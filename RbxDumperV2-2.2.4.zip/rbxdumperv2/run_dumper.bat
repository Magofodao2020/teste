@echo off

if exist "RbxDumperV2.exe" (
    RbxDumperV2.exe
) else if exist "cmake-build-release\RbxDumperV2\RbxDumperV2.exe" (
    cmake-build-release\RbxDumperV2\RbxDumperV2.exe
) else (
    cmake-build-debug\RbxDumperV2\RbxDumperV2.exe
)

pause
