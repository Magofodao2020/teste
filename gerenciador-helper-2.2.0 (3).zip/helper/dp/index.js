'use strict';
/**
 * Pasta dp: koffi 2.16.3 (MIT, https://koffi.dev) embutido no Helper.
 * Pasta e binários renomeados (dp/, dp.node); o conteúdo dos binários não foi alterado.
 *
 * Só os binários nativos do Windows (x64, ia32, arm64), copiados sem alteração do
 * pacote oficial (npm koffi@2.16.3, integridade sha512 conferida). Este carregador
 * substitui o index.js do pacote: não precisa de "npm install", não cria a pasta
 * node_modules e não tem nenhum código de download (o index.js original traz
 * ferramentas de instalação com https/fs que o Helper não usa).
 */
const VERSION = '2.16.3';
const ARCHS = { x64: 'x64', ia32: 'ia32', arm64: 'arm64' };

function load(dir = __dirname, platform = process.platform, arch = process.arch) {
  const a = ARCHS[arch];
  if (!a) throw new Error(`Arquitetura não suportada pela pasta dp: ${platform}_${arch}`);
  const native = require(`${dir}/${platform}_${a}/dp.node`);
  if (native.version !== VERSION) throw new Error(`dp.node com versão inesperada (${native.version}, esperado ${VERSION})`);
  return { ...native };
}

module.exports = load();
