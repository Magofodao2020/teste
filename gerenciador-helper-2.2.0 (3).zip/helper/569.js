/*
 * Mapa de teclas compartilhado (thread principal + workers).
 *
 * O site guarda teclas no formato KeyboardEvent.code ("KeyE", "Space", "F6"...),
 * que é a POSIÇÃO FÍSICA da tecla — não depende do layout (ABNT2, US, etc).
 * Por isso o mapa principal aqui é  code -> scancode (set 1)  + flag "estendida".
 *
 *  - Para INJETAR teclas (macros) usamos o scancode: o jogo recebe exatamente a
 *    tecla física, igual a um teclado de verdade.
 *  - Para LER teclas com GetAsyncKeyState (hotkeys) precisamos do VK, que depende
 *    do layout; o VK é obtido em tempo de execução com MapVirtualKeyW(scan) e,
 *    se falhar, cai na tabela estática (layout US).
 *
 * Botões do mouse usam pseudo-codes: MouseLeft, MouseRight, MouseMiddle,
 * MouseBack (lateral ◄), MouseForward (lateral ►). Scroll: ScrollUp/ScrollDown.
 * Teclas desconhecidas podem ser escritas como "VK_XX" (hex), ex.: "VK_B3".
 */

// code -> [scancode, estendida?]
const SCAN = {
  Escape: [0x01], Digit1: [0x02], Digit2: [0x03], Digit3: [0x04], Digit4: [0x05], Digit5: [0x06],
  Digit6: [0x07], Digit7: [0x08], Digit8: [0x09], Digit9: [0x0a], Digit0: [0x0b], Minus: [0x0c],
  Equal: [0x0d], Backspace: [0x0e], Tab: [0x0f], KeyQ: [0x10], KeyW: [0x11], KeyE: [0x12],
  KeyR: [0x13], KeyT: [0x14], KeyY: [0x15], KeyU: [0x16], KeyI: [0x17], KeyO: [0x18], KeyP: [0x19],
  BracketLeft: [0x1a], BracketRight: [0x1b], Enter: [0x1c], ControlLeft: [0x1d], KeyA: [0x1e],
  KeyS: [0x1f], KeyD: [0x20], KeyF: [0x21], KeyG: [0x22], KeyH: [0x23], KeyJ: [0x24], KeyK: [0x25],
  KeyL: [0x26], Semicolon: [0x27], Quote: [0x28], Backquote: [0x29], ShiftLeft: [0x2a],
  Backslash: [0x2b], KeyZ: [0x2c], KeyX: [0x2d], KeyC: [0x2e], KeyV: [0x2f], KeyB: [0x30],
  KeyN: [0x31], KeyM: [0x32], Comma: [0x33], Period: [0x34], Slash: [0x35], ShiftRight: [0x36],
  NumpadMultiply: [0x37], AltLeft: [0x38], Space: [0x39], CapsLock: [0x3a],
  F1: [0x3b], F2: [0x3c], F3: [0x3d], F4: [0x3e], F5: [0x3f], F6: [0x40], F7: [0x41], F8: [0x42],
  F9: [0x43], F10: [0x44], NumLock: [0x45, 1], ScrollLock: [0x46], Numpad7: [0x47], Numpad8: [0x48],
  Numpad9: [0x49], NumpadSubtract: [0x4a], Numpad4: [0x4b], Numpad5: [0x4c], Numpad6: [0x4d],
  NumpadAdd: [0x4e], Numpad1: [0x4f], Numpad2: [0x50], Numpad3: [0x51], Numpad0: [0x52],
  NumpadDecimal: [0x53], IntlBackslash: [0x56], F11: [0x57], F12: [0x58],
  F13: [0x64], F14: [0x65], F15: [0x66], F16: [0x67], F17: [0x68], F18: [0x69], F19: [0x6a],
  F20: [0x6b], F21: [0x6c], F22: [0x6d], F23: [0x6e], F24: [0x76],
  IntlRo: [0x73], NumpadComma: [0x7e],
  // estendidas (prefixo E0)
  NumpadEnter: [0x1c, 1], ControlRight: [0x1d, 1], NumpadDivide: [0x35, 1], PrintScreen: [0x37, 1],
  AltRight: [0x38, 1], Home: [0x47, 1], ArrowUp: [0x48, 1], PageUp: [0x49, 1], ArrowLeft: [0x4b, 1],
  ArrowRight: [0x4d, 1], End: [0x4f, 1], ArrowDown: [0x50, 1], PageDown: [0x51, 1], Insert: [0x52, 1],
  Delete: [0x53, 1], MetaLeft: [0x5b, 1], MetaRight: [0x5c, 1], ContextMenu: [0x5d, 1],
};

// code -> VK (fallback estático, layout US) — usado quando MapVirtualKeyW não ajuda
const VK_STATIC = {
  Escape: 0x1b, Tab: 0x09, CapsLock: 0x14, Space: 0x20, Enter: 0x0d, NumpadEnter: 0x0d, Backspace: 0x08,
  ShiftLeft: 0xa0, ShiftRight: 0xa1, ControlLeft: 0xa2, ControlRight: 0xa3, AltLeft: 0xa4, AltRight: 0xa5,
  MetaLeft: 0x5b, MetaRight: 0x5c, ContextMenu: 0x5d,
  Insert: 0x2d, Delete: 0x2e, Home: 0x24, End: 0x23, PageUp: 0x21, PageDown: 0x22,
  ArrowUp: 0x26, ArrowDown: 0x28, ArrowLeft: 0x25, ArrowRight: 0x27,
  PrintScreen: 0x2c, ScrollLock: 0x91, Pause: 0x13, NumLock: 0x90,
  NumpadMultiply: 0x6a, NumpadAdd: 0x6b, NumpadSubtract: 0x6d, NumpadDecimal: 0x6e, NumpadDivide: 0x6f,
  NumpadComma: 0xc2, IntlRo: 0xc1, IntlBackslash: 0xe2,
  Minus: 0xbd, Equal: 0xbb, BracketLeft: 0xdb, BracketRight: 0xdd, Backslash: 0xdc,
  Semicolon: 0xba, Quote: 0xde, Backquote: 0xc0, Comma: 0xbc, Period: 0xbe, Slash: 0xbf,
  MouseLeft: 0x01, MouseRight: 0x02, MouseMiddle: 0x04, MouseBack: 0x05, MouseForward: 0x06,
};
for (let i = 0; i < 26; i++) VK_STATIC['Key' + String.fromCharCode(65 + i)] = 0x41 + i;
for (let i = 0; i < 10; i++) { VK_STATIC['Digit' + i] = 0x30 + i; VK_STATIC['Numpad' + i] = 0x60 + i; }
for (let i = 1; i <= 24; i++) VK_STATIC['F' + i] = 0x6f + i;

const MOUSE_CODES = new Set(['MouseLeft', 'MouseRight', 'MouseMiddle', 'MouseBack', 'MouseForward']);
const SCROLL_CODES = new Set(['ScrollUp', 'ScrollDown']);

// reverso: (scan|ext) -> code
const SCAN_TO_CODE = {};
for (const [code, [sc, ext]] of Object.entries(SCAN)) SCAN_TO_CODE[(ext ? 0xe000 : 0) | sc] = code;
// reverso: vk -> code (só para quando o scancode não resolve)
const VK_TO_CODE = {};
for (const [code, vk] of Object.entries(VK_STATIC)) if (VK_TO_CODE[vk] == null && !MOUSE_CODES.has(code)) VK_TO_CODE[vk] = code;
VK_TO_CODE[0x10] = 'ShiftLeft'; VK_TO_CODE[0x11] = 'ControlLeft'; VK_TO_CODE[0x12] = 'AltLeft';

function parseVkCode(code) {
  const m = /^VK_([0-9A-Fa-f]{1,2})$/.exec(String(code || ''));
  return m ? parseInt(m[1], 16) : null;
}

/** Info para injetar uma tecla: { scan, ext, vk } (scan 0 = usar só VK). */
function keyInfo(code) {
  const s = SCAN[code];
  const vk = VK_STATIC[code] ?? parseVkCode(code);
  if (s) return { scan: s[0], ext: !!s[1], vk: vk ?? 0 };
  if (vk != null) return { scan: 0, ext: false, vk };
  return null;
}

/**
 * Cria um conversor code -> VK que respeita o layout atual do Windows
 * (MapVirtualKeyW com MAPVK_VSC_TO_VK_EX). mapVirtualKey pode ser null.
 */
function makeCodeToVk(mapVirtualKey) {
  const cache = new Map();
  return function codeToVk(code) {
    if (!code) return null;
    if (cache.has(code)) return cache.get(code);
    let vk = null;
    if (MOUSE_CODES.has(code)) vk = VK_STATIC[code];
    else {
      const raw = parseVkCode(code);
      if (raw != null) vk = raw;
      else {
        const s = SCAN[code];
        if (s && mapVirtualKey) {
          try {
            const r = mapVirtualKey((s[1] ? 0xe000 : 0) | s[0], 3 /* MAPVK_VSC_TO_VK_EX */);
            if (r) vk = r;
          } catch {}
        }
        if (vk == null) vk = VK_STATIC[code] ?? null;
      }
    }
    cache.set(code, vk);
    return vk;
  };
}

/** Tecla vinda do hook (vk + scancode + flag estendida) -> code. */
function codeFromHook(vk, scan, ext) {
  const byScan = SCAN_TO_CODE[(ext ? 0xe000 : 0) | (scan & 0xff)];
  if (byScan && scan) return byScan;
  if (vk === 0x0d && ext) return 'NumpadEnter';
  const byVk = VK_TO_CODE[vk];
  if (byVk) return byVk;
  return 'VK_' + vk.toString(16).toUpperCase().padStart(2, '0');
}

module.exports = { SCAN, VK_STATIC, MOUSE_CODES, SCROLL_CODES, keyInfo, makeCodeToVk, codeFromHook, parseVkCode };
