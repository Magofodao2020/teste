# Painel do BOPE — Helper Local

Ponte entre o site (Painel do BOPE) e o Roblox na sua máquina. Roda em Node.js,
**só localmente** (`127.0.0.1`), **sem internet** e **sem gravar nada no PC**.

## O que faz

- **Ações** (Bug Indi, Bug indi ESQUERDA, Bug indi DIREITA, Perfect Dive, Gagatech):
  executa as ações configuradas no site quando você aperta o botão/tecla definido,
  mesmo com o Roblox em foco e o navegador minimizado.
- **Presets de flags**: escreve os valores das flags diretamente na memória do
  Roblox em execução (aplicar, pausar, retomar, atalhos de ligar/desligar e alternar).
- **Identificação do Roblox**: descobre a versão (`version-…`) do Roblox que está
  rodando a partir do próprio processo e bloqueia qualquer escrita se os offsets
  forem de outra versão.

## Requisitos

- Windows
- Node.js 18+ instalado uma vez (https://nodejs.org/)
- Roblox aberto (dentro de um jogo) para aplicar flags
- Recomendado: rodar como administrador (necessário se o Roblox estiver elevado)

## Uso

Dê dois cliques em `help.bat` (ele usa o Node.js do PC).
**Não precisa de `npm install`:** a única dependência (koffi, para chamar o Windows)
já vem na pasta `dp/`, então nenhuma pasta `node_modules` é criada.

Depois abra o **site** no navegador: ele encontra
o Helper sozinho (portas 7962–7966) e envia offsets, ações e atalhos.
Deixe a janela do Helper aberta enquanto joga.

## Como funciona

```
INTERNET ──► SITE (navegador)
               │  versão LIVE + offsets (baixados e validados no navegador)
               │  ações, presets e atalhos (salvos no navegador)
               ▼
           HELPER LOCAL (127.0.0.1, só em memória)
               ▼
           Roblox em execução
```

1. O Helper escuta em `127.0.0.1:7962` (ou a próxima porta livre até 7966).
2. O site envia por POST: offsets de FFlags (`/set-offsets`), ações (`/set-macros`),
   atalhos de flags (`/set-hotkeys`) e as operações (`/apply`, `/pause`, `/resume`…).
3. O Helper identifica o Roblox em execução e, **imediatamente antes de cada escrita**,
   confere: versão do processo = versão dos offsets = versão do dataset do site.
   Qualquer diferença (ou versão desconhecida) → a escrita é bloqueada com a explicação.
4. Ações e atalhos são lidos globalmente (`GetAsyncKeyState` + hook de mouse/scroll).

O Helper **não** baixa offsets nem dumps e não fala com nenhum serviço externo.
Se ele ainda não recebeu os offsets, as operações de flags respondem pedindo para
abrir o site.

## Identificação da versão do Roblox

Mesmo princípio do RbxDumperV2: processo `RobloxPlayerBeta.exe` → PID → módulos do
processo → caminho real do `RobloxPlayerBeta.exe` → pasta `version-…` que contém o
executável. Não usa pastas instaladas no disco, então funciona com Fishstrap/Bloxstrap
e com várias versões instaladas. Várias instâncias abertas só são aceitas se estiverem
na mesma versão; caso contrário a versão fica desconhecida e nada é escrito.

## Diagnóstico

```bash
node 626.js --test
```

Mostra se o FFI (koffi) carregou, cada instância do Roblox com caminho e versão,
o PID usado e se o `OpenProcess` funcionou. Com o Helper rodando,
`http://127.0.0.1:7962/status` e `/debug` mostram o mesmo em JSON.

Se não detectar: confira se o Roblox está dentro de um jogo, se a pasta `dp` foi extraída junto
e tente o `help.bat` como administrador.

## Como a injeção funciona (633.js)

1. **Sessão por processo:** PID + horário de criação do processo. Roblox fechado e
   aberto de novo (mesmo com o PID reaproveitado) = sessão nova; nada do processo
   anterior é reaproveitado.
2. **Tudo é validado antes de escrever:** tipo pelo prefixo do nome; valor estrito
   (`true/false`, inteiro de 32 bits, float finito, texto até 15 bytes — o resto é
   recusado, nunca vira 0); endereço alinhado, dentro do `RobloxPlayerBeta.exe` e numa
   página que já é gravável (`PAGE_READWRITE`/`PAGE_WRITECOPY`). A proteção da memória
   nunca é alterada: endereço que não passa = offset errado = recusa.
3. **Lote atômico:** se uma escrita falhar no meio de "Aplicar", as já feitas naquele
   lote são desfeitas. Nada fica pela metade.
4. **Valor original por endereço:** guardado no primeiro contato da sessão (nomes
   diferentes que apontam para a mesma flag compartilham o original).
5. **Valor igual não é reescrito;** toda escrita é conferida por leitura logo depois.
6. **Texto:** só textos curtos (buffer interno do `std::string`); texto longo no heap
   não é tocado, porque trocá-lo com o jogo lendo podia crashar.

## Sobre pausar (reverter flags)

Pausar (ou `/restore`) devolve os **bytes originais exatos**, na ordem inversa das
alterações, e só nas flags que o Helper alterou neste processo do Roblox.

| Situação | O que acontece ao pausar |
|---|---|
| Flag alterada pelo Helper | volta ao valor original exato (inclusive texto curto) |
| Flag do preset que não foi alterada | não é tocada |
| Roblox reaberto depois de aplicar | nada a pausar (o processo novo já está no padrão) |
| Helper reaberto com o Roblox já alterado | recupera o original pelo site (se a aba do site ficou aberta); senão avisa e pede para reiniciar o Roblox |

Nunca é escrito um "padrão" inventado (`false`/`0`): um valor que o jogo nunca teve
pode crashar o Roblox. Reiniciar o Roblox sempre restaura 100% dos valores padrão.

## O que o Helper grava no PC

**Nada.** Não cria arquivos, pastas, cache, logs nem usa AppData/Temp/Registro.
Offsets, ações, atalhos e valores originais ficam só na memória enquanto o Helper
está aberto. As mensagens do console aparecem apenas na janela do `help.bat`.
Para depurar: `GERENCIADOR_DEBUG=1 node 626.js` (mesmo assim nada é gravado).

## Problemas comuns

- **Ação não faz nada no jogo:** as ações só disparam com o Roblox em foco. Se o
  Roblox roda como administrador, o Helper também precisa.
- **"Versão incompatível":** o Roblox aberto não é da mesma versão dos offsets do
  site. Atualize o Roblox (feche e abra) ou aguarde o site atualizar os offsets.
- **"O Helper ainda não recebeu os offsets do site":** abra o site com o Helper aberto.

## Arquivos

| Arquivo | Função |
|---|---|
| `626.js` | servidor local, identificação do Roblox, chamadas do Windows, atalhos |
| `633.js` | motor de injeção: validação, lote atômico, valores originais, restauração |
| `dp/` | koffi 2.16.3 embutido, renomeado (binários do Windows `dp.bin` + carregador; licença MIT em `dp/LICENSE.txt`) |
| `521.js` | sistema de ações (gatilhos, execução, parada) |
| `592.js` | executa as ações (worker; SendInput) |
| `609.js` | hook global de mouse/scroll/teclado (scroll, gravação e "definir botão") |
| `569.js` | mapa de teclas (código físico ↔ scancode/VK) |

## Novidades 2.5.2

- **Alternar o lado do flick** (ex.: Bug indi): no editor da ação, defina o "Botão que
  alterna o lado do flick". Um botão faz a ação; o outro troca esquerda ⇄ direita
  (espelha o movimento horizontal das etapas de flick). Começa no lado configurado
  nas etapas; o lado escolhido fica só na memória do Helper.
- Bipe ao trocar (pode desligar): agudo = direita, grave = esquerda. Toca em outra
  thread, sem travar os atalhos, e sem arquivo de som.

## Novidades 2.5.1

- **Helper não "desconecta do nada":**
  - Desliga o "Modo de Edição Rápida" só na janela do Helper (nada vai pro registro).
    Antes, um clique na janela do CMD deixava o Helper congelado em "Selecionar".
  - Um erro inesperado não fecha mais o Helper: aparece no console e ele segue rodando.
  - `/status` responde na hora (cache de 1,5 s só para o status; aplicar/pausar sempre
    identificam o Roblox na hora).
  - O hook global (scroll/botões/gravação) reinicia sozinho se cair.
  - `help.bat` reabre o Helper sozinho se o Node fechar com erro (até 5 vezes).
- Site: espera mais pela resposta e só mostra "desconectado" depois de duas falhas seguidas.

## Novidades 2.5.0

- **Turbo automático** (sem opção de desligar): ao **Aplicar** ou **Retomar**, o
  Helper passa a conferir as flags aplicadas a cada 1 s e reaplica as que o Roblox
  voltar sozinho. **Pausar** para o turbo; aplicar/retomar liga de novo.
- Leve: um único timer de 1 s, sem procurar o Roblox de novo a cada volta (segue o
  mesmo processo em que aplicou); só lê as flags aplicadas e escreve apenas as que
  mudaram, com as validações de sempre. Roblox fechado = o turbo para sozinho.
- Flag desligada pelo atalho (toggle) não é reaplicada.
- O console mostra `[TURBO] ativo/parado` e `[TURBO] reaplicada(s): ...` (no máximo
  uma linha a cada 5 s).

## Novidades 2.4.8

- Desligar (toggle) e pausar voltam ao valor padrão mesmo depois de fechar e abrir o
  Helper com o Roblox aberto. Antes, o Helper novo guardava o valor JÁ ALTERADO como
  "original" e o OFF não mudava nada. Agora a aba do site guarda os valores padrão
  (só na memória da aba, nada é gravado no PC) e devolve ao Helper novo
  (`/set-originals`), aceito só para o mesmo processo do Roblox.
- Se mesmo assim o padrão for desconhecido (ex.: site e Helper fechados), o console
  avisa em vez de mostrar um OFF que não muda nada.

## Novidades 2.4.7

- Corrige o ON/OFF + CYCLE no mesmo clique: o mesmo atalho podia estar salvo duas
  vezes para a mesma flag (com e sem prefixo, ex.: `DFIntX` e `X`). Agora os dois nomes
  contam como a mesma flag: cada ação roda uma vez só, e se "ligar/desligar" e
  "alternar valores" estiverem no mesmo botão, só "ligar/desligar" roda (com aviso).

## Novidades 2.4.6

- Corrige o disparo duplo (ON→OFF no mesmo acionamento) de toggle/cycle de flags:
  enquanto o toggle/cycle está em andamento novos gatilhos são ignorados, com um
  descanso curto depois. Vale para botões com "bounce"/mouse que repete o evento.
- Scroll de alta resolução: acumula o giro e dispara a hotkey uma vez por giro
  completo (não repete o toggle).

## Novidades 2.4.5

- Volta a usar o Node.js do PC (instale uma vez). Nenhum `.exe` vem no zip.

## Novidades 2.4.3

- "Definir botão" pelo Helper: ao clicar em um campo de botão no site, o hook global
  do Windows informa o próximo botão/tecla (`/capture/start`, `/capture/status`,
  `/capture/stop`). Funciona igual em qualquer navegador e mouse, inclusive os
  laterais que alguns navegadores/mouses não repassam à página. O lateral capturado
  não chega ao navegador (que voltaria a página). Durante a captura, botões não
  disparam ações nem atalhos. Nada é gravado.

## Novidades 2.4.2

- Mesmo motor de injeção da 2.4.0.
- Sem `npm install` e sem pasta `node_modules`: o koffi 2.16.3 vem embutido na pasta
  `dp/` (binários do Windows renomeados para `dp.bin`, conteúdo sem alteração, e um
  carregador mínimo sem código de download).

## Novidades 2.4.0

- Novo motor de injeção (`633.js`), descrito em "Como a injeção funciona": sessão por
  processo, validação completa antes de escrever, lote atômico, originais por endereço,
  restauração exata (inclusive texto curto), `/restore` funcional.
- Pausar nunca escreve valores inventados; escrita só em páginas já graváveis.

## Novidades 2.3.0

- Sem internet: os offsets vêm somente do site (antes eram baixados pelo Helper).
- `startedAt` no `/status`, para o site reenviar a configuração quando o Helper reinicia.
- Mensagens claras quando os offsets ainda não foram recebidos.
