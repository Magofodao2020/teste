# Gerenciador — Helper Local (Injeção em Memória)

Ponte entre o Gerenciador (site) e o Roblox na sua máquina.

## O que faz

Injeta flags **diretamente na memória** do processo Roblox em execução
usando offsets do [Imtheo](https://dev.imtheo.lol). Nenhum arquivo
ClientAppSettings.json é escrito.

## Modo recomendado: tudo em um só (site + helper juntos)

Este helper é **só a API local** em **http://127.0.0.1:7962** (injeção, hotkeys e
execução de ações). O **site é separado** (hospede a pasta `gerenciador-site-hospedar`)
e conversa com o helper por CORS. O helper **não serve páginas** e **não inclui `web/`**.

```bash
cd helper
npm install
node 626.js
```

Depois abra **http://127.0.0.1:7962** no navegador. Pronto — sem precisar
hospedar nada.

> Se você hospedar o site num serviço externo (Netlify, Cloudflare, etc.), ele
> será servido em **HTTPS**, e aí o navegador precisa liberar o acesso ao helper
> HTTP local: Chrome/Edge/Firefox funcionam (às vezes pedem permissão de "rede
> local" uma vez); **Safari não funciona** nesse cenário. Por isso o modo
> all-in-one acima é o mais simples e compatível.

## Requisitos

- **Node.js 18+**
- **Windows** (usa APIs do kernel para acessar a memória)
- **Roblox rodando** — abra o Roblox e entre em um jogo antes de aplicar
- **Recomendado:** rodar como administrador

## Instalação e uso

```bash
cd helper
npm install
node 626.js
```

Ou simplesmente dê dois cliques em `help.bat`.

## Funcionalidades

- **Injetar flags** — escreve valores na memória do Roblox. Antes da primeira
  escrita, captura o valor **original** de cada flag para poder revertê-lo.
- **Toggle** — ativa/desativa uma flag com clique ou hotkey. Ao desativar,
  reverte ao original capturado ou, na falta dele, ao **default por tipo**
  (`false` para bool, `0` para int/float).
- **Cycle** — cicla entre valores pré-definidos com hotkey.
- **Pausar / desaplicar tudo** — reverte **todas** as flags ao valor
  original/default na memória (igual ao "disable all" da versão desktop).
  Funciona mesmo para flags não aplicadas nesta sessão (usa o default por tipo).
  Strings não são revertíveis na memória — só reiniciando o Roblox.
- **Despausar** — reaplica todas as flags do preset.
- **Hotkeys globais** — funciona mesmo com o Roblox em foco e o navegador
  minimizado/fechado. Aceita **teclas** (F1–F12, letras, etc.) **e botões do
  mouse**: botão do meio e os dois **botões laterais** (◄ voltar / ► avançar).
  A execução é toda feita pelo helper via `GetAsyncKeyState`, que lê o estado
  global do teclado e do mouse — por isso não precisa do navegador em foco.

- **Macros (mouse + teclado)** — estilo TinyTask, configurados na página
  **Macros** do site e executados pelo helper. Veja a seção abaixo.

### Sobre a reversão (pausar)

| Situação | Alvo da reversão |
|---|---|
| Valor original capturado no apply | o valor original |
| Flag bool sem original | `false` |
| Flag int/float sem original | `0` |
| Flag string | não revertível (reinicie o Roblox) |

Reiniciar o Roblox sempre restaura 100% dos valores padrão.

## Como funciona

1. Escuta em `127.0.0.1:7962` (localhost)
2. O site envia flags via POST
3. O helper encontra o processo Roblox, baixa offsets, e escreve na memória
4. Hotkeys são monitoradas via `GetAsyncKeyState` (funcionam globalmente)

## Diagnóstico (se não detectar o Roblox)

Rode o autoteste, que verifica só a detecção e mostra o que está acontecendo:

```bash
node 626.js --test
```

Ele mostra:
- Se o FFI (koffi) carregou corretamente
- Cada instância do `RobloxPlayerBeta.exe` em execução, com o caminho real e a versão (`version-…`)
- O PID do Roblox usado pelo Helper (se encontrado)
- Se o `OpenProcess` funcionou (senão, rode como **administrador**)
- O base address do processo

Com o helper rodando, você também pode acessar `http://127.0.0.1:7962/debug`
no navegador para ver o mesmo diagnóstico em JSON.

**Checklist se não detectar:**
1. O Roblox está realmente aberto e **dentro de um jogo** (não só o launcher)?
2. Rodou `npm install` na pasta `helper`?
3. Tentou rodar o terminal/`help.bat` **como administrador**?
4. O processo é `RobloxPlayerBeta.exe`? (a versão da Microsoft Store tem outro nome)

## Versão do Roblox em execução

A versão (`version-…`) é identificada **no processo que está rodando**, como no
RbxDumperV2: processo `RobloxPlayerBeta.exe` → PID → módulos do processo →
caminho real do `RobloxPlayerBeta.exe` → pasta `version-…` que contém o executável.
Não usa pastas instaladas no disco nem a seleção do site, então funciona com
Fishstrap/Bloxstrap e com várias versões instaladas.

- A identificação é refeita imediatamente antes de cada escrita (aplicar, toggle,
  cycle, pausar) e comparada com a versão dos offsets e do dataset do site.
  Versões diferentes → **bloqueia** e mostra as duas versões.
- Várias instâncias abertas: só segue se todas estiverem na mesma versão. Senão,
  ou se a versão não puder ser lida, o estado fica desconhecido e nada é escrito.

## Macros (v2.1)

Página **Macros** no site. Quem executa é o helper (JavaScript puro, sem
programas extras): os macros funcionam **globalmente**, com o Roblox em foco e o
navegador minimizado ou fechado.

### Como usar

1. Abra o `help.bat` e o site → **Macros** → **Novo macro**.
2. Monte os passos ou clique em **Gravar** (contagem regressiva → vá para o jogo →
   faça as ações → aperte **F8** para parar).
3. Clique em **Botão que dispara** e aperte a tecla / botão do mouse
   (meio, laterais ◄ ►, scroll ↑ ↓ ou qualquer tecla).
4. **Testar (3s)** roda uma vez depois de 3 segundos.

A configuração (ações, hotkeys, Flick, etc.) fica no **site** (no seu navegador) e
é enviada ao Helper em memória a cada sessão. O Helper não grava nada no PC — ao
reabrir, abra o site para o Helper receber a config de novo.

### Modos

| Modo | Comportamento |
|---|---|
| Uma vez | Roda N repetições e para. Apertar o botão de novo durante a execução cancela. |
| Loop (liga/desliga) | Aperta: começa a repetir. Aperta de novo: para. |
| Enquanto segurar | Repete enquanto o botão estiver apertado (não vale para scroll). |

**Tecla de parada** (padrão F8): para todos os macros e encerra a gravação.
**Velocidade**: multiplica todos os tempos (2× = metade do tempo).
**Só com o Roblox em foco**: o botão não dispara se outra janela estiver na frente.

### Passos

Todo passo tem **espera antes** (ms). Tipos:

| Passo | Campos |
|---|---|
| Mover mouse | X, Y (ou ΔX/ΔY se *relativo*), duração (0 = teleporta), suave |
| Trajetória gravada | pontos gravados; dá para *simplificar* ou virar *movimento reto* |
| Clique | botão, vezes, segurar (ms), intervalo (ms) |
| Segurar / Soltar botão | botão (para arrastar) |
| Scroll | cliques (+ cima / − baixo), intervalo |
| Tecla | tecla, vezes, segurar, intervalo |
| Segurar / Soltar tecla | tecla (ex.: segurar W enquanto move) |
| Digitar texto | texto, intervalo entre letras |
| Esperar | ms |
| **Flick (câmera)** | botão (M1/M2/meio/nenhum), delay inicial, hold, pré-flick, X, Y (relativos), duração, pós-flick, cooldown |

Ao parar um macro (gatilho, F8 ou fim), qualquer tecla/botão que ele tenha
deixado apertado é **solto automaticamente**.

**Relativo / câmera:** para mover a câmera em 1ª pessoa ou shift lock, use
movimento *relativo* (ou grave com "Coordenadas: relativa"). Posição na tela
serve para menus e cliques em botões da interface.

### Compartilhar / copiar configuração

**Copiar código** gera `BOPE-MACRO1:…` (ou `BOPE-MACRO1Z:…` comprimido para
gravações longas). **Importar** aceita o código, o JSON ou um arquivo.
Por padrão o código **não leva o botão** — quem importa escolhe o próprio botão.

Formato JSON (o mesmo que fica dentro do código):

```json
{
  "bope": "macro", "v": 1,
  "name": "Exemplo", "mode": "once", "repeat": 1, "loopDelay": 0,
  "speed": 1, "robloxOnly": false,
  "steps": [
    { "t": "key", "code": "KeyE", "hold": 40 },
    { "t": "wait", "ms": 250 },
    { "t": "move", "x": 960, "y": 540, "dur": 120, "delay": 50 },
    { "t": "click", "btn": "left", "n": 2, "hold": 40, "gap": 60 }
  ]
}
```

Vários de uma vez: `{ "bope": "macro-pack", "v": 1, "macros": [ ... ] }`.
Teclas usam `KeyboardEvent.code` (posição física: funciona igual em ABNT2 e US).
Botões: `left`, `right`, `middle`, `back`, `forward`.
`path.pts` é uma lista plana `[dt, x, y, dt, x, y, …]` (dt em ms; com `"rel": true`, x/y são deslocamentos).

> Para um futuro sistema de **presets de macro**, basta uma lista desses objetos
> (sem `trigger`); o usuário só escolhe o botão ao importar.


### Flick (igual ao macro.ahk)

O passo **Flick** reproduz o `macro.ahk`: um movimento **relativo** do mouse que o
Roblox lê como giro de câmera (não é posição na tela). A sequência, com **cada
tempo configurável** (pode ser 0):

```
hotkey → delay inicial → M1 Down → hold → M1 Up → pré-flick → MoveRel(X, Y) → pós-flick → cooldown
```

- **X / Y**: movimento relativo em unidades do mouse (+X direita, −X esquerda; +Y baixo, −Y cima).
- **duração**: 0 = um único envio relativo (igual ao `mouse_event` do `.ahk`, recomendado); >0 interpola.
- Os botõezinhos de seta preenchem X/Y numa direção, mantendo a magnitude atual.

O app já vem com o preset **AHK Default** (duas ações, editáveis):

| Ação | Botão | Hold | Pré-flick | X | Y |
|---|---|---|---|---|---|
| Flick Down (AHK) | XButton1 (lateral ◄) | 500 ms | 0 ms | 13 | 4502 |
| Flick Up (AHK) | Home | 500 ms | 0 ms | 0 | -500 |

> Precisão de tempo: o helper chama `timeBeginPeriod(1)` (resolução de ~1 ms, igual ao
> `.ahk`) e os workers dormem com `Atomics.wait` + espera ativa no fim, para delays
> curtos saírem consistentes.

### Problemas comuns

- **Macro não faz nada no jogo:** se o Roblox estiver rodando como administrador,
  o helper também precisa (o Windows bloqueia input de um processo comum para um elevado).
- **Posição errada do mouse:** o helper usa pixels físicos (DPI-aware). Grave e rode
  na mesma resolução/escala de tela.
- **Gravação não inicia:** o console do helper mostra se o hook global subiu
  ("✓ Hook global ativo").


## Helper mínimo (sem o site embutido)

O Helper é **só a API local** (porta 127.0.0.1:7962): injeção em memória, hotkeys e
execução das ações. Ele **não inclui o site** nem serve páginas — o site é hospedado
à parte (pasta `gerenciador-site-hospedar`) e conversa com o Helper por CORS. Por isso
o pacote do Helper **não tem pasta `web/`** e o código não usa `fs` (não lê nem grava
arquivos no PC).

## O que o helper grava no PC

**Nada.** O Helper é 100% em memória: **não cria arquivos, pastas, cache, logs,
nem usa AppData/Temp/Registry**. Toda a sua configuração (presets, ações, hotkeys,
Flick, Toggle, Cycle, delays) fica no **site**, salva no seu navegador, e é enviada
ao Helper em memória enquanto ele está aberto. Fechou o Helper, nada fica para trás.

Fluxo: **site → config em memória → Helper → execução.** Os offsets, quando
necessários, são baixados e usados só em memória durante a execução (sem cache em
disco). As mensagens do console são apenas a tela do `help.bat` e não vão para
arquivo. Para depurar, rode com `GERENCIADOR_DEBUG=1` (mesmo assim, nada é gravado).

## Arquivos do helper

| Arquivo | Função |
|---|---|
| `626.js` | servidor local, injeção de flags, hotkeys |
| `521.js` | sistema de macros (gatilhos, gravação, sincronização) |
| `592.js` | executa os macros (worker; SendInput) |
| `609.js` | hook global: scroll nas hotkeys + gravação (substitui o antigo `mouse-hook.js`, que pode ser apagado) |
| `569.js` | mapa de teclas (código físico ↔ scancode/VK) |

## Novidades 2.1.0

- Sistema de macros (acima).
- Hotkeys aceitam qualquer tecla capturada pelo site (antes só F1–F12, letras,
  números e algumas outras), respeitando o layout do teclado.
- Corrigido: abrir `http://127.0.0.1:7962/` mostrava o JSON de status em vez do site.
- Site: o botão lateral do mouse não volta mais a página ao definir hotkeys;
  presets prontos atualizados no JSON agora atualizam a cópia salva no navegador.
