# Painel do BOPE — Helper Local

Ponte entre o site (Painel do BOPE) e o Roblox na sua máquina. Roda em Node.js,
**só localmente** (`127.0.0.1`), **sem internet** e **sem gravar nada no PC**.

## O que faz

- **Ações** (Bug Indi, Bug indi ESQUERDA, Bug indi DIREITA, Perfect Dive, Gagatech):
  executa as ações configuradas no site quando você aperta o botão/tecla definido,
  mesmo com o Roblox em foco e o navegador minimizado.
- **Presets de flags**: escreve os valores das flags diretamente na memória do
  Roblox em execução (aplicar, pausar, retomar, atalhos de ligar/desligar e alternar).
- **Identificação do Roblox**: descobre a versão (`version-…`) do Roblox que está
  rodando a partir do próprio processo e bloqueia qualquer escrita se os offsets
  forem de outra versão.

## Requisitos

- Windows
- Node.js 18+
- Roblox aberto (dentro de um jogo) para aplicar flags
- Recomendado: rodar como administrador (necessário se o Roblox estiver elevado)

## Uso

```bash
cd helper
npm install
node 626.js
```

Ou dê dois cliques em `help.bat`. Depois abra o **site** no navegador: ele encontra
o Helper sozinho (portas 7962–7966) e envia offsets, ações e atalhos.
Deixe a janela do Helper aberta enquanto joga.

## Como funciona

```
INTERNET ──► SITE (navegador)
               │  versão LIVE + offsets (baixados e validados no navegador)
               │  ações, presets e atalhos (salvos no navegador)
               ▼
           HELPER LOCAL (127.0.0.1, só em memória)
               ▼
           Roblox em execução
```

1. O Helper escuta em `127.0.0.1:7962` (ou a próxima porta livre até 7966).
2. O site envia por POST: offsets de FFlags (`/set-offsets`), ações (`/set-macros`),
   atalhos de flags (`/set-hotkeys`) e as operações (`/apply`, `/pause`, `/resume`…).
3. O Helper identifica o Roblox em execução e, **imediatamente antes de cada escrita**,
   confere: versão do processo = versão dos offsets = versão do dataset do site.
   Qualquer diferença (ou versão desconhecida) → a escrita é bloqueada com a explicação.
4. Ações e atalhos são lidos globalmente (`GetAsyncKeyState` + hook de mouse/scroll).

O Helper **não** baixa offsets nem dumps e não fala com nenhum serviço externo.
Se ele ainda não recebeu os offsets, as operações de flags respondem pedindo para
abrir o site.

## Identificação da versão do Roblox

Mesmo princípio do RbxDumperV2: processo `RobloxPlayerBeta.exe` → PID → módulos do
processo → caminho real do `RobloxPlayerBeta.exe` → pasta `version-…` que contém o
executável. Não usa pastas instaladas no disco, então funciona com Fishstrap/Bloxstrap
e com várias versões instaladas. Várias instâncias abertas só são aceitas se estiverem
na mesma versão; caso contrário a versão fica desconhecida e nada é escrito.

## Diagnóstico

```bash
node 626.js --test
```

Mostra se o FFI (koffi) carregou, cada instância do Roblox com caminho e versão,
o PID usado e se o `OpenProcess` funcionou. Com o Helper rodando,
`http://127.0.0.1:7962/status` e `/debug` mostram o mesmo em JSON.

Se não detectar: confira se o Roblox está dentro de um jogo, se rodou `npm install`
e tente o `help.bat` como administrador.

## Como a injeção funciona (633.js)

1. **Sessão por processo:** PID + horário de criação do processo. Roblox fechado e
   aberto de novo (mesmo com o PID reaproveitado) = sessão nova; nada do processo
   anterior é reaproveitado.
2. **Tudo é validado antes de escrever:** tipo pelo prefixo do nome; valor estrito
   (`true/false`, inteiro de 32 bits, float finito, texto até 15 bytes — o resto é
   recusado, nunca vira 0); endereço alinhado e dentro do `RobloxPlayerBeta.exe`.
   Página de código ou sem acesso = offset errado = recusa. Página de dados só leitura:
   a proteção é liberada só nos bytes da flag, durante a escrita, e volta logo depois.
3. **Lote atômico:** se uma escrita falhar no meio de "Aplicar", as já feitas naquele
   lote são desfeitas. Nada fica pela metade.
4. **Valor original por endereço:** guardado no primeiro contato da sessão (nomes
   diferentes que apontam para a mesma flag compartilham o original).
5. **Valor igual não é reescrito;** toda escrita é conferida por leitura logo depois.
6. **Texto:** só textos curtos (buffer interno do `std::string`); texto longo no heap
   não é tocado, porque trocá-lo com o jogo lendo podia crashar.

## Sobre pausar (reverter flags)

Pausar (ou `/restore`) devolve os **bytes originais exatos**, na ordem inversa das
alterações, e só nas flags que o Helper alterou neste processo do Roblox.

| Situação | O que acontece ao pausar |
|---|---|
| Flag alterada pelo Helper | volta ao valor original exato (inclusive texto curto) |
| Flag do preset que não foi alterada | não é tocada |
| Roblox reaberto depois de aplicar | nada a pausar (o processo novo já está no padrão) |
| Helper reaberto com o Roblox já alterado | não sabe o original — reinicie o Roblox |

Nunca é escrito um "padrão" inventado (`false`/`0`): um valor que o jogo nunca teve
pode crashar o Roblox. Reiniciar o Roblox sempre restaura 100% dos valores padrão.

## O que o Helper grava no PC

**Nada.** Não cria arquivos, pastas, cache, logs nem usa AppData/Temp/Registro.
Offsets, ações, atalhos e valores originais ficam só na memória enquanto o Helper
está aberto. As mensagens do console aparecem apenas na janela do `help.bat`.
Para depurar: `GERENCIADOR_DEBUG=1 node 626.js` (mesmo assim nada é gravado).

## Problemas comuns

- **Ação não faz nada no jogo:** as ações só disparam com o Roblox em foco. Se o
  Roblox roda como administrador, o Helper também precisa.
- **"Versão incompatível":** o Roblox aberto não é da mesma versão dos offsets do
  site. Atualize o Roblox (feche e abra) ou aguarde o site atualizar os offsets.
- **"O Helper ainda não recebeu os offsets do site":** abra o site com o Helper aberto.

## Arquivos

| Arquivo | Função |
|---|---|
| `626.js` | servidor local, identificação do Roblox, chamadas do Windows, atalhos |
| `633.js` | motor de injeção: validação, lote atômico, valores originais, restauração |
| `521.js` | sistema de ações (gatilhos, execução, parada) |
| `592.js` | executa as ações (worker; SendInput) |
| `609.js` | hook global de mouse/scroll |
| `569.js` | mapa de teclas (código físico ↔ scancode/VK) |

## Novidades 2.4.1

- Corrige "nenhuma flag aplicada" no 2.4.0: páginas de dados só leitura voltam a ser
  aceitas (proteção liberada só durante a escrita e restaurada logo depois).
- A janela do `help.bat` mostra quantas flags foram aplicadas e o motivo de cada recusa.

## Novidades 2.4.0

- Novo motor de injeção (`633.js`), descrito em "Como a injeção funciona": sessão por
  processo, validação completa antes de escrever, lote atômico, originais por endereço,
  restauração exata (inclusive texto curto), `/restore` funcional.
- Pausar nunca escreve valores inventados; escrita só em páginas já graváveis.

## Novidades 2.3.0

- Sem internet: os offsets vêm somente do site (antes eram baixados pelo Helper).
- `startedAt` no `/status`, para o site reenviar a configuração quando o Helper reinicia.
- Mensagens claras quando os offsets ainda não foram recebidos.
