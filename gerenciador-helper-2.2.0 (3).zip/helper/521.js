/*
 * Sistema de macros do helper (thread principal).
 *
 *  - Guarda EM MEMÓRIA os macros enviados pelo site (POST /set-macros). O Helper
 *    não grava nada no PC: o site é a fonte da verdade e reenvia a cada sessão.
 *  - Dispara macros pelos gatilhos (tecla, botão do mouse, scroll), com os modos:
 *      once  → roda N vezes (apertar de novo durante a execução PARA)
 *      loop  → repete até apertar o gatilho de novo (ou a tecla de parada)
 *      hold  → repete enquanto o gatilho estiver pressionado
 *  - Tecla de parada global (padrão F8): para todos os macros e encerra gravação.
 *  - Gravação estilo TinyTask: recebe os eventos do hook (609.js) e
 *    converte em passos editáveis (trajetórias, cliques, teclas, scroll).
 *
 * Formato de macro (o mesmo do site / do código de compartilhamento):
 *   { id, name, enabled, trigger, mode, repeat, loopDelay, speed, robloxOnly, steps:[...] }
 * Passos: ver README.md (seção Macros).
 */
const path = require('path');
const { Worker } = require('worker_threads');
const { codeFromHook, SCROLL_CODES } = require('./569');

const MAX_REC_EVENTS = 300000;
const MAX_REC_MS = 15 * 60 * 1000;

function createMacroSystem(opts) {
  const {
    codeToVk, isWin, hasFfi, log = console.log, verbose = false,
    getForegroundPid = () => null, getRobloxPid = () => null, getCursor = null,
    beep = () => {},
  } = opts;
  // act(): atividade por-evento — só aparece no console em modo debug (nunca em arquivo).
  // log(): erros e mensagens essenciais — sempre.
  const act = (...a) => { if (verbose) log(...a); };

  // Configuração 100% EM MEMÓRIA — o site é a fonte da verdade e envia tudo via
  // /set-macros a cada sessão. O Helper não grava NADA no PC.
  let macros = [];
  let settings = { stopKey: 'F8' };

  // supressão de auto-disparo: VK -> nº de pressões injetadas em aberto / último instante
  const injHeldBuf = new SharedArrayBuffer(256 * 4);
  const injLastBuf = new SharedArrayBuffer(256 * 8);
  const injHeld = new Int32Array(injHeldBuf);
  const injLast = new Float64Array(injLastBuf);

  function setConfig(cfg) {
    const list = Array.isArray(cfg && cfg.macros) ? cfg.macros.map(sanitizeMacro).filter(Boolean) : [];
    const ids = new Set(list.map((m) => m.id));
    // macros removidos: para e descarta o worker
    for (const id of [...pool.keys()]) if (!ids.has(id) && id !== '__test__') disposePlayer(id);
    macros = list;
    // Lado do flick: mantém o lado escolhido nas ressincronizações do site; zera
    // para ações removidas ou que não têm mais botão de alternar.
    for (const id of [...sides.keys()]) { const m = macros.find((x) => x.id === id); if (!m || !m.sideKey) sides.delete(id); }
    if (cfg && cfg.settings) settings = sanitizeSettings(cfg.settings);
    return { count: macros.length, active: macros.filter((m) => m.enabled && m.trigger).length };
  }
  function getConfig() { return { settings, macros }; }

  // ───────── pool de players (1 worker por macro) ─────────
  const pool = new Map(); // id -> { worker, ctl, busy, runId, macroName, startedAt, onDone }
  let runSeq = 1;

  function getPlayer(id) {
    let p = pool.get(id);
    if (p) return p;
    const ctlBuf = new SharedArrayBuffer(16);
    const worker = new Worker(path.join(__dirname, '592.js'), {
      workerData: { ctl: ctlBuf, injHeld: injHeldBuf, injLast: injLastBuf, mock: !isWin },
    });
    p = { worker, ctl: new Int32Array(ctlBuf), busy: false, runId: 0, macroName: '', startedAt: 0, last: null };
    worker.on('message', (m) => {
      if (!m) return;
      if (m.type === 'done' && m.runId === p.runId) {
        p.busy = false;
        p.last = { ok: m.ok, reason: m.reason, iterations: m.iterations, error: m.error || null, at: Date.now(), mockLog: m.log || null };
        if (m.error) log(`  [ação] "${p.macroName}": ${m.error}`);
        else act(`  [ação] "${p.macroName}" ${m.reason} (${m.iterations}x)`);
      } else if (m.type === 'fatal') {
        log('  [ação] erro no player:', m.error);
      }
    });
    worker.on('error', (e) => { log('  [ação] worker caiu:', e.message); pool.delete(id); });
    worker.on('exit', () => { if (pool.get(id) === p) pool.delete(id); });
    pool.set(id, p);
    return p;
  }
  function disposePlayer(id) {
    const p = pool.get(id);
    if (!p) return;
    stop(id);
    pool.delete(id);
    p.worker.terminate().catch(() => {});
  }

  function isRunning(id) { const p = pool.get(id); return !!(p && p.busy); }

  function run(macro, { countdown = 0 } = {}) {
    const m = sanitizeMacro(macro);
    if (!m) return { ok: false, message: 'Ação inválida.' };
    if (!m.steps.length) return { ok: false, message: 'A ação não tem passos.' };
    if (!isWin) act('  [ação] (fora do Windows: execução simulada, nada é enviado ao sistema)');
    const p = getPlayer(m.id);
    if (p.busy) return { ok: false, message: 'Essa ação já está rodando.' };
    Atomics.store(p.ctl, 0, 0);
    p.busy = true; p.runId = runSeq++; p.macroName = m.name; p.startedAt = Date.now();
    p.worker.postMessage({ type: 'run', runId: p.runId, macro: m, countdown });
    return { ok: true, runId: p.runId, message: countdown > 0 ? `"${m.name}" começa em ${Math.round(countdown / 1000)}s.` : `"${m.name}" rodando.` };
  }
  function stop(id) {
    const p = pool.get(id);
    if (!p) return false;
    Atomics.store(p.ctl, 0, 1);
    Atomics.notify(p.ctl, 0);
    return p.busy;
  }
  function stopAll() {
    let n = 0;
    for (const id of pool.keys()) if (stop(id)) n++;
    return n;
  }

  // ───────── lado do flick ─────────
  // id -> -1 quando o lado está trocado (espelhado). Ausente = lado configurado.
  // Só em memória: o Helper reaberto volta ao lado configurado nas etapas.
  const sides = new Map();
  const lastSide = {};

  /** Sinal do movimento horizontal configurado (1 direita, -1 esquerda, 0 sem X). */
  function baseDir(m) {
    const f = m.steps.find((st) => st.t === 'flick' && Number(st.dx));
    return f ? Math.sign(Number(f.dx)) : 0;
  }
  function sideName(m) {
    const d = baseDir(m) * (sides.get(m.id) || 1);
    return d > 0 ? 'DIREITA' : d < 0 ? 'ESQUERDA' : (sides.get(m.id) === -1 ? 'trocado' : 'configurado');
  }
  /** Passos com o movimento horizontal espelhado (flick e movimento relativo). */
  function mirrored(m) {
    if (sides.get(m.id) !== -1) return m;
    return { ...m, steps: m.steps.map((st) => (st.t === 'flick' || (st.t === 'move' && st.rel)) && Number(st.dx) ? { ...st, dx: -Number(st.dx) } : st) };
  }
  function flipSide(m) {
    if (sides.get(m.id) === -1) sides.delete(m.id); else sides.set(m.id, -1);
    const name = sideName(m);
    // Agudo = direita (ou lado configurado), grave = esquerda (ou lado trocado).
    if (m.sideSound) beep(name === 'DIREITA' || name === 'configurado' ? 1200 : 600, 70);
    log(`  [ação] "${m.name}": lado do flick → ${name}`);
  }

  // ───────── gatilhos ─────────
  const lastFire = {};
  let robloxPidCache = { pid: null, at: 0 };
  function robloxFocused() {
    if (!hasFfi) return true;
    const now = Date.now();
    if (now - robloxPidCache.at > 2000) robloxPidCache = { pid: getRobloxPid(), at: now };
    const fg = getForegroundPid();
    return !!robloxPidCache.pid && fg === robloxPidCache.pid;
  }

  /** Códigos que o loop de polling precisa observar (gatilhos + tecla de parada). */
  function watchedCodes() {
    const s = new Set();
    for (const m of macros) if (m.enabled && m.trigger && !SCROLL_CODES.has(m.trigger)) s.add(m.trigger);
    for (const m of macros) if (m.enabled && m.sideKey && !SCROLL_CODES.has(m.sideKey)) s.add(m.sideKey);
    if (settings.stopKey) s.add(settings.stopKey);
    return s;
  }

  /** O polling chama isto: true = a borda deve ser ignorada (fomos nós que injetamos). */
  function isSelfInjected(code) {
    const vk = codeToVk(code);
    if (!vk || vk > 255) return false;
    return Atomics.load(injHeld, vk) > 0 || Date.now() - injLast[vk] < 150;
  }

  function onDown(code) {
    if (rec.state === 'recording' || rec.state === 'countdown') return; // gravando: só a parada vale (via hook)
    if (settings.stopKey && code === settings.stopKey) {
      const n = stopAll();
      if (n) act(`  [ação] tecla de parada (${code}): ${n} ação(ões) parada(s).`);
      return;
    }
    for (const m of macros) {
      if (!m.enabled || !m.sideKey || m.sideKey !== code) continue;
      const now = Date.now();
      if (now - (lastSide[m.id] || 0) < 150) continue; // bounce/repetição do botão
      lastSide[m.id] = now;
      if (m.robloxOnly && !robloxFocused()) continue;
      flipSide(m);
    }
    for (const m of macros) {
      if (!m.enabled || m.trigger !== code) continue;
      const now = Date.now();
      if (now - (lastFire[m.id] || 0) < 150) continue;
      lastFire[m.id] = now;
      if (isRunning(m.id)) {
        if (m.mode !== 'hold') { stop(m.id); act(`  [ação] "${m.name}" parado pelo gatilho.`); }
        continue;
      }
      if (m.robloxOnly && !robloxFocused()) continue;
      const ms = mirrored(m);
      const mm = SCROLL_CODES.has(code) && m.mode === 'hold' ? { ...ms, mode: 'once' } : ms;
      const r = run(mm);
      if (r.ok) act(`  [ação] ▶ "${m.name}" (${code})`);
    }
  }
  function onUp(code) {
    for (const m of macros) {
      if (m.enabled && m.mode === 'hold' && m.trigger === code && isRunning(m.id)) stop(m.id);
    }
  }

  // ───────── gravação ─────────
  let hook = null; // { shared: Int32Array, ready: bool }
  const rec = { state: 'idle', opts: null, events: [], startedAt: 0, timer: null, result: null, error: null };

  function attachHook(h) { hook = h; }

  function startRecording(o = {}) {
    if (!isWin) return { ok: false, message: 'Gravação só funciona no Windows.' };
    if (!hook || !hook.ready) return { ok: false, message: 'Hook global indisponível (veja o console do helper).' };
    if (rec.state === 'recording' || rec.state === 'countdown') return { ok: false, message: 'Já está gravando.' };
    stopAll();
    const opts = {
      moves: ['path', 'clicks', 'none'].includes(o.moves) ? o.moves : 'path',
      coords: o.coords === 'rel' ? 'rel' : 'abs',
      sampleMs: Math.min(200, Math.max(1, Number(o.sampleMs) || 10)),
      countdown: Math.min(10000, Math.max(0, Number(o.countdown) || 0)),
    };
    const stopVk = codeToVk(settings.stopKey) || 0x77;
    Object.assign(rec, { state: 'countdown', opts, events: [], startedAt: 0, result: null, error: null });
    clearTimeout(rec.timer);
    rec.timer = setTimeout(() => {
      if (rec.state !== 'countdown') return;
      Atomics.store(hook.shared, 1, stopVk);
      Atomics.store(hook.shared, 2, opts.moves === 'none' ? 0 : 1);
      Atomics.store(hook.shared, 0, 1);
      rec.state = 'recording';
      rec.startedAt = Date.now();
      act(`  [ação] ⏺ gravando… aperte ${settings.stopKey || 'F8'} para parar.`);
      rec.timer = setTimeout(() => { if (rec.state === 'recording') stopRecording('tempo máximo'); }, MAX_REC_MS);
    }, opts.countdown);
    return { ok: true, message: 'Gravação agendada.', stopKey: settings.stopKey };
  }

  function onRecEvent(ev) {
    if (rec.state !== 'recording') return;
    rec.events.push(ev);
    if (rec.events.length >= MAX_REC_EVENTS) stopRecording('limite de eventos');
  }

  function stopRecording(why = 'parado') {
    clearTimeout(rec.timer);
    if (hook) Atomics.store(hook.shared, 0, 0);
    if (rec.state === 'countdown') { rec.state = 'idle'; return { ok: true, cancelled: true, message: 'Gravação cancelada.' }; }
    if (rec.state !== 'recording') return { ok: false, message: 'Não há gravação em andamento.' };
    const steps = eventsToSteps(rec.events, rec.opts);
    rec.result = { steps, events: rec.events.length, durationMs: Date.now() - rec.startedAt, why, opts: rec.opts };
    rec.state = 'done';
    rec.events = [];
    act(`  [ação] ⏹ gravação encerrada (${why}): ${steps.length} passos.`);
    return { ok: true, ...rec.result };
  }

  function recordingStatus() {
    return {
      state: rec.state,
      events: rec.state === 'recording' ? rec.events.length : (rec.result ? rec.result.events : 0),
      elapsedMs: rec.state === 'recording' ? Date.now() - rec.startedAt : 0,
      stopKey: settings.stopKey,
      result: rec.state === 'done' ? rec.result : null,
    };
  }

  // ───────── estado / util ─────────
  function state() {
    const running = [];
    for (const [id, p] of pool) if (p.busy && id !== '__test__') running.push({ id, name: p.macroName, since: p.startedAt });
    const testing = pool.get('__test__');
    return {
      ok: true,
      running,
      testing: !!(testing && testing.busy),
      recording: { state: rec.state, events: rec.state === 'recording' ? rec.events.length : 0 },
      hookReady: !!(hook && hook.ready),
      count: macros.length,
      stopKey: settings.stopKey,
      simulated: !isWin,
      sides: Object.fromEntries(macros.filter((m) => m.sideKey).map((m) => [m.id, sideName(m)])),
    };
  }

  async function pickCursor(delayMs) {
    const d = Math.min(10000, Math.max(0, Number(delayMs) || 0));
    await new Promise((r) => setTimeout(r, d));
    if (!getCursor) return { ok: false, message: 'Só no Windows.' };
    const p = getCursor();
    return p ? { ok: true, x: p.x, y: p.y } : { ok: false, message: 'GetCursorPos falhou.' };
  }

  function shutdown() {
    stopAll();
    for (const p of pool.values()) p.worker.terminate().catch(() => {});
  }

  return {
    setConfig, getConfig, run, stop, stopAll, isRunning, state,
    watchedCodes, isSelfInjected, onDown, onUp,
    lastRun: (id) => { const p = pool.get(id); return p ? p.last : null; },
    attachHook, startRecording, stopRecording, recordingStatus, onRecEvent,
    pickCursor, shutdown,
  };
}

// ───────────── sanitização ─────────────

const STEP_TYPES = new Set(['flick', 'move', 'path', 'click', 'down', 'up', 'scroll', 'key', 'keydown', 'keyup', 'text', 'wait']);
const BTNS = new Set(['left', 'right', 'middle', 'back', 'forward']);
const n = (v, d = 0) => (Number.isFinite(Number(v)) ? Number(v) : d);

function sanitizeStep(s) {
  if (!s || typeof s !== 'object' || !STEP_TYPES.has(s.t)) return null;
  const o = { t: s.t };
  if (s.delay != null) o.delay = Math.max(0, n(s.delay));
  switch (s.t) {
    case 'move': o.x = Math.round(n(s.x)); o.y = Math.round(n(s.y)); if (s.rel) o.rel = true; if (s.dur) o.dur = Math.max(0, n(s.dur)); if (s.ease) o.ease = true; break;
    case 'flick': {
      o.btn = s.btn === 'none' ? 'none' : (BTNS.has(s.btn) ? s.btn : 'left');
      o.pre = Math.max(0, n(s.pre, 0));
      o.hold = Math.max(0, n(s.hold, 500));
      o.afterUp = Math.max(0, n(s.afterUp, 0));
      const lim = (v) => Math.min(100000, Math.max(-100000, Math.round(n(v, 0))));
      o.dx = lim(s.dx); o.dy = lim(s.dy);
      o.moveDur = Math.max(0, n(s.moveDur, 0));
      o.afterMove = Math.max(0, n(s.afterMove, 0));
      o.cooldown = Math.max(0, n(s.cooldown, 0));
      break;
    }
    case 'path': o.pts = Array.isArray(s.pts) ? s.pts.slice(0, 600000).map((v) => n(v)) : []; if (s.rel) o.rel = true; break;
    case 'click': o.btn = BTNS.has(s.btn) ? s.btn : 'left'; if (s.n != null) o.n = Math.max(1, Math.round(n(s.n, 1))); if (s.hold != null) o.hold = Math.max(0, n(s.hold)); if (s.gap != null) o.gap = Math.max(0, n(s.gap)); break;
    case 'down': case 'up': o.btn = BTNS.has(s.btn) ? s.btn : 'left'; break;
    case 'scroll': o.amount = Math.round(n(s.amount, 1)) || 1; if (s.gap != null) o.gap = Math.max(0, n(s.gap)); break;
    case 'key': o.code = String(s.code || ''); if (s.n != null) o.n = Math.max(1, Math.round(n(s.n, 1))); if (s.hold != null) o.hold = Math.max(0, n(s.hold)); if (s.gap != null) o.gap = Math.max(0, n(s.gap)); break;
    case 'keydown': case 'keyup': o.code = String(s.code || ''); break;
    case 'text': o.text = String(s.text ?? '').slice(0, 5000); if (s.gap != null) o.gap = Math.max(0, n(s.gap)); break;
    case 'wait': o.ms = Math.max(0, n(s.ms)); delete o.delay; break;
  }
  return o;
}

function sanitizeMacro(m) {
  if (!m || typeof m !== 'object') return null;
  const id = String(m.id || '').slice(0, 80) || ('m-' + Math.random().toString(36).slice(2, 10));
  return {
    id,
    name: String(m.name || 'Macro').slice(0, 80),
    enabled: m.enabled !== false,
    trigger: m.trigger ? String(m.trigger).slice(0, 40) : null,
    mode: ['once', 'loop', 'hold'].includes(m.mode) ? m.mode : 'once',
    repeat: Math.max(1, Math.round(n(m.repeat, 1))),
    loopDelay: Math.max(0, n(m.loopDelay, 0)),
    speed: Math.min(50, Math.max(0.05, n(m.speed, 1))),
    robloxOnly: !!m.robloxOnly,
    sideKey: m.sideKey && String(m.sideKey) !== String(m.trigger || '') ? String(m.sideKey).slice(0, 40) : null,
    sideSound: m.sideSound !== false,
    steps: (Array.isArray(m.steps) ? m.steps : []).slice(0, 20000).map(sanitizeStep).filter(Boolean),
  };
}

function sanitizeSettings(s) {
  return { stopKey: s && s.stopKey ? String(s.stopKey).slice(0, 40) : 'F8' };
}

// ───────────── gravação → passos ─────────────

/**
 * Converte eventos crus do hook em passos editáveis:
 *  - movimentos consecutivos viram UM passo "path" (trajetória), amostrado a cada `sampleMs`
 *  - mdown+mup do mesmo botão sem nada no meio (ou com tremidinha < 4px) viram "click" (com hold)
 *  - kdown+kup da mesma tecla sem nada no meio viram "key" (com hold)
 *  - ups sem down correspondente (tecla já segurada antes de gravar) são descartados
 *  - o "delay" de cada passo é o tempo desde o passo anterior (ms)
 */
function eventsToSteps(events, opts) {
  const o = { moves: 'path', coords: 'abs', sampleMs: 10, ...(opts || {}) };
  const evs = events.slice().sort((a, b) => a.t - b.t);
  // descarta ups órfãos
  const downK = new Set(), downB = new Set();
  const clean = [];
  for (const e of evs) {
    if (e.e === 'kdown') { downK.add(e.vk); clean.push(e); }
    else if (e.e === 'kup') { if (downK.delete(e.vk)) clean.push(e); }
    else if (e.e === 'mdown') { downB.add(e.btn); clean.push(e); }
    else if (e.e === 'mup') { if (downB.delete(e.btn)) clean.push(e); }
    else clean.push(e);
  }

  const raw = []; // passos com tempo absoluto: { at, step }
  let moveBuf = [];
  const flushMoves = () => {
    if (!moveBuf.length) return;
    if (o.moves === 'path') {
      const pts = [];
      let accDx = 0, accDy = 0, lastKeptT = null;
      for (let i = 0; i < moveBuf.length; i++) {
        const m = moveBuf[i];
        accDx += m.dx || 0; accDy += m.dy || 0;
        const isLast = i === moveBuf.length - 1;
        if (lastKeptT !== null && m.t - lastKeptT < o.sampleMs && !isLast) continue;
        if (o.coords === 'rel' && !accDx && !accDy && !isLast) continue;
        const dt = lastKeptT === null ? 0 : m.t - lastKeptT;
        if (o.coords === 'rel') { pts.push(dt, accDx, accDy); accDx = 0; accDy = 0; }
        else pts.push(dt, m.x, m.y);
        lastKeptT = m.t;
      }
      if (pts.length) raw.push({ at: moveBuf[0].t, step: { t: 'path', ...(o.coords === 'rel' ? { rel: true } : {}), pts } });
    }
    moveBuf = [];
  };

  for (let i = 0; i < clean.length; i++) {
    const e = clean[i];
    if (e.e === 'move') { if (o.moves === 'path') moveBuf.push(e); continue; }
    flushMoves();
    if (e.e === 'mdown') {
      // clique simples? procura o mup do mesmo botão, permitindo só tremidinha no meio
      let j = i + 1, jitter = true, mx = 0, my = 0;
      while (j < clean.length && clean[j].e === 'move') { mx += clean[j].dx || 0; my += clean[j].dy || 0; j++; }
      if (Math.abs(mx) > 3 || Math.abs(my) > 3) jitter = false;
      const up = clean[j];
      if (jitter && up && up.e === 'mup' && up.btn === e.btn && up.t - e.t <= 1500) {
        if (o.moves === 'clicks' && o.coords === 'abs') raw.push({ at: e.t, step: { t: 'move', x: e.x, y: e.y } });
        raw.push({ at: e.t, step: { t: 'click', btn: e.btn, hold: Math.max(0, up.t - e.t) } });
        i = j; continue;
      }
      if (o.moves === 'clicks' && o.coords === 'abs') raw.push({ at: e.t, step: { t: 'move', x: e.x, y: e.y } });
      raw.push({ at: e.t, step: { t: 'down', btn: e.btn } });
    } else if (e.e === 'mup') {
      if (o.moves === 'clicks' && o.coords === 'abs') raw.push({ at: e.t, step: { t: 'move', x: e.x, y: e.y } });
      raw.push({ at: e.t, step: { t: 'up', btn: e.btn } });
    } else if (e.e === 'wheel') {
      const notches = Math.round(e.delta / 120) || (e.delta > 0 ? 1 : -1);
      const prev = raw[raw.length - 1];
      // junta "cliques" de roda seguidos (até 120ms entre eles) num passo só
      if (prev && prev.step.t === 'scroll' && Math.sign(prev.step.amount) === Math.sign(notches) && e.t - prev.lastAt <= 120) {
        prev.step.amount += notches; prev.lastAt = e.t;
        prev.step.gap = Math.round((prev.lastAt - prev.at) / Math.max(1, Math.abs(prev.step.amount) - 1));
      } else raw.push({ at: e.t, lastAt: e.t, step: { t: 'scroll', amount: notches } });
    } else if (e.e === 'kdown') {
      const code = codeFromHook(e.vk, e.scan, e.ext);
      const nx = clean[i + 1];
      if (nx && nx.e === 'kup' && nx.vk === e.vk && nx.t - e.t <= 1500) {
        raw.push({ at: e.t, step: { t: 'key', code, hold: Math.max(0, nx.t - e.t) } });
        i++; continue;
      }
      raw.push({ at: e.t, step: { t: 'keydown', code } });
    } else if (e.e === 'kup') {
      raw.push({ at: e.t, step: { t: 'keyup', code: codeFromHook(e.vk, e.scan, e.ext) } });
    }
  }
  flushMoves();

  // tempos absolutos → delay relativo ao FIM do passo anterior
  const steps = [];
  let cursor = raw.length ? raw[0].at : 0;
  for (const r of raw) {
    const s = r.step;
    const delay = Math.max(0, Math.round(r.at - cursor));
    if (delay) s.delay = delay;
    steps.push(s);
    cursor = r.at + stepSpan(s);
  }
  return steps;
}

function stepSpan(s) {
  if (s.t === 'path') { let ms = 0; for (let i = 0; i < s.pts.length; i += 3) ms += s.pts[i]; return ms; }
  if (s.t === 'click' || s.t === 'key') return s.hold || 0;
  if (s.t === 'scroll') return (Math.abs(s.amount) - 1) * (s.gap || 0);
  return 0;
}

module.exports = { createMacroSystem, sanitizeMacro, eventsToSteps };
