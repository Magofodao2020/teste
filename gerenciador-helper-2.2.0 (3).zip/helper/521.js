/*
 * Executor de ações (macros) do Helper — thread principal. Versão 3.
 *
 * Um único lugar decide TUDO sobre as ações: quem dispara, quando, em qual
 * worker, o que acontece se apertar de novo, quem interrompe quem, e registra o
 * resultado. O site só configura e mostra; nunca executa nada.
 *
 *  - Configuração 100% EM MEMÓRIA (POST /set-macros). Nada é gravado no PC.
 *  - Pool de workers (592.js) PRÉ-AQUECIDOS: o primeiro acionamento não espera
 *    criar thread nem carregar o FFI. Cada worker guarda as definições das
 *    ações já carregadas (por versão), então cada execução manda só um "run"
 *    pequeno — nada de copiar etapas a cada aperto.
 *  - Modos: once (N repetições), loop (liga/desliga), hold (enquanto segura),
 *    mirror ("segurar junto": aperta ao apertar, solta ao soltar).
 *  - Temporização: delay inicial, delay entre etapas, delay antes/depois de cada
 *    etapa, delay entre repetições, delay final. 0 ms = sem espera nenhuma.
 *  - Apertar de novo durante a execução (modo "uma vez"): parar | reiniciar | ignorar.
 *  - Grupos com prioridade: ações do mesmo grupo não rodam juntas; a de prioridade
 *    maior interrompe a menor; empate segue a política (interromper | bloquear | fila).
 *  - Tecla de parada global e tecla de parada por ação; combinações Ctrl/Shift/Alt.
 *  - Histórico em memória (anel) com latência real: gatilho → 1ª entrada enviada,
 *    duração planejada × real, atraso máximo/médio das esperas e travadas.
 *  - Gravação estilo TinyTask (eventos do hook 609.js → etapas editáveis).
 */
const path = require('path');
const { Worker } = require('worker_threads');
const { codeFromHook, SCROLL_CODES, keyInfo, VK_STATIC } = require('./569');

const MAX_REC_EVENTS = 300000;
const MAX_REC_MS = 15 * 60 * 1000;
const MAX_WORKERS = 16;   // execuções simultâneas
const WARM_WORKERS = 2;   // prontos antes do primeiro aperto
const KEEP_IDLE = 4;      // workers ociosos mantidos (o resto é encerrado)
const HISTORY_MAX = 300;
const QUEUE_MAX = 10;     // por grupo
const nowAbs = () => performance.timeOrigin + performance.now(); // relógio monotônico, comum a todas as threads

function createMacroSystem(opts) {
  const {
    codeToVk, isWin, hasFfi, log = console.log, verbose = false,
    getForegroundPid = () => null, getRobloxPid = () => null, getCursor = null,
    beep = () => {}, modsDown = () => ({ ctrl: false, shift: false, alt: false }),
  } = opts;
  // act(): atividade por-evento — só no console em modo debug (nunca em arquivo).
  const act = (...a) => { if (verbose) log(...a); };

  let macros = [];
  let byId = new Map();
  let settings = { stopKey: 'F8', history: true };

  // supressão de auto-disparo (polling): VK -> nº de pressões injetadas em aberto / último instante
  const injHeldBuf = new SharedArrayBuffer(256 * 4);
  const injLastBuf = new SharedArrayBuffer(256 * 8);
  const injHeld = new Int32Array(injHeldBuf);
  const injLast = new Float64Array(injLastBuf);

  function setConfig(cfg) {
    const list = Array.isArray(cfg && cfg.macros) ? cfg.macros.map(sanitizeMacro).filter(Boolean) : [];
    const seen = new Set();
    macros = list.filter((m) => (seen.has(m.id) ? false : (seen.add(m.id), true)));
    for (const m of macros) m.ver = fingerprint(m);
    byId = new Map(macros.map((m) => [m.id, m]));
    // ações removidas ou desativadas: param agora
    for (const [id, r] of running) { const m = byId.get(id); if (id !== '__test__' && (!m || !m.enabled)) stopRun(r); }
    for (const id of [...sides.keys()]) { const m = byId.get(id); if (!m || !m.sideKey) sides.delete(id); }
    for (const g of [...groupQueues.keys()]) groupQueues.set(g, groupQueues.get(g).filter((q) => byId.has(q.m.id)));
    if (cfg && cfg.settings) settings = sanitizeSettings(cfg.settings);
    warmUp();
    return { count: macros.length, active: macros.filter((m) => m.enabled && m.trigger).length };
  }
  function getConfig() { return { settings, macros: macros.map(({ ver: _v, ...m }) => m) }; }

  // ───────── pool de workers ─────────
  const workers = [];          // { w, ctl, busy, runId, macroId, loaded: Map(id→ver), ready }
  const running = new Map();   // macroId -> { wk, runId, m, startedAt, trigAt, ctx }
  const lastRuns = new Map();  // macroId -> último resultado (testes / diagnóstico)
  const pendingRestart = new Map(); // macroId -> ctx (reiniciar depois de parar)
  const groupQueues = new Map();    // grupo -> [{ m, ctx }]
  let runSeq = 1;

  function spawn() {
    const ctlBuf = new SharedArrayBuffer(16);
    const w = new Worker(path.join(__dirname, '592.js'), {
      workerData: { ctl: ctlBuf, injHeld: injHeldBuf, injLast: injLastBuf, mock: !isWin },
    });
    const wk = { w, ctl: new Int32Array(ctlBuf), busy: false, runId: 0, macroId: null, loaded: new Map(), dead: false };
    w.on('message', (msg) => onWorkerMessage(wk, msg));
    w.on('error', (e) => { log('  [ação] worker caiu:', e.message); retire(wk, 'erro: ' + e.message); });
    w.on('exit', () => retire(wk, 'worker encerrado'));
    workers.push(wk);
    return wk;
  }
  function retire(wk, why) {
    if (wk.dead) return;
    wk.dead = true;
    const i = workers.indexOf(wk);
    if (i >= 0) workers.splice(i, 1);
    if (wk.busy && wk.macroId) finish(wk.macroId, wk.runId, { ok: false, reason: 'erro', error: why, iterations: 0 });
  }
  /** Workers prontos antes do 1º aperto + definições das ações ativas já carregadas. */
  function warmUp() {
    const want = macros.some((m) => m.enabled && m.trigger) ? WARM_WORKERS : 0;
    while (workers.length < want) spawn();
    let budget = 20000; // etapas: não copia gravações gigantes para todos
    for (const m of macros) {
      if (!m.enabled || !m.trigger) continue;
      for (const wk of workers) {
        if (budget <= 0) break;
        if (!wk.busy && wk.loaded.get(m.id) !== m.ver) { load(wk, m); budget -= m.steps.length; }
      }
    }
  }
  function load(wk, m) {
    wk.w.postMessage({ type: 'load', id: m.id, ver: m.ver, macro: m });
    wk.loaded.set(m.id, m.ver);
  }
  function pickWorker(m) {
    let free = null;
    for (const wk of workers) {
      if (wk.busy || wk.dead) continue;
      if (wk.loaded.get(m.id) === m.ver) return wk;
      if (!free) free = wk;
    }
    if (free) return free;
    return workers.length < MAX_WORKERS ? spawn() : null;
  }

  function onWorkerMessage(wk, msg) {
    if (!msg) return;
    if (msg.type === 'done') { if (msg.runId === wk.runId) finish(wk.macroId, msg.runId, msg); }
    else if (msg.type === 'fatal') log('  [ação] erro no player:', msg.error);
  }

  // ───────── execução ─────────

  /**
   * Inicia uma execução (já decidido que deve rodar). ctx: { countdown, trigAt,
   * mirror, mode, code }. Devolve { ok, message }.
   */
  function startRun(m, ctx = {}) {
    if (!m.steps.length) return { ok: false, message: 'A ação não tem etapas.' };
    if (running.has(m.id)) return { ok: false, message: 'Essa ação já está rodando.' };
    const wk = pickWorker(m);
    if (!wk) { record(m, { result: 'bloqueada', error: `limite de ${MAX_WORKERS} execuções simultâneas` }); return { ok: false, message: `Limite de ${MAX_WORKERS} execuções simultâneas.` }; }
    if (wk.loaded.get(m.id) !== m.ver) load(wk, m);
    Atomics.store(wk.ctl, 0, 0);
    wk.busy = true; wk.runId = runSeq++; wk.macroId = m.id;
    const r = { wk, runId: wk.runId, m, startedAt: Date.now(), trigAt: ctx.trigAt || nowAbs(), ctx };
    running.set(m.id, r);
    wk.w.postMessage({
      type: 'run', runId: wk.runId, id: m.id, ver: m.ver,
      countdown: ctx.countdown || 0, mirror: !!ctx.mirror, mode: ctx.mode || null,
    });
    act(`  [ação] ▶ "${m.name}"${ctx.code ? ` (${ctx.code})` : ''}`);
    return { ok: true, runId: wk.runId, message: ctx.countdown > 0 ? `"${m.name}" começa em ${Math.round(ctx.countdown / 1000)}s.` : `"${m.name}" rodando.` };
  }

  function stopRun(r) {
    Atomics.store(r.wk.ctl, 0, 1);
    Atomics.notify(r.wk.ctl, 0);
  }

  function finish(macroId, runId, msg) {
    const r = running.get(macroId);
    if (!r || r.runId !== runId) return; // callback antigo: ignora
    running.delete(macroId);
    const wk = r.wk;
    wk.busy = false; wk.macroId = null;
    const st = msg.stats || {};
    const result = msg.error ? 'erro' : msg.reason === 'parado' ? 'parada' : msg.reason === 'solto' ? 'solta' : 'concluída';
    const entry = record(r.m, {
      result, error: msg.error || null, iterations: msg.iterations || 0,
      ms: Math.round(((st.endAt || nowAbs()) - (st.startAt || r.trigAt)) * 10) / 10,
      latency: st.firstAt ? Math.round((st.firstAt - r.trigAt) * 100) / 100 : null,
      steps: st.steps || 0, planned: st.plannedMs != null ? Math.round(st.plannedMs) : null,
      lateMax: st.lateMax != null ? Math.round(st.lateMax * 100) / 100 : null,
      lateAvg: st.lateAvg != null ? Math.round(st.lateAvg * 100) / 100 : null,
      stalls: st.stalls || 0, at: r.startedAt,
    });
    lastRuns.set(macroId, { ...entry, ok: msg.ok, reason: msg.reason, mockLog: msg.log || null });
    if (msg.error) log(`  [ação] "${r.m.name}": ${msg.error}`);
    else act(`  [ação] "${r.m.name}" ${msg.reason} (${msg.iterations}x)`);
    // encerra workers ociosos sobrando
    if (workers.filter((x) => !x.busy).length > KEEP_IDLE) { wk.dead = true; workers.splice(workers.indexOf(wk), 1); wk.w.terminate().catch(() => {}); }
    // reiniciar (re-acionamento "reiniciar")
    const again = pendingRestart.get(macroId);
    if (again) { pendingRestart.delete(macroId); const m = byId.get(macroId); if (m && m.enabled) begin(m, again); }
    // fila do grupo
    if (r.m.group) drainGroup(r.m.group);
  }

  function drainGroup(group) {
    const q = groupQueues.get(group);
    if (!q || !q.length) return;
    if ([...running.values()].some((x) => x.m.group === group)) return;
    const next = q.shift();
    const m = byId.get(next.m.id);
    if (m && m.enabled) startRun(m, next.ctx);
  }

  /** Grupo + prioridade: decide se inicia, interrompe outras, bloqueia ou entra na fila. */
  function begin(m, ctx) {
    if (m.group) {
      const others = [...running.values()].filter((x) => x.m.group === m.group && x.m.id !== m.id);
      const higher = others.some((x) => x.m.priority > m.priority);
      const equal = others.some((x) => x.m.priority === m.priority);
      const policy = m.groupPolicy;
      if (higher || (equal && policy !== 'interrupt')) {
        if (policy === 'queue') {
          const q = groupQueues.get(m.group) || [];
          if (!q.some((x) => x.m.id === m.id) && q.length < QUEUE_MAX) q.push({ m, ctx });
          groupQueues.set(m.group, q);
          act(`  [ação] "${m.name}" na fila do grupo "${m.group}".`);
          return { ok: true, queued: true, message: `"${m.name}" na fila.` };
        }
        record(m, { result: 'bloqueada', error: `grupo "${m.group}" ocupado por ${others.map((x) => x.m.name).join(', ')}` });
        return { ok: false, message: `"${m.name}" bloqueada: grupo "${m.group}" ocupado.` };
      }
      for (const x of others) stopRun(x); // prioridade menor (ou empate com "interromper")
    }
    return startRun(m, ctx);
  }

  /** Execução pedida pelo site (Testar) — mesmo motor, macro avulsa. */
  function run(macro, { countdown = 0 } = {}) {
    const m = sanitizeMacro(macro);
    if (!m) return { ok: false, message: 'Ação inválida.' };
    if (!m.steps.length) return { ok: false, message: 'A ação não tem passos.' };
    m.ver = fingerprint(m) + ':' + runSeq;
    if (!isWin) act('  [ação] (fora do Windows: execução simulada, nada é enviado ao sistema)');
    if (running.has(m.id)) return { ok: false, message: 'Essa ação já está rodando.' };
    return startRun(m, { countdown, trigAt: nowAbs() });
  }
  function stop(id) {
    const r = running.get(id);
    pendingRestart.delete(id);
    if (!r) return false;
    stopRun(r);
    return true;
  }
  function stopAll() {
    pendingRestart.clear();
    for (const q of groupQueues.values()) q.length = 0;
    let n = 0;
    for (const r of running.values()) { stopRun(r); n++; }
    return n;
  }
  function isRunning(id) { return running.has(id); }

  // ───────── histórico ─────────
  const history = [];
  let histSeq = 0;
  function record(m, data) {
    const entry = { seq: ++histSeq, id: m.id, name: m.name, at: Date.now(), ...data };
    if (settings.history !== false) {
      history.push(entry);
      if (history.length > HISTORY_MAX) history.splice(0, history.length - HISTORY_MAX);
    }
    return entry;
  }
  function getHistory(since = 0) {
    const s = Number(since) || 0;
    return { seq: histSeq, items: history.filter((h) => h.seq > s) };
  }
  function clearHistory() { history.length = 0; return { ok: true }; }

  // ───────── lado do flick ─────────
  // id -> -1 quando o lado está trocado (espelhado). Ausente = lado configurado.
  const sides = new Map();
  const lastSide = {};
  function baseDir(m) {
    const f = m.steps.find((st) => st.t === 'flick' && Number(st.dx));
    return f ? Math.sign(Number(f.dx)) : 0;
  }
  function sideName(m) { return baseDir(m) * (sides.get(m.id) || 1) > 0 ? 'DIREITA' : 'ESQUERDA'; }
  function flipSide(m) {
    if (sides.get(m.id) === -1) sides.delete(m.id); else sides.set(m.id, -1);
    const name = sideName(m);
    if (m.sideSound) beep(name === 'DIREITA' ? 1200 : 600, 70); // agudo = direita, grave = esquerda
    log(`  [ação] "${m.name}": lado do flick → ${name}`);
  }

  // ───────── foco / combinações ─────────
  let robloxPidCache = { pid: null, at: 0 };
  function robloxFocused() {
    if (!hasFfi) return true;
    const now = Date.now();
    if (now - robloxPidCache.at > 2000) robloxPidCache = { pid: getRobloxPid(), at: now };
    const fg = getForegroundPid();
    return !!robloxPidCache.pid && fg === robloxPidCache.pid;
  }
  function modsOk(m) {
    if (!m.mods.length) return true;
    const d = modsDown();
    return m.mods.every((k) => d[k]);
  }

  // ───────── Gagatech / "segurar junto" direto no hook ─────────
  const BTN_SLOT = { MouseBack: 1, MouseForward: 2, MouseMiddle: 3 };
  /**
   * Ações "segurar junto" que o PRÓPRIO hook do Windows executa (como o
   * Gagatech.py): ativa, modo mirror, sem "só no Roblox", sem combinação,
   * gatilho lateral/meio e uma única etapa "teclas juntas" (até 4, sem espera).
   * Retorna { [slot]: { keys:[{vk,scan,ext}], block } } (1 ◄, 2 ►, 3 meio).
   */
  function directChords(ids) {
    const out = {};
    for (const m of macros) {
      if (!m.enabled || m.mode !== 'mirror' || m.robloxOnly || m.mods.length) continue;
      const slot = BTN_SLOT[m.trigger] || 0;
      if (!slot || out[slot]) continue;
      const st = m.steps.filter((s) => !s.off);
      if (st.length !== 1 || st[0].t !== 'keysdown' || st[0].delay || m.startDelay) continue;
      const codes = st[0].codes || [];
      if (!codes.length || codes.length > 4) continue;
      const keys = codes.map((c) => { const i = keyInfo(c); return i ? { vk: i.vk || VK_STATIC[c] || 0, scan: i.scan, ext: i.ext ? 1 : 0 } : null; });
      if (keys.some((k) => !k)) continue;
      out[slot] = { keys, block: m.blockTrigger };
      if (ids) ids.set(m.id, slot);
    }
    return out;
  }
  /** Por que uma ação NÃO roda direto no hook (para o site mostrar). null = roda direto. */
  function directReason(m) {
    if (m.mode !== 'mirror') return 'o modo não é "Segurar junto"';
    if (!BTN_SLOT[m.trigger]) return 'o gatilho não é um lateral nem o botão do meio';
    if (m.robloxOnly) return '"Só com o Roblox em foco" está ligado';
    if (m.mods.length) return 'tem combinação (Ctrl/Shift/Alt)';
    const st = m.steps.filter((s) => !s.off);
    if (st.length !== 1 || st[0].t !== 'keysdown') return 'precisa de uma única etapa "Apertar teclas juntas"';
    if (st[0].delay || m.startDelay) return 'tem espera antes das teclas';
    if (!(st[0].codes || []).length || st[0].codes.length > 4) return 'precisa de 1 a 4 teclas';
    if (!m.enabled) return 'está desativada';
    const ids = new Map(); directChords(ids);
    if (!ids.has(m.id)) return 'outra ação "segurar junto" já usa esse botão';
    if (!hook || !hook.ready) return 'o hook do Windows não está ativo';
    return null;
  }
  const ownerWarned = new Set();
  function directOwner(code) {
    if (!hook || !hook.ready || !BTN_SLOT[code]) return null;
    const ids = new Map();
    directChords(ids);
    const owner = macros.find((m) => ids.has(m.id) && m.trigger === code) || null;
    if (owner) {
      for (const m of macros) {
        if (m === owner || !m.enabled || m.trigger !== code) continue;
        const k = owner.id + '|' + m.id;
        if (!ownerWarned.has(k)) { ownerWarned.add(k); log(`  [ação] "${m.name}" está no mesmo botão de "${owner.name}" e foi ignorada (esse botão é só de "${owner.name}"). Troque o botão de uma delas no site.`); }
      }
    }
    return owner;
  }
  // Contadores da execução direta (o hook avisa cada apertar/soltar).
  const direct = { 1: null, 2: null, 3: null };
  function onDirect(ev) {
    const slot = ev.which;
    const ids = new Map(); directChords(ids);
    let m = null;
    for (const [id, s] of ids) if (s === slot) m = byId.get(id);
    const d = direct[slot] || (direct[slot] = { presses: 0, fails: 0, held: false, last: 0, name: '' });
    d.name = m ? m.name : d.name;
    d.held = !!ev.down;
    d.last = Date.now();
    if (ev.down) d.presses++;
    if (ev.sent !== ev.n) d.fails++;
    if (ev.down && m) record(m, { result: ev.sent === ev.n ? 'direto' : 'erro', error: ev.sent === ev.n ? null : `o Windows aceitou ${ev.sent}/${ev.n} teclas`, latency: 0, steps: 1, ms: 0, iterations: 1 });
    return { m, ...d };
  }

  /** Laterais/meio que o hook deve BLOQUEAR para ações "segurar junto" que não rodam direto. */
  function blockedButtons() {
    let mask = 0;
    for (const m of macros) {
      if (!m.enabled || m.mode !== 'mirror' || !m.blockTrigger) continue;
      if (m.trigger === 'MouseBack') mask |= 1;
      if (m.trigger === 'MouseForward') mask |= 2;
      if (m.trigger === 'MouseMiddle') mask |= 4;
    }
    return mask;
  }

  /** Códigos que precisam ser observados (gatilhos, paradas, lado). */
  function watchedCodes() {
    const s = new Set();
    for (const m of macros) {
      if (!m.enabled) continue;
      for (const c of [m.trigger, m.sideKey, m.stopKey]) if (c && !SCROLL_CODES.has(c)) s.add(c);
    }
    if (settings.stopKey) s.add(settings.stopKey);
    return s;
  }

  /** O polling chama isto: true = a borda deve ser ignorada (fomos nós que injetamos). */
  function isSelfInjected(code) {
    const vk = codeToVk(code);
    if (!vk || vk > 255) return false;
    return Atomics.load(injHeld, vk) > 0 || Date.now() - injLast[vk] < 150;
  }

  // ───────── gatilhos ─────────
  const lastFire = {};
  /** at: instante (relógio absoluto) em que o Windows entregou o evento. */
  function onDown(code, at) {
    const trigAt = at || nowAbs();
    if (rec.state === 'recording' || rec.state === 'countdown') return; // gravando: só a parada vale (via hook)
    if (settings.stopKey && code === settings.stopKey) {
      const n = stopAll();
      if (n) act(`  [ação] tecla de parada (${code}): ${n} ação(ões) parada(s).`);
      return;
    }
    // tecla de parada da própria ação
    for (const m of macros) if (m.stopKey === code && running.has(m.id)) { stop(m.id); act(`  [ação] "${m.name}" parada pela tecla de parada da ação.`); }
    const owner = directOwner(code);
    for (const m of macros) {
      if (!m.enabled || !m.sideKey || m.sideKey !== code) continue;
      const now = Date.now();
      if (now - (lastSide[m.id] || 0) < 150) continue; // bounce/repetição do botão
      lastSide[m.id] = now;
      if (m.robloxOnly && !robloxFocused()) continue;
      flipSide(m);
    }
    if (owner) return; // o hook já apertou as teclas; o botão é só da ação direta
    let focus = null; // consultado no máximo uma vez por evento
    for (const m of macros) {
      if (!m.enabled || m.trigger !== code || !modsOk(m)) continue;
      const now = Date.now();
      // trava anti-repetição só para "uma vez"/"loop" (bounce do botão); 0 = desligada
      if ((m.mode === 'once' || m.mode === 'loop') && m.debounce && now - (lastFire[m.id] || 0) < m.debounce) continue;
      lastFire[m.id] = now;
      if (running.has(m.id)) {
        if (m.mode === 'loop') { stop(m.id); act(`  [ação] "${m.name}" parada pelo gatilho.`); }
        else if (m.mode === 'once') {
          if (m.onRetrigger === 'stop') stop(m.id);
          else if (m.onRetrigger === 'restart') { stop(m.id); pendingRestart.set(m.id, { trigAt, code, mirror: sides.get(m.id) === -1 }); }
        }
        continue; // hold/mirror: já está segurando
      }
      if (m.robloxOnly) { if (focus === null) focus = robloxFocused(); if (!focus) continue; }
      // Scroll não tem "soltar": segurar/segurar junto vira uma execução só.
      const mode = SCROLL_CODES.has(code) && (m.mode === 'hold' || m.mode === 'mirror') ? 'once' : null;
      begin(m, { trigAt, code, mirror: sides.get(m.id) === -1, mode });
    }
  }
  function onUp(code) {
    for (const m of macros) {
      if (m.enabled && (m.mode === 'hold' || m.mode === 'mirror') && m.trigger === code) {
        if (running.has(m.id)) stop(m.id);
        // soltou antes da vez na fila: sai da fila
        if (m.group) { const q = groupQueues.get(m.group); if (q) groupQueues.set(m.group, q.filter((x) => x.m.id !== m.id)); }
      }
    }
  }

  // ───────── gravação ─────────
  let hook = null; // { shared: Int32Array, ready: bool }
  const rec = { state: 'idle', opts: null, events: [], startedAt: 0, timer: null, result: null, error: null };

  function attachHook(h) { hook = h; }

  function startRecording(o = {}) {
    if (!isWin) return { ok: false, message: 'Gravação só funciona no Windows.' };
    if (!hook || !hook.ready) return { ok: false, message: 'Hook global indisponível (veja o console do helper).' };
    if (rec.state === 'recording' || rec.state === 'countdown') return { ok: false, message: 'Já está gravando.' };
    stopAll();
    const opts = {
      moves: ['path', 'clicks', 'none'].includes(o.moves) ? o.moves : 'path',
      coords: o.coords === 'rel' ? 'rel' : 'abs',
      sampleMs: Math.min(200, Math.max(1, Number(o.sampleMs) || 10)),
      countdown: Math.min(10000, Math.max(0, Number(o.countdown) || 0)),
    };
    const stopVk = codeToVk(settings.stopKey) || 0x77;
    Object.assign(rec, { state: 'countdown', opts, events: [], startedAt: 0, result: null, error: null });
    clearTimeout(rec.timer);
    rec.timer = setTimeout(() => {
      if (rec.state !== 'countdown') return;
      Atomics.store(hook.shared, 1, stopVk);
      Atomics.store(hook.shared, 2, opts.moves === 'none' ? 0 : 1);
      Atomics.store(hook.shared, 0, 1);
      rec.state = 'recording';
      rec.startedAt = Date.now();
      act(`  [ação] ⏺ gravando… aperte ${settings.stopKey || 'F8'} para parar.`);
      rec.timer = setTimeout(() => { if (rec.state === 'recording') stopRecording('tempo máximo'); }, MAX_REC_MS);
    }, opts.countdown);
    return { ok: true, message: 'Gravação agendada.', stopKey: settings.stopKey };
  }

  function onRecEvent(ev) {
    if (rec.state !== 'recording') return;
    rec.events.push(ev);
    if (rec.events.length >= MAX_REC_EVENTS) stopRecording('limite de eventos');
  }

  function stopRecording(why = 'parado') {
    clearTimeout(rec.timer);
    if (hook) Atomics.store(hook.shared, 0, 0);
    if (rec.state === 'countdown') { rec.state = 'idle'; return { ok: true, cancelled: true, message: 'Gravação cancelada.' }; }
    if (rec.state !== 'recording') return { ok: false, message: 'Não há gravação em andamento.' };
    const steps = eventsToSteps(rec.events, rec.opts);
    rec.result = { steps, events: rec.events.length, durationMs: Date.now() - rec.startedAt, why, opts: rec.opts };
    rec.state = 'done';
    rec.events = [];
    act(`  [ação] ⏹ gravação encerrada (${why}): ${steps.length} passos.`);
    return { ok: true, ...rec.result };
  }

  function recordingStatus() {
    return {
      state: rec.state,
      events: rec.state === 'recording' ? rec.events.length : (rec.result ? rec.result.events : 0),
      elapsedMs: rec.state === 'recording' ? Date.now() - rec.startedAt : 0,
      stopKey: settings.stopKey,
      result: rec.state === 'done' ? rec.result : null,
    };
  }

  // ───────── estado / util ─────────
  function state() {
    const run = [];
    for (const [id, r] of running) if (id !== '__test__') run.push({ id, name: r.m.name, since: r.startedAt });
    const queued = [];
    for (const [g, q] of groupQueues) for (const x of q) queued.push({ id: x.m.id, name: x.m.name, group: g });
    const directInfo = {};
    const ids = new Map(); directChords(ids);
    for (const [id, slot] of ids) {
      const d = direct[slot] || { presses: 0, fails: 0, held: false, last: 0 };
      directInfo[id] = { slot, presses: d.presses, fails: d.fails, held: d.held, last: d.last };
    }
    const why = {};
    for (const m of macros) if (m.mode === 'mirror') why[m.id] = directReason(m);
    return {
      ok: true,
      running: run,
      queued,
      testing: running.has('__test__'),
      recording: { state: rec.state, events: rec.state === 'recording' ? rec.events.length : 0 },
      hookReady: !!(hook && hook.ready),
      count: macros.length,
      workers: { total: workers.length, busy: workers.filter((w) => w.busy).length, max: MAX_WORKERS },
      stopKey: settings.stopKey,
      simulated: !isWin,
      sides: Object.fromEntries(macros.filter((m) => m.sideKey).map((m) => [m.id, sideName(m)])),
      direct: directInfo,
      directWhy: why,
      historySeq: histSeq,
    };
  }

  async function pickCursor(delayMs) {
    const d = Math.min(10000, Math.max(0, Number(delayMs) || 0));
    await new Promise((r) => setTimeout(r, d));
    if (!getCursor) return { ok: false, message: 'Só no Windows.' };
    const p = getCursor();
    return p ? { ok: true, x: p.x, y: p.y } : { ok: false, message: 'GetCursorPos falhou.' };
  }

  function shutdown() {
    stopAll();
    for (const wk of workers) wk.w.terminate().catch(() => {});
  }

  return {
    setConfig, getConfig, run, stop, stopAll, isRunning, state,
    watchedCodes, isSelfInjected, onDown, onUp, onDirect,
    blockedButtons, blockedXButtons: blockedButtons, directChords, directReason,
    getHistory, clearHistory,
    lastRun: (id) => lastRuns.get(id) || null,
    attachHook, startRecording, stopRecording, recordingStatus, onRecEvent,
    pickCursor, shutdown,
  };
}

// ───────────── sanitização (mesmas regras do site: core/macros.ts) ─────────────

const STEP_TYPES = new Set(['flick', 'move', 'path', 'click', 'down', 'up', 'scroll', 'key', 'keydown', 'keyup', 'keysdown', 'text', 'wait']);
const BTNS = new Set(['left', 'right', 'middle', 'back', 'forward']);
const MODS = ['ctrl', 'shift', 'alt'];
const n = (v, d = 0) => (Number.isFinite(Number(v)) ? Number(v) : d);
const ms = (v, d = 0) => Math.min(3600000, Math.max(0, n(v, d))); // 0 ms a 1 h
const code = (v) => (v && /^[A-Za-z0-9_]{1,40}$/.test(String(v)) ? String(v) : null);

function sanitizeStep(s) {
  if (!s || typeof s !== 'object' || !STEP_TYPES.has(s.t)) return null;
  const o = { t: s.t };
  if (s.delay != null && s.t !== 'wait') o.delay = ms(s.delay);
  if (s.after != null && n(s.after) > 0) o.after = ms(s.after);
  if (s.off) o.off = true;
  switch (s.t) {
    case 'move': o.x = Math.round(n(s.x)); o.y = Math.round(n(s.y)); if (s.rel) o.rel = true; if (s.dur) o.dur = ms(s.dur); if (s.ease) o.ease = true; break;
    case 'flick': {
      o.btn = s.btn === 'none' ? 'none' : (BTNS.has(s.btn) ? s.btn : 'left');
      o.pre = ms(s.pre, 0);
      o.hold = ms(s.hold, 500);
      o.afterUp = ms(s.afterUp, 0);
      const lim = (v) => Math.min(100000, Math.max(-100000, Math.round(n(v, 0))));
      o.dx = lim(s.dx); o.dy = lim(s.dy);
      o.moveDur = ms(s.moveDur, 0);
      o.afterMove = ms(s.afterMove, 0);
      o.cooldown = ms(s.cooldown, 0);
      break;
    }
    case 'path': o.pts = Array.isArray(s.pts) ? s.pts.slice(0, 600000).map((v) => n(v)) : []; if (s.rel) o.rel = true; break;
    case 'click': o.btn = BTNS.has(s.btn) ? s.btn : 'left'; if (s.n != null) o.n = Math.max(1, Math.round(n(s.n, 1))); if (s.hold != null) o.hold = ms(s.hold); if (s.gap != null) o.gap = ms(s.gap); break;
    case 'down': case 'up': o.btn = BTNS.has(s.btn) ? s.btn : 'left'; break;
    case 'scroll': o.amount = Math.round(n(s.amount, 1)) || 1; if (s.gap != null) o.gap = ms(s.gap); break;
    case 'key': o.code = String(s.code || ''); if (s.n != null) o.n = Math.max(1, Math.round(n(s.n, 1))); if (s.hold != null) o.hold = ms(s.hold); if (s.gap != null) o.gap = ms(s.gap); break;
    case 'keydown': case 'keyup': o.code = String(s.code || ''); break;
    case 'keysdown': o.codes = (Array.isArray(s.codes) ? s.codes : []).filter((c) => typeof c === 'string' && c).slice(0, 10).map((c) => c.slice(0, 40)); break;
    case 'text': o.text = String(s.text ?? '').slice(0, 5000); if (s.gap != null) o.gap = ms(s.gap); break;
    case 'wait': o.ms = ms(s.ms); break;
  }
  return o;
}

function sanitizeMacro(m) {
  if (!m || typeof m !== 'object') return null;
  const id = String(m.id || '').slice(0, 80) || ('m-' + Math.random().toString(36).slice(2, 10));
  const steps = (Array.isArray(m.steps) ? m.steps : []).slice(0, 20000).map(sanitizeStep).filter(Boolean);
  const trigger = code(m.trigger);
  const mode = ['once', 'loop', 'hold', 'mirror'].includes(m.mode) ? m.mode : 'once';
  return {
    id,
    name: String(m.name || 'Macro').slice(0, 80),
    enabled: m.enabled !== false,
    trigger,
    mods: Array.isArray(m.mods) ? MODS.filter((k) => m.mods.includes(k)) : [],
    stopKey: code(m.stopKey) && code(m.stopKey) !== trigger ? code(m.stopKey) : null,
    mode,
    repeat: Math.min(1000000, Math.max(1, Math.round(n(m.repeat, 1)))),
    startDelay: ms(m.startDelay),
    stepGap: ms(m.stepGap),
    loopDelay: ms(m.loopDelay),
    endDelay: ms(m.endDelay),
    speed: Math.min(50, Math.max(0.05, n(m.speed, 1))),
    robloxOnly: !!m.robloxOnly,
    onRetrigger: ['stop', 'restart', 'ignore'].includes(m.onRetrigger) ? m.onRetrigger : 'stop',
    debounce: m.debounce == null ? 150 : Math.min(5000, Math.max(0, Math.round(n(m.debounce, 150)))),
    group: m.group ? String(m.group).trim().slice(0, 40) : '',
    priority: Math.min(100, Math.max(-100, Math.round(n(m.priority, 0)))),
    groupPolicy: ['interrupt', 'block', 'queue'].includes(m.groupPolicy) ? m.groupPolicy : 'interrupt',
    blockTrigger: m.blockTrigger !== false,
    // Alternar lado só existe para flick que vai para a esquerda/direita (X ≠ 0).
    sideKey: code(m.sideKey) && code(m.sideKey) !== trigger && steps.some((st) => st.t === 'flick' && Number(st.dx)) ? code(m.sideKey) : null,
    sideSound: m.sideSound !== false,
    steps,
  };
}

function sanitizeSettings(s) {
  return { stopKey: s && code(s.stopKey) ? code(s.stopKey) : 'F8', history: !(s && s.history === false) };
}

/** Impressão digital barata da definição (para saber se o worker já tem esta versão). */
function fingerprint(m) {
  const str = JSON.stringify([m.steps, m.mode, m.repeat, m.startDelay, m.stepGap, m.loopDelay, m.endDelay, m.speed]);
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 0x01000193); }
  return (h >>> 0).toString(36) + ':' + str.length;
}

// ───────────── gravação → passos ─────────────

/**
 * Converte eventos crus do hook em passos editáveis:
 *  - movimentos consecutivos viram UM passo "path" (trajetória), amostrado a cada `sampleMs`
 *  - mdown+mup do mesmo botão sem nada no meio (ou com tremidinha < 4px) viram "click" (com hold)
 *  - kdown+kup da mesma tecla sem nada no meio viram "key" (com hold)
 *  - ups sem down correspondente (tecla já segurada antes de gravar) são descartados
 *  - o "delay" de cada passo é o tempo desde o passo anterior (ms)
 */
function eventsToSteps(events, opts) {
  const o = { moves: 'path', coords: 'abs', sampleMs: 10, ...(opts || {}) };
  const evs = events.slice().sort((a, b) => a.t - b.t);
  // descarta ups órfãos
  const downK = new Set(), downB = new Set();
  const clean = [];
  for (const e of evs) {
    if (e.e === 'kdown') { downK.add(e.vk); clean.push(e); }
    else if (e.e === 'kup') { if (downK.delete(e.vk)) clean.push(e); }
    else if (e.e === 'mdown') { downB.add(e.btn); clean.push(e); }
    else if (e.e === 'mup') { if (downB.delete(e.btn)) clean.push(e); }
    else clean.push(e);
  }

  const raw = []; // passos com tempo absoluto: { at, step }
  let moveBuf = [];
  const flushMoves = () => {
    if (!moveBuf.length) return;
    if (o.moves === 'path') {
      const pts = [];
      let accDx = 0, accDy = 0, lastKeptT = null;
      for (let i = 0; i < moveBuf.length; i++) {
        const m = moveBuf[i];
        accDx += m.dx || 0; accDy += m.dy || 0;
        const isLast = i === moveBuf.length - 1;
        if (lastKeptT !== null && m.t - lastKeptT < o.sampleMs && !isLast) continue;
        if (o.coords === 'rel' && !accDx && !accDy && !isLast) continue;
        const dt = lastKeptT === null ? 0 : m.t - lastKeptT;
        if (o.coords === 'rel') { pts.push(dt, accDx, accDy); accDx = 0; accDy = 0; }
        else pts.push(dt, m.x, m.y);
        lastKeptT = m.t;
      }
      if (pts.length) raw.push({ at: moveBuf[0].t, step: { t: 'path', ...(o.coords === 'rel' ? { rel: true } : {}), pts } });
    }
    moveBuf = [];
  };

  for (let i = 0; i < clean.length; i++) {
    const e = clean[i];
    if (e.e === 'move') { if (o.moves === 'path') moveBuf.push(e); continue; }
    flushMoves();
    if (e.e === 'mdown') {
      // clique simples? procura o mup do mesmo botão, permitindo só tremidinha no meio
      let j = i + 1, jitter = true, mx = 0, my = 0;
      while (j < clean.length && clean[j].e === 'move') { mx += clean[j].dx || 0; my += clean[j].dy || 0; j++; }
      if (Math.abs(mx) > 3 || Math.abs(my) > 3) jitter = false;
      const up = clean[j];
      if (jitter && up && up.e === 'mup' && up.btn === e.btn && up.t - e.t <= 1500) {
        if (o.moves === 'clicks' && o.coords === 'abs') raw.push({ at: e.t, step: { t: 'move', x: e.x, y: e.y } });
        raw.push({ at: e.t, step: { t: 'click', btn: e.btn, hold: Math.max(0, up.t - e.t) } });
        i = j; continue;
      }
      if (o.moves === 'clicks' && o.coords === 'abs') raw.push({ at: e.t, step: { t: 'move', x: e.x, y: e.y } });
      raw.push({ at: e.t, step: { t: 'down', btn: e.btn } });
    } else if (e.e === 'mup') {
      if (o.moves === 'clicks' && o.coords === 'abs') raw.push({ at: e.t, step: { t: 'move', x: e.x, y: e.y } });
      raw.push({ at: e.t, step: { t: 'up', btn: e.btn } });
    } else if (e.e === 'wheel') {
      const notches = Math.round(e.delta / 120) || (e.delta > 0 ? 1 : -1);
      const prev = raw[raw.length - 1];
      // junta "cliques" de roda seguidos (até 120ms entre eles) num passo só
      if (prev && prev.step.t === 'scroll' && Math.sign(prev.step.amount) === Math.sign(notches) && e.t - prev.lastAt <= 120) {
        prev.step.amount += notches; prev.lastAt = e.t;
        prev.step.gap = Math.round((prev.lastAt - prev.at) / Math.max(1, Math.abs(prev.step.amount) - 1));
      } else raw.push({ at: e.t, lastAt: e.t, step: { t: 'scroll', amount: notches } });
    } else if (e.e === 'kdown') {
      const code = codeFromHook(e.vk, e.scan, e.ext);
      const nx = clean[i + 1];
      if (nx && nx.e === 'kup' && nx.vk === e.vk && nx.t - e.t <= 1500) {
        raw.push({ at: e.t, step: { t: 'key', code, hold: Math.max(0, nx.t - e.t) } });
        i++; continue;
      }
      raw.push({ at: e.t, step: { t: 'keydown', code } });
    } else if (e.e === 'kup') {
      raw.push({ at: e.t, step: { t: 'keyup', code: codeFromHook(e.vk, e.scan, e.ext) } });
    }
  }
  flushMoves();

  // tempos absolutos → delay relativo ao FIM do passo anterior
  const steps = [];
  let cursor = raw.length ? raw[0].at : 0;
  for (const r of raw) {
    const s = r.step;
    const delay = Math.max(0, Math.round(r.at - cursor));
    if (delay) s.delay = delay;
    steps.push(s);
    cursor = r.at + stepSpan(s);
  }
  return steps;
}

function stepSpan(s) {
  if (s.t === 'path') { let ms = 0; for (let i = 0; i < s.pts.length; i += 3) ms += s.pts[i]; return ms; }
  if (s.t === 'click' || s.t === 'key') return s.hold || 0;
  if (s.t === 'scroll') return (Math.abs(s.amount) - 1) * (s.gap || 0);
  return 0;
}

module.exports = { createMacroSystem, sanitizeMacro, eventsToSteps };
