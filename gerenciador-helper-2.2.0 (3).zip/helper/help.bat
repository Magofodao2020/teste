@echo off
title Gerenciador - Helper + Site (Injecao em Memoria)
echo ============================================================
echo  Gerenciador - Helper Local (Injecao em Memoria)
echo ============================================================
echo.
echo  Este helper injeta flags direto na memoria do Roblox
echo  e roda as ACOES (Flick, cliques, teclas) configuradas no site.
echo  Abra o SITE (hospedado) no navegador - ele fala com este Helper.
echo.
echo  IMPORTANTE: o Roblox deve estar RODANDO (dentro de um jogo).
echo  Recomendado: rodar como administrador.
echo  Deixe esta janela aberta: hotkeys e acoes param se fechar.
echo ============================================================
echo.

cd /d "%~dp0"

if not exist "node_modules" (
    echo Instalando dependencias...
    npm install
    echo.
)

node 626.js
if %ERRORLEVEL% neq 0 (
    echo.
    echo [ERRO] Node.js nao encontrado. Instale o Node.js 18+ e tente novamente.
    echo Baixe em: https://nodejs.org/
    pause
)
