@echo off
title Painel do BOPE - Helper Local
echo ============================================================
echo  Painel do BOPE - Helper Local
echo ============================================================
echo.
echo  Executa as ACOES e aplica os presets de flags no Roblox.
echo  Abra o SITE no navegador - ele envia tudo para este Helper.
echo  O Helper roda so nesta maquina, sem internet, e nao grava
echo  nada no PC.
echo.
echo  IMPORTANTE: o Roblox deve estar RODANDO (dentro de um jogo).
echo  Recomendado: rodar como administrador.
echo  Deixe esta janela aberta: as acoes param se fechar.
echo ============================================================
echo.

cd /d "%~dp0"

where node >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo [ERRO] Node.js nao encontrado. Instale o Node.js 18+ e tente novamente.
    echo Baixe em: https://nodejs.org/
    pause
    exit /b 1
)

if not exist "node_modules" (
    echo Instalando dependencias...
    call npm install
    echo.
)

node 626.js
if %ERRORLEVEL% neq 0 (
    echo.
    echo [ERRO] O Helper foi encerrado com erro. Veja a mensagem acima.
    pause
)
