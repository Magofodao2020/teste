@echo off
title Painel do BOPE - Helper Local
echo ============================================================
echo  Painel do BOPE - Helper Local
echo ============================================================
echo.
echo  Executa as ACOES e aplica os presets de flags no Roblox.
echo  Abra o SITE no navegador - ele envia tudo para este Helper.
echo  O Helper roda so nesta maquina, sem internet, e nao grava
echo  nada no PC.
echo.
echo  IMPORTANTE: o Roblox deve estar RODANDO (dentro de um jogo).
echo  Recomendado: rodar como administrador.
echo  Deixe esta janela aberta: as acoes param se fechar.
echo ============================================================
echo.

cd /d "%~dp0"

where node >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo [ERRO] Node.js nao encontrado. Instale o Node.js 18+ uma vez e tente de novo.
    echo Baixe em: https://nodejs.org/
    pause
    exit /b 1
)

if not exist "dp\index.js" (
    echo [ERRO] Pasta "dp" nao encontrada. Extraia o zip inteiro, com todas as pastas.
    pause
    exit /b 1
)

set TENTATIVAS=0
:iniciar
node 626.js
if %ERRORLEVEL% equ 0 goto fim
set /a TENTATIVAS+=1
if %TENTATIVAS% geq 5 (
    echo.
    echo [ERRO] O Helper caiu 5 vezes. Veja a mensagem acima.
    pause
    goto fim
)
echo.
echo [!] O Helper fechou com erro. Reiniciando em 3 segundos... (%TENTATIVAS%/5)
timeout /t 3 /nobreak >nul
goto iniciar
:fim
