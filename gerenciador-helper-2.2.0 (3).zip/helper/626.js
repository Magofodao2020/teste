#!/usr/bin/env node
/**
 * Painel do BOPE — Helper Local (Node.js)
 * =============================================================
 *
 * Executa as ações e escreve as flags dos presets na memória do Roblox em
 * execução, usando os offsets que o SITE envia. Sem internet, sem arquivos:
 * tudo fica em memória enquanto o Helper está aberto.
 *
 * Requisitos: Node.js 18+ (instalado no PC), Windows, Roblox rodando (como admin
 *   de preferência).
 * Uso: node 626.js   (sem npm install: a dependência já vem na pasta dp/)
 *      node 626.js --test   (só testa a detecção do Roblox e sai)
 */

const http = require('http');
const path = require('path');
const keymap = require('./569');
const { createMacroSystem } = require('./521');
const { createFlagEngine, inferTypeFromName, cleanFlagName } = require('./633');

const HELPER_VERSION = '3.0.1';
// Identifica esta execução (o site reenvia offsets/ações/atalhos quando muda).
const STARTED_AT = Date.now();
const DEFAULT_PORT = 7962;
// Atividade por-evento no console só em modo debug (nunca é gravada em arquivo).
const DEBUG = process.env.GERENCIADOR_DEBUG === '1' || process.argv.includes('--verbose');
const dbg = (...a) => { if (DEBUG) console.log(...a); };

// ──────────────────────── Windows API (koffi) ────────────────────────

let koffi = null;
let IS_WIN = process.platform === 'win32';
let LOAD_ERROR = null;

// bindings
let OpenProcess, CloseHandle, CreateToolhelp32Snapshot;
let Process32FirstW, Process32NextW, Module32FirstW, Module32NextW;
let ReadProcessMemory, WriteProcessMemory, VirtualQueryEx;
let NtWriteVirtualMemory, NtReadVirtualMemory, GetExitCodeProcess, GetProcessTimes;
let BeepFn = null;
let FindWindowW, GetWindowThreadProcessId, GetAsyncKeyState;
let MapVirtualKeyW, GetForegroundWindow, GetCursorPosFn;
let QueryFullProcessImageNameW;
let PE_SIZE = 568, ME_SIZE = 1080;

if (IS_WIN) {
  try {
    koffi = require('./dp');

    const kernel32 = koffi.load('kernel32.dll');
    const ntdll = koffi.load('ntdll.dll');
    const user32 = koffi.load('user32.dll');

    // Structs
    const PROCESSENTRY32W = koffi.struct('PROCESSENTRY32W', {
      dwSize: 'uint32', cntUsage: 'uint32', th32ProcessID: 'uint32',
      th32DefaultHeapID: 'uintptr_t', th32ModuleID: 'uint32', cntThreads: 'uint32',
      th32ParentProcessID: 'uint32', pcPriClassBase: 'int32', dwFlags: 'uint32',
      szExeFile: koffi.array('uint16', 260),
    });
    const MODULEENTRY32W = koffi.struct('MODULEENTRY32W', {
      dwSize: 'uint32', th32ModuleID: 'uint32', th32ProcessID: 'uint32',
      GlblcntUsage: 'uint32', ProccntUsage: 'uint32',
      modBaseAddr: 'uintptr_t', modBaseSize: 'uint32', hModule: 'uintptr_t',
      szModule: koffi.array('uint16', 256), szExePath: koffi.array('uint16', 260),
    });
    PE_SIZE = koffi.sizeof(PROCESSENTRY32W);
    ME_SIZE = koffi.sizeof(MODULEENTRY32W);

    // Ponteiros de saída
    const PE_IO = koffi.inout(koffi.pointer(PROCESSENTRY32W));
    const ME_IO = koffi.inout(koffi.pointer(MODULEENTRY32W));
    const OUT_U32 = koffi.out(koffi.pointer('uint32'));
    const OUT_UPTR = koffi.out(koffi.pointer('uintptr_t'));

    OpenProcess = kernel32.func('OpenProcess', 'void*', ['uint32', 'int', 'uint32']);
    CloseHandle = kernel32.func('CloseHandle', 'int', ['void*']);
    CreateToolhelp32Snapshot = kernel32.func('CreateToolhelp32Snapshot', 'void*', ['uint32', 'uint32']);
    Process32FirstW = kernel32.func('Process32FirstW', 'int', ['void*', PE_IO]);
    Process32NextW = kernel32.func('Process32NextW', 'int', ['void*', PE_IO]);
    Module32FirstW = kernel32.func('Module32FirstW', 'int', ['void*', ME_IO]);
    Module32NextW = kernel32.func('Module32NextW', 'int', ['void*', ME_IO]);

    ReadProcessMemory = kernel32.func('ReadProcessMemory', 'int', ['void*', 'uintptr_t', 'void*', 'uintptr_t', OUT_UPTR]);
    WriteProcessMemory = kernel32.func('WriteProcessMemory', 'int', ['void*', 'uintptr_t', 'void*', 'uintptr_t', OUT_UPTR]);
    VirtualQueryEx = kernel32.func('VirtualQueryEx', 'uintptr_t', ['void*', 'uintptr_t', 'void*', 'uintptr_t']);

    NtWriteVirtualMemory = ntdll.func('NtWriteVirtualMemory', 'int32', ['void*', 'uintptr_t', 'void*', 'uintptr_t', OUT_UPTR]);
    NtReadVirtualMemory = ntdll.func('NtReadVirtualMemory', 'int32', ['void*', 'uintptr_t', 'void*', 'uintptr_t', OUT_UPTR]);
    GetExitCodeProcess = kernel32.func('GetExitCodeProcess', 'int', ['void*', OUT_U32]);
    GetProcessTimes = kernel32.func('GetProcessTimes', 'int', ['void*', 'void*', 'void*', 'void*', 'void*']);
    try { BeepFn = kernel32.func('Beep', 'int', ['uint32', 'uint32']); } catch {}

    FindWindowW = user32.func('FindWindowW', 'uintptr_t', ['void*', 'str16']);
    GetWindowThreadProcessId = user32.func('GetWindowThreadProcessId', 'uint32', ['uintptr_t', OUT_U32]);
    GetAsyncKeyState = user32.func('GetAsyncKeyState', 'int16', ['int']);
    MapVirtualKeyW = user32.func('MapVirtualKeyW', 'uint32', ['uint32', 'uint32']);
    GetForegroundWindow = user32.func('GetForegroundWindow', 'uintptr_t', []);
    GetCursorPosFn = user32.func('GetCursorPos', 'int', ['void*']);
    // Caminho do .exe do processo → contém "version-XXXX" (build que o Roblox roda agora).
    QueryFullProcessImageNameW = kernel32.func('QueryFullProcessImageNameW', 'int', ['void*', 'uint32', 'void*', koffi.inout(koffi.pointer('uint32'))]);

    // Flick/cliques: coordenadas em pixels FÍSICOS (senão, com escala de tela 125%/150%,
    // a posição gravada e a reproduzida não batem). Tem que ser antes de qualquer janela.
    try {
      const SetProcessDpiAwarenessContext = user32.func('SetProcessDpiAwarenessContext', 'int', ['intptr_t']);
      if (!SetProcessDpiAwarenessContext(-4)) throw new Error('v2');
    } catch {
      try { user32.func('SetProcessDPIAware', 'int', [])(); } catch {}
    }
    // Janela do CMD: desliga o "Modo de Edição Rápida" SÓ nesta janela, enquanto ela
    // estiver aberta (nada é gravado no registro). Com ele ligado, um clique na
    // janela entra em modo "Selecionar" e o Windows CONGELA o Helper até apertar
    // uma tecla — o site via isso como "Helper desconectado".
    try {
      const GetStdHandle = kernel32.func('GetStdHandle', 'void*', ['int32']);
      const GetConsoleMode = kernel32.func('GetConsoleMode', 'int', ['void*', OUT_U32]);
      const SetConsoleMode = kernel32.func('SetConsoleMode', 'int', ['void*', 'uint32']);
      const hIn = GetStdHandle(-10);
      const mode = [0];
      if (hIn && GetConsoleMode(hIn, mode)) SetConsoleMode(hIn, ((mode[0] & ~0x40) | 0x80) >>> 0);
    } catch {}
    // Timer do Windows a 1ms: deixa os tempos dos macros precisos.
    try { koffi.load('winmm.dll').func('timeBeginPeriod', 'uint32', ['uint32'])(1); } catch {}
  } catch (e) {
    LOAD_ERROR = e.message;
    console.error('[!] Erro ao carregar koffi / APIs do Windows:', e.message);
    console.error('    Confira se a pasta "dp" (que vem no zip) está ao lado do 626.js.');
    koffi = null;
  }
}

const HAS_FFI = IS_WIN && koffi !== null;

// decodifica WCHAR[] (array de uint16) ou string
function decodeWChar(val) {
  if (typeof val === 'string') return val;
  if (!val || typeof val.length !== 'number') return '';
  let s = '';
  for (let i = 0; i < val.length; i++) {
    const c = val[i];
    if (!c) break;
    s += String.fromCharCode(c);
  }
  return s;
}

// ──────────────────────── Offsets (vindos do site) ────────────────────────
//
// O Helper NÃO acessa a internet. Os offsets de FFlags chegam do site
// (POST /set-offsets), já baixados e validados no navegador, e ficam SÓ em
// memória durante esta execução. Fechou o Helper, nada fica para trás.

const RVA_MIN = 0x100000;
const RVA_MAX = 0x10000000;

let siteOffsets = null; // { version, entries: { nomeLimpo: { rva, fullName, type } } }

function setSiteOffsets(version, names, addresses) {
  const v = typeof version === 'string' ? version.trim().toLowerCase() : '';
  if (!/^version-[0-9a-f]{16}$/.test(v)) return { ok: false, message: 'Versão do dataset inválida.' };
  if (!Array.isArray(names) || !Array.isArray(addresses) || names.length !== addresses.length) {
    return { ok: false, message: "Campos 'names' e 'addresses' devem ser listas do mesmo tamanho." };
  }
  const entries = {};
  for (let i = 0; i < names.length; i++) {
    const ident = names[i], addr = addresses[i];
    if (typeof ident !== 'string' || !/^[A-Za-z_]\w{0,127}$/.test(ident)) continue;
    if (typeof addr !== 'string' || !/^0x[0-9a-fA-F]{1,8}$/.test(addr)) continue;
    const rva = parseInt(addr.slice(2), 16);
    if (rva < RVA_MIN || rva > RVA_MAX) continue;
    const clean = cleanFlagName(ident);
    if (!entries[clean]) entries[clean] = { rva, fullName: ident, type: inferTypeFromName(ident) || 'unknown' };
  }
  const count = Object.keys(entries).length;
  if (count < 500) return { ok: false, message: `Dataset com poucos offsets válidos (${count}).` };
  siteOffsets = { version: v, entries };
  return { ok: true, version: v, count, message: `Offsets do dataset ${v} carregados em memória (${count}).` };
}

const NO_OFFSETS_MSG = 'O Helper ainda não recebeu os offsets do site. Abra o site com o Helper aberto e tente de novo.';

/**
 * Portão de escrita na memória (inspirado no _live_writes_gated do FastFlag
 * Manager). Se o build dos offsets carregados ≠ build do Roblox rodando, os
 * endereços (base + rva) apontam para o lugar errado e QUALQUER escrita
 * (aplicar / toggle / cycle / PAUSE) crasha o Roblox no próximo frame.
 * Nesse caso a gente NÃO escreve e devolve o motivo — em vez de crashar.
 *
 * A versão do Roblox é identificada DE NOVO aqui, imediatamente antes da
 * escrita (o processo pode ter sido fechado/reaberto desde o attach ou durante
 * o download dos offsets). Sem versão confirmada → bloqueia (fail-closed).
 * expectedVersion: versão da configuração/dataset escolhida no site (opcional).
 */
function liveWritesGated(sourceBuild, expectedVersion) {
  const det = detectRunningRoblox();
  const norm = (v) => (v ? String(v).trim().toLowerCase() : null);
  const block = (reason, mismatch = false) => ({
    gated: true, mismatch, running: det.version, offsets: sourceBuild || null, detection: det, reason,
  });
  if (det.state !== 'running') return block(det.reason);
  if (!engine || engine.pid() !== det.pid) {
    return block('O processo do Roblox mudou durante a operação (foi fechado ou reaberto). Nada foi escrito — tente de novo.');
  }
  if (!sourceBuild) {
    return block(`Não foi possível identificar a versão dos offsets carregados. Versão em execução: ${det.version}. `
      + 'Sem a versão dos offsets não dá para garantir compatibilidade, então nada foi escrito.');
  }
  if (norm(sourceBuild) !== det.version) {
    return block(`Versão incompatível. offsets → ${norm(sourceBuild)} · processo em execução → ${det.version}. `
      + 'Escrever na memória agora apontaria para endereços errados e crasharia o Roblox. '
      + 'Atualize os offsets (ou o Roblox) para a mesma versão e tente de novo.', true);
  }
  if (expectedVersion && norm(expectedVersion) !== det.version) {
    return block('Versão incompatível. A configuração selecionada pertence a outra versão do Roblox: '
      + `configuração → ${norm(expectedVersion)} · processo em execução → ${det.version}.`, true);
  }
  return { gated: false, detection: det };
}

// Resposta padrão de bloqueio (mesmos campos que o site/console já usam).
function gatedResponse(g, extra = {}) {
  return {
    ok: false, blocked: true, buildMismatch: g.mismatch, running: g.running, offsets: g.offsets,
    detection: publicDetection(g.detection), message: g.reason, ...extra,
  };
}

// ──────────────────────── Memory Injector ────────────────────────

const TH32CS_SNAPPROCESS = 0x02;
const TH32CS_SNAPMODULE = 0x08;
const TH32CS_SNAPMODULE32 = 0x10;
const PROCESS_VM_READ = 0x0010;
const PROCESS_VM_WRITE = 0x0020;
const PROCESS_VM_OPERATION = 0x0008;
const PROCESS_QUERY_INFORMATION = 0x0400;
const PROCESS_QUERY_LIMITED_INFORMATION = 0x1000;
const PROCESS_ACCESS = PROCESS_VM_READ | PROCESS_VM_WRITE | PROCESS_VM_OPERATION | PROCESS_QUERY_INFORMATION;

// ──────────────── Identificação da versão do Roblox em execução ────────────────
//
// Mesmo princípio do RbxDumperV2 (main.cpp → init()):
//   processo RobloxPlayerBeta.exe → PID → módulos do processo →
//   módulo RobloxPlayerBeta.exe → caminho REAL do módulo → "version-…".
// A versão vem só do processo em execução. Nunca de pastas de versões no disco,
// da seleção do site ou da "última instalada": com Fishstrap/Bloxstrap pode haver
// várias versões instaladas ao mesmo tempo. Nada disto é guardado (sem cache).

const ROBLOX_EXE = 'robloxplayerbeta.exe';
const RX_VERSION_DIR = /^version-[0-9a-f]+$/i;
const INVALID_HANDLE = 0xFFFFFFFFFFFFFFFFn;

function isValidHandle(h) {
  if (!h) return false;
  try {
    const a = BigInt.asUintN(64, BigInt(koffi.address(h)));
    return a !== 0n && a !== INVALID_HANDLE && a !== 0xFFFFFFFFn;
  } catch { return true; }
}

// "…\<qualquer coisa>\version-XXXX\RobloxPlayerBeta.exe" → "version-xxxx".
// Usa a pasta que CONTÉM o .exe (layout do Roblox, Bloxstrap e Fishstrap), para
// não confundir com "version-" em outro trecho do caminho (ex.: nome de usuário).
function versionFromImagePath(p) {
  if (!p) return null;
  const parts = String(p).split(/[\\/]+/).filter(Boolean);
  if (parts.length < 2 || parts[parts.length - 1].toLowerCase() !== ROBLOX_EXE) return null;
  const dir = parts[parts.length - 2];
  return RX_VERSION_DIR.test(dir) ? dir.toLowerCase() : null;
}

// Todos os PIDs de RobloxPlayerBeta.exe (ordem crescente). null = falha ao listar.
function listRobloxPids() {
  let snap = null;
  try {
    snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (!isValidHandle(snap)) return null;
    const pids = [];
    const pe = { dwSize: PE_SIZE };
    let ok = Process32FirstW(snap, pe);
    while (ok) {
      if (decodeWChar(pe.szExeFile).toLowerCase() === ROBLOX_EXE) pids.push(pe.th32ProcessID);
      pe.dwSize = PE_SIZE;
      ok = Process32NextW(snap, pe);
    }
    return pids.sort((a, b) => a - b);
  } catch { return null; } finally {
    if (snap) { try { CloseHandle(snap); } catch {} }
  }
}

// Módulo RobloxPlayerBeta.exe DENTRO do processo: caminho real, base e tamanho
// (igual ao getModulePathByName do main.cpp). Tenta 2x: o snapshot de módulos pode
// falhar de forma transitória (ERROR_BAD_LENGTH) enquanto o processo carrega DLLs.
function robloxModuleOf(pid) {
  for (let attempt = 0; attempt < 2; attempt++) {
    let snap = null;
    try {
      snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, pid);
      if (!isValidHandle(snap)) continue;
      const me = { dwSize: ME_SIZE };
      let ok = Module32FirstW(snap, me);
      while (ok) {
        if (decodeWChar(me.szModule).toLowerCase() === ROBLOX_EXE) {
          return { path: decodeWChar(me.szExePath) || null, base: Number(me.modBaseAddr), size: Number(me.modBaseSize) };
        }
        me.dwSize = ME_SIZE;
        ok = Module32NextW(snap, me);
      }
      return null;
    } catch {} finally {
      if (snap) { try { CloseHandle(snap); } catch {} }
    }
  }
  return null;
}
function modulePathOf(pid) {
  const m = robloxModuleOf(pid);
  return m ? m.path : null;
}

// Caminho real da imagem do processo (QueryFullProcessImageNameW). Só precisa de
// PROCESS_QUERY_LIMITED_INFORMATION, então funciona mesmo sem admin na maioria dos casos.
function imagePathOf(pid) {
  let h = null;
  try {
    h = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, 0, pid);
    if (!isValidHandle(h)) return null;
    const buf = Buffer.alloc(32768 * 2);
    const size = [32768];
    if (QueryFullProcessImageNameW(h, 0, buf, size) && size[0] > 0) return buf.toString('utf16le', 0, size[0] * 2);
  } catch {} finally {
    if (h) { try { CloseHandle(h); } catch {} }
  }
  return null;
}

// Identidade + versão de UM processo. Se as duas fontes existirem e discordarem → desconhecida.
function identifyProcess(pid) {
  const modPath = modulePathOf(pid);
  const imgPath = imagePathOf(pid);
  const path = modPath || imgPath;
  if (!path) return { pid, path: null, version: null, error: 'sem acesso ao caminho do processo (rode o Helper como administrador)' };
  const vMod = versionFromImagePath(modPath);
  const vImg = versionFromImagePath(imgPath);
  if (modPath && imgPath && vMod !== vImg) return { pid, path, version: null, error: 'caminhos do processo divergentes' };
  const version = vMod || vImg;
  if (!version) return { pid, path, version: null, error: 'o executável não está dentro de uma pasta de versão (version-XXXX)' };
  return { pid, path, version, error: null };
}

// PID dono da janela "Roblox" (mesma busca do main.cpp: FindWindowA(nullptr, "Roblox")).
function robloxWindowPid() {
  try {
    const hwnd = FindWindowW(null, 'Roblox');
    if (!hwnd) return null;
    const out = [0];
    GetWindowThreadProcessId(hwnd, out);
    return out[0] || null;
  } catch { return null; }
}

/**
 * Identifica o Roblox em execução. Sempre consulta o Windows na hora (sem cache).
 *   state 'running'     → version + pid do processo que o Helper vai usar
 *   state 'not-running' → nenhum RobloxPlayerBeta.exe
 *   state 'unknown'     → não dá para afirmar com segurança (nunca chuta)
 * Várias instâncias: todas precisam ser identificadas e estar na MESMA versão;
 * senão → 'unknown'. O processo usado é o dono da janela "Roblox" (como o
 * RbxDumper) ou, se nenhuma instância tiver essa janela, o de menor PID.
 */
function detectRunningRoblox() {
  const base = { state: 'unknown', version: null, pid: null, path: null, instances: [] };
  if (!HAS_FFI) {
    return { ...base, reason: LOAD_ERROR ? `Não foi possível identificar a versão do Roblox (FFI indisponível: ${LOAD_ERROR}).` : 'Não foi possível identificar a versão do Roblox: a identificação só funciona no Windows.' };
  }
  const pids = listRobloxPids();
  if (pids === null) return { ...base, reason: 'Não foi possível identificar a versão do Roblox: falha ao listar os processos do Windows.' };
  if (!pids.length) return { ...base, state: 'not-running', reason: 'Roblox não está em execução. Abra o Roblox e entre em um jogo.' };

  const instances = pids.map(identifyProcess);
  const bad = instances.filter(i => !i.version);
  if (bad.length) {
    return { ...base, instances, reason: 'Não foi possível identificar a versão do Roblox: '
      + bad.map(i => `PID ${i.pid} — ${i.error}`).join('; ') + '.' };
  }
  const versions = [...new Set(instances.map(i => i.version))];
  if (versions.length > 1) {
    return { ...base, instances, reason: 'Não foi possível identificar a versão do Roblox: há instâncias em versões diferentes ('
      + instances.map(i => `PID ${i.pid} → ${i.version}`).join(', ') + '). Feche as instâncias extras.' };
  }
  const winPid = robloxWindowPid();
  const target = instances.find(i => i.pid === winPid) || instances[0];
  return { state: 'running', version: versions[0], pid: target.pid, path: target.path, instances, reason: `Versão em execução: ${versions[0]}` };
}

// O que vai para o site (sem caminhos completos da máquina do usuário).
function publicDetection(det) {
  if (!det) return null;
  return {
    state: det.state, version: det.version, pid: det.pid, reason: det.reason,
    instances: det.instances.map(i => ({ pid: i.pid, version: i.version })),
  };
}

// ──────────────────────── Injeção (camada do Windows) ────────────────────────
//
// A lógica de escrita fica em 633.js (validação, lote atômico, originais,
// restauração). Aqui só as chamadas ao Windows que ela usa.

const STILL_ACTIVE = 259;

function winOs() {
  return {
    openProcess(pid) {
      try { const h = OpenProcess(PROCESS_ACCESS, 0, pid); return isValidHandle(h) ? h : null; } catch { return null; }
    },
    closeHandle(h) { try { CloseHandle(h); } catch {} },
    isAlive(h) {
      try { const code = [0]; return !!GetExitCodeProcess(h, code) && code[0] === STILL_ACTIVE; } catch { return false; }
    },
    // Horário de criação do processo: distingue um Roblox reaberto com o mesmo PID.
    startTime(h) {
      try {
        const c = Buffer.alloc(8), e = Buffer.alloc(8), k = Buffer.alloc(8), u = Buffer.alloc(8);
        return GetProcessTimes(h, c, e, k, u) ? c.readBigUInt64LE(0).toString() : null;
      } catch { return null; }
    },
    moduleInfo(pid) {
      const m = robloxModuleOf(pid);
      return m && m.base && m.size ? { base: m.base, size: m.size } : null;
    },
    read(h, addr, len) {
      const buf = Buffer.alloc(len);
      try { const br = [0]; if (NtReadVirtualMemory(h, addr, buf, len, br) === 0 && Number(br[0]) === len) return buf; } catch {}
      try { const br = [0]; if (ReadProcessMemory(h, addr, buf, len, br) && Number(br[0]) === len) return buf; } catch {}
      return null;
    },
    write(h, addr, data) {
      try { const bw = [0]; if (NtWriteVirtualMemory(h, addr, data, data.length, bw) === 0 && Number(bw[0]) === data.length) return true; } catch {}
      try { const bw = [0]; if (WriteProcessMemory(h, addr, data, data.length, bw) && Number(bw[0]) === data.length) return true; } catch {}
      return false;
    },
    query(h, addr) {
      try {
        const mbi = Buffer.alloc(48); // MEMORY_BASIC_INFORMATION (x64)
        if (Number(VirtualQueryEx(h, addr, mbi, 48)) < 48) return null;
        return { base: Number(mbi.readBigUInt64LE(0)), size: Number(mbi.readBigUInt64LE(24)), state: mbi.readUInt32LE(32), protect: mbi.readUInt32LE(36) };
      } catch { return null; }
    },
  };
}

const engine = HAS_FFI ? createFlagEngine(winOs(), { log: dbg }) : null;

/**
 * Prepara qualquer escrita: identifica o Roblox AGORA, conecta a ESSE processo,
 * exige offsets do site da mesma versão. Devolve { entries } ou { error }.
 */
function liveSession(expectedVersion) {
  if (!HAS_FFI) return { error: { ok: false, message: LOAD_ERROR ? `FFI indisponível: ${LOAD_ERROR}` : 'A injeção só funciona no Windows.' } };
  const det = detectRunningRoblox();
  if (det.state !== 'running') return { error: { ok: false, blocked: true, detection: publicDetection(det), message: det.reason } };
  const att = engine.attach(det.pid);
  if (!att.ok) return { error: { ok: false, blocked: true, detection: publicDetection(det), message: att.message } };
  if (!siteOffsets) return { error: { ok: false, blocked: true, message: NO_OFFSETS_MSG } };
  const g = liveWritesGated(siteOffsets.version, expectedVersion);
  if (g.gated) return { error: gatedResponse(g) };
  return { entries: siteOffsets.entries, version: siteOffsets.version };
}

const entryOf = (entries, name) => entries[cleanFlagName(name)] || entries[name] || null;

// /status é consultado pelo site a cada poucos segundos. Identificar o Roblox
// (lista de processos + módulos) pode levar centenas de ms num PC ocupado; um
// cache curto deixa a resposta instantânea. Aplicar/pausar/etc. NÃO usam este
// cache: sempre identificam o Roblox na hora.
const STATUS_CACHE_MS = 1500;
let statusCache = { at: 0, value: null };
function getStatusCached() {
  const now = Date.now();
  if (!statusCache.value || now - statusCache.at > STATUS_CACHE_MS) statusCache = { at: now, value: getStatus() };
  return statusCache.value;
}

function getStatus() {
  // Identificação feita na hora, a partir do processo (nada reaproveitado de antes).
  const det = detectRunningRoblox();
  const robloxRunning = det.instances.length > 0;
  const pid = det.pid;
  const runningBuild = det.state === 'running' ? det.version : null;
  const offsetsBuild = siteOffsets ? siteOffsets.version : null;
  const buildMatch = runningBuild && offsetsBuild ? runningBuild === offsetsBuild : null;
  return {
    ok: true, helper: 'gerenciador-helper', helperVersion: HELPER_VERSION,
    platform: process.platform, method: 'memory-injection', macros: true,
    ffiReady: HAS_FFI, loadError: LOAD_ERROR,
    robloxFound: robloxRunning, robloxPid: pid,
    startedAt: STARTED_AT,
    runningBuild, offsetsBuild, buildMatch,
    siteOffsetsBuild: offsetsBuild,
    detection: publicDetection(det),
    canApply: HAS_FFI && robloxRunning,
    alteredFlags: engine && engine.pid() === pid ? engine.liveCount() : 0,
    // Originais deste processo do Roblox: o site guarda só em memória (aba aberta)
    // e devolve em /set-originals se este Helper for fechado e aberto de novo.
    turbo: { active: turbo.active, intervalMs: TURBO_MS, reapplied: turbo.total },
    flagSession: engine && pid && engine.pid() === pid ? engine.sessionId() : null,
    originals: engine && pid && engine.pid() === pid ? engine.exportOriginals() : [],
  };
}

const plural = (n, um, varios) => `${n} ${n === 1 ? um : varios}`;

async function applyFlags(flags, expectedVersion) {
  const names = Object.keys(flags);
  const ctx = liveSession(expectedVersion);
  if (ctx.error) return { applied: 0, skipped: names, ...ctx.error };
  const r = engine.apply(names.map(name => ({ name, entry: entryOf(ctx.entries, name), value: flags[name] })));
  const applied = r.applied.length;
  const message = r.message
    || (applied === names.length ? `Todas as ${plural(applied, 'configuração aplicada', 'configurações aplicadas')} na memória.`
      : applied > 0 ? `${applied}/${names.length} configurações aplicadas. ${plural(r.skipped.length, 'ignorada', 'ignoradas')} (veja os motivos).`
      : 'Nenhuma configuração foi aplicada.')
    + (r.skipped.length && !r.message ? ' ' + r.skipped.slice(0, 3).map(f => `${f.flag}: ${f.reason}`).join(' · ') : '');
  if (applied > 0) setTurbo(true); // turbo faz parte do aplicar/retomar
  return { ok: applied > 0, applied, skipped: r.skipped.map(f => f.flag), failures: r.skipped, rolledBack: r.rolledBack || 0, message, sourceBuild: ctx.version };
}

async function toggleFlag(name, flags, expectedVersion) {
  const ctx = liveSession(expectedVersion);
  if (ctx.error) return ctx.error;
  // Padrão DESLIGADO: o 1º toque LIGA (aplica o valor do preset), o 2º DESLIGA (volta ao original).
  if (engine.isLive(name)) {
    const r = engine.restore([name]);
    const done = r.restored[0];
    if (done && done.unchanged) return { ok: true, enabled: false, flag: name, value: done.value, unknownOriginal: true, message: `'${name}' DESLIGADA, mas o Helper não conhece o valor padrão (foi aberto com a flag já alterada). Reinicie o Roblox para voltar ao padrão.` };
    if (done) return { ok: true, enabled: false, flag: name, value: done.value, message: `⭘ '${name}' DESLIGADA → ${done.value}` };
    return { ok: false, enabled: true, flag: name, message: `'${name}' não foi desligada: ${r.failed[0] ? r.failed[0].reason : 'erro desconhecido'}` };
  }
  // Valor do preset: pelo nome exato ou, se o atalho usa outro nome da mesma flag
  // (com/sem prefixo), pelo nome "limpo".
  let value = flags[name];
  if (value == null) {
    const key = cleanFlagName(name);
    const alt = Object.keys(flags).find((k) => cleanFlagName(k) === key);
    if (alt) value = flags[alt];
  }
  if (value == null || String(value) === '') return { ok: false, message: `Configuração '${name}' não tem valor definido no preset.` };
  const r = engine.apply([{ name, entry: entryOf(ctx.entries, name), value }]);
  if (r.ok) return { ok: true, enabled: true, flag: name, value: engine.liveValue(name), message: `✅ '${name}' LIGADA → ${engine.liveValue(name)}` };
  return { ok: false, enabled: false, flag: name, message: `Falha ao ligar '${name}': ${r.message || (r.skipped[0] && r.skipped[0].reason)}` };
}

async function cycleFlag(name, cycleValues, flags, expectedVersion) {
  if (!Array.isArray(cycleValues) || cycleValues.length < 2) return { ok: false, message: 'Precisa de pelo menos 2 valores.' };
  const ctx = liveSession(expectedVersion);
  if (ctx.error) return ctx.error;
  const vals = cycleValues.map(String);
  const current = engine.liveValue(name) ?? (flags[name] != null ? String(flags[name]) : null);
  const idx = vals.indexOf(current);
  const nextIdx = (idx + 1) % vals.length;
  const r = engine.apply([{ name, entry: entryOf(ctx.entries, name), value: vals[nextIdx] }]);
  if (!r.ok) return { ok: false, flag: name, message: `Falha ao ciclar '${name}': ${r.message || (r.skipped[0] && r.skipped[0].reason)}` };
  return { ok: true, flag: name, value: engine.liveValue(name), cycleIndex: nextIdx, message: `Configuração '${name}' ciclada para: ${engine.liveValue(name)}` };
}

/**
 * Pausa: volta ao valor original exato tudo o que o Helper alterou neste processo
 * do Roblox (ordem inversa). O que não foi alterado não é tocado.
 */
async function pauseAllFlags(_presetFlags, expectedVersion) {
  setTurbo(false); // pausar para o turbo; aplicar/retomar liga de novo
  const ctx = liveSession(expectedVersion);
  if (ctx.error) return { reverted: 0, failed: 0, ...ctx.error, message: ctx.error.buildMismatch ? 'Pause cancelado para não crashar o Roblox: ' + ctx.error.message : ctx.error.message };
  const r = engine.restore();
  const reverted = r.restored.length, failed = r.failed.length;
  return {
    ok: failed === 0, reverted, failed, failures: r.failed, total: reverted + failed,
    message: reverted + failed === 0 ? 'Nada para pausar: nenhuma configuração foi alterada neste Roblox.'
      : `Configurações pausadas: ${plural(reverted, 'voltou', 'voltaram')} ao valor original`
        + (failed ? `, ${plural(failed, 'falhou', 'falharam')} (${r.failed.slice(0, 3).map(f => `${f.flag}: ${f.reason}`).join(' · ')})` : '') + '.'
        + (r.restored.some(f => f.unchanged) ? ` ATENÇÃO: ${plural(r.restored.filter(f => f.unchanged).length, 'flag', 'flags')} sem valor padrão conhecido (o Helper foi aberto com elas já alteradas) — reinicie o Roblox para voltar ao padrão.` : ''),
  };
}

async function resumeAllFlags(flags, expectedVersion) {
  return applyFlags(flags, expectedVersion);
}

// ──────────────────────── Modo turbo ────────────────────────
// Faz parte do "Aplicar": depois de aplicar (ou retomar), o Helper confere as
// flags aplicadas a cada TURBO_MS e reaplica as que o Roblox voltar sozinho.
// Para ao pausar; volta ao aplicar/retomar de novo. Não tem opção de desligar.
// Leve: um timer só, sem detecção do Roblox a cada volta (segue o MESMO processo
// — PID + horário de criação — em que as flags foram aplicadas e validadas), só
// lê as flags aplicadas e escreve apenas as que mudaram. Roblox fechado = para.
const TURBO_MS = 1000;
const turbo = { active: false, timer: null, total: 0, pending: new Set(), lastLog: 0 };

function turboTick() {
  if (!turbo.active || !engine || !engine.pid()) return setTurbo(false);
  if (!engine.attach(engine.pid()).ok) return setTurbo(false); // Roblox fechado/reaberto
  if (!engine.liveCount()) return;
  const r = engine.enforce();
  for (const n of r.rewritten) turbo.pending.add(n);
  turbo.total += r.rewritten.length;
  // Console sem spam: no máximo uma linha a cada 5 s, só se algo foi reaplicado.
  const now = Date.now();
  if (turbo.pending.size && now - turbo.lastLog >= 5000) {
    const list = [...turbo.pending];
    console.log(`  [TURBO] reaplicada(s): ${list.slice(0, 5).join(', ')}${list.length > 5 ? ` e mais ${list.length - 5}` : ''}`);
    turbo.pending.clear(); turbo.lastLog = now;
  }
}

function setTurbo(active) {
  if (turbo.active === !!active) return;
  turbo.active = !!active;
  if (turbo.timer) { clearInterval(turbo.timer); turbo.timer = null; }
  if (turbo.active) {
    turbo.timer = setInterval(turboTick, TURBO_MS);
    if (turbo.timer.unref) turbo.timer.unref();
  }
  turbo.pending.clear();
  console.log(turbo.active ? '  [TURBO] ativo — conferindo as flags aplicadas a cada 1 s' : '  [TURBO] parado');
}

// ──────────────────────── Hotkey Listener ────────────────────────

let hotkeyConfig = {};
let hotkeyFlags = {};
let hotkeyRunning = false;

// Mapa code -> VK respeitando o layout atual do Windows (ABNT2, US…).
// Aceita qualquer tecla que o site capture (KeyboardEvent.code) + botões do mouse.
const codeToVk = keymap.makeCodeToVk(MapVirtualKeyW ? (a, b) => MapVirtualKeyW(a, b) : null);

// Evita disparo duplo/flip-flop de toggle e cycle. Um acionamento = UM toggle.
// Causas reais de disparo repetido num só acionamento: botão com "bounce", mouse
// com software que repete o evento, ou scroll de alta resolução (vários eventos
// por giro). Protegemos de duas formas, por (flag, ação):
//   1. enquanto o toggle/cycle (assíncrono) está em andamento, ignora novos;
//   2. depois que termina, um descanso curto (COOLDOWN_MS) ignora repetições.
// Um 2º acionamento intencional (depois do descanso) funciona normalmente.
const COOLDOWN_MS = 250;
const actionBusy = new Set();     // (flag|ação) em andamento
const actionCooldown = {};        // (flag|ação) -> timestamp até quando ignorar

function fireAction(fname, action) {
  // Trava pela flag "limpa": nomes com e sem prefixo são a mesma flag na memória.
  const key = cleanFlagName(fname) + '|' + action;
  const now = Date.now();
  if (actionBusy.has(key) || now < (actionCooldown[key] || 0)) return;
  actionBusy.add(key);
  const done = () => { actionBusy.delete(key); actionCooldown[key] = Date.now() + COOLDOWN_MS; };
  // Saída em tempo real no CMD, SÓ no momento da hotkey. Não é gravada em lugar
  // nenhum (sem .log/.txt/histórico); é apenas console enquanto o Helper roda.
  if (action === 'toggle') {
    toggleFlag(fname, hotkeyFlags)
      .then(r => {
        if (r.buildMismatch) console.log(`  [CONFIG] ${fname} = IGNORADO (versão incompatível — nada escrito)`);
        else if (r.blocked) console.log(`  [CONFIG] ${fname} = IGNORADO (${r.message})`);
        else if (r.unknownOriginal) console.log(`  [CONFIG] ${fname} = OFF -> ${r.value} (ATENÇÃO: o Helper não sabe o valor padrão desta flag — reinicie o Roblox)`);
        else if (r.ok) console.log(`  [CONFIG] ${fname} = ${r.enabled ? 'ON' : 'OFF'}${r.value != null ? ' -> ' + r.value : ''}`);
        else console.log(`  [CONFIG] ${fname} = FALHOU (${r.message})`);
      })
      .catch(e => console.log(`  [CONFIG] ${fname} = ERRO (${e.message})`))
      .finally(done);
  } else {
    const cv = (hotkeyConfig[fname] && hotkeyConfig[fname].cycleValues) || [];
    if (cv.length >= 2) {
      cycleFlag(fname, cv, hotkeyFlags)
        .then(r => {
          if (r.buildMismatch) console.log(`  [CONFIG] ${fname} = IGNORADO (versão incompatível — nada escrito)`);
          else if (r.blocked) console.log(`  [CONFIG] ${fname} = IGNORADO (${r.message})`);
          else if (r.ok) console.log(`  [CONFIG] ${fname} = CYCLE -> ${r.value}`);
          else console.log(`  [CONFIG] ${fname} = FALHOU (${r.message})`);
        })
        .catch(e => console.log(`  [CONFIG] ${fname} = ERRO (${e.message})`))
        .finally(done);
    } else {
      actionBusy.delete(key);
      console.log(`  [CONFIG] ${fname} = CYCLE precisa de 2+ valores configurados`);
    }
  }
}

// Dispara toggle/cycle para toda flag vinculada a este "code" (tecla ou botão/scroll).
// A mesma flag pode chegar com nomes diferentes (com e sem prefixo, ex.:
// DFIntX e X — atalhos antigos). Elas são a MESMA flag na memória, então:
//   - cada ação roda no máximo uma vez por flag;
//   - toggle e cycle da mesma flag no mesmo botão se anulariam (o cycle muda o
//     valor e o toggle desliga em seguida): só o toggle roda, com um aviso.
const conflictWarned = new Set();
function triggerForCode(code) {
  const perFlag = new Map(); // nome limpo → { toggle: nome, cycle: nome }
  for (const [fname, hk] of Object.entries(hotkeyConfig)) {
    const key = cleanFlagName(fname);
    const slot = perFlag.get(key) || {};
    if (hk.toggleKey === code && !slot.toggle) slot.toggle = fname;
    if (hk.cycleKey === code && !slot.cycle) slot.cycle = fname;
    perFlag.set(key, slot);
  }
  for (const [key, slot] of perFlag) {
    if (slot.toggle && slot.cycle) {
      const w = key + '|' + code;
      if (!conflictWarned.has(w)) {
        conflictWarned.add(w);
        console.log(`  [CONFIG] ${key}: "ligar/desligar" e "alternar valores" estão no MESMO botão (${code}) — só ligar/desligar vai rodar. Troque um dos atalhos no site.`);
      }
      fireAction(slot.toggle, 'toggle');
    } else if (slot.toggle) fireAction(slot.toggle, 'toggle');
    else if (slot.cycle) fireAction(slot.cycle, 'cycle');
  }
}

// ---- Sistema de ações (100% em memória: nada é salvo no PC) ----
const cursorBuf = Buffer.alloc(8);
// Bipe curto (troca de lado do flick). Roda em outra thread (koffi .async), então
// não trava as hotkeys enquanto toca. Nada é gravado; sem arquivo de som.
function beep(freq, ms) {
  if (!BeepFn) return;
  try { if (typeof BeepFn.async === 'function') BeepFn.async(freq, ms, () => {}); } catch {}
}

const macroSys = createMacroSystem({
  beep,
  // Combinações (Ctrl/Shift/Alt + botão): estado global dos modificadores na hora do gatilho.
  modsDown: () => {
    if (!HAS_FFI || !GetAsyncKeyState) return { ctrl: false, shift: false, alt: false };
    const down = (vk) => { try { return (GetAsyncKeyState(vk) & 0x8000) !== 0; } catch { return false; } };
    return { ctrl: down(0x11), shift: down(0x10), alt: down(0x12) };
  },
  codeToVk,
  isWin: IS_WIN,
  hasFfi: HAS_FFI,
  log: (...a) => console.log(...a),   // erros/essencial (sempre)
  verbose: DEBUG,                       // atividade por-evento só em debug
  getRobloxPid: () => { if (!HAS_FFI) return null; const p = listRobloxPids(); return p && p.length ? p[0] : null; },
  getForegroundPid: () => {
    if (!HAS_FFI) return null;
    try {
      const hwnd = GetForegroundWindow();
      if (!hwnd) return null;
      const pid = [0];
      GetWindowThreadProcessId(hwnd, pid);
      return pid[0] || null;
    } catch { return null; }
  },
  getCursor: HAS_FFI ? () => (GetCursorPosFn(cursorBuf) ? { x: cursorBuf.readInt32LE(0), y: cursorBuf.readInt32LE(4) } : null) : null,
});

// ---- Hook global de entrada (worker separado): scroll + gravação de ações ----
let inputWorker = null;
let inputHookStarted = false; // só tenta uma vez por execução (evita respawn)
const hookShared = new Int32Array(new SharedArrayBuffer(48 * 4)); // layout em 609.js
const hookHandle = { shared: hookShared, ready: false };
function startInputHook() {
  if (inputWorker || inputHookStarted || !IS_WIN) return;
  inputHookStarted = true;
  macroSys.attachHook(hookHandle);
  try {
    const { Worker } = require('worker_threads');
    inputWorker = new Worker(path.join(__dirname, '609.js'), { workerData: { shared: hookShared.buffer } });
    inputWorker.on('message', (m) => {
      if (!m) return;
      if (m.type === 'rec') macroSys.onRecEvent(m);
      else if (m.type === 'direct') {
        // Igual ao print do Gagatech.py: mostra cada apertar/soltar e quantas teclas o Windows aceitou.
        const info = macroSys.onDirect(m);
        const btn = m.which === 3 ? 'botão do meio' : `lateral ${m.which === 2 ? '►' : '◄'}`;
        const who = info.m ? `[${info.m.name}]` : '[segurar junto]';
        if (m.sent === m.n) console.log(`  ${who} ${m.down ? 'APERTOU' : 'SOLTOU '} ${btn} → ${m.sent} teclas enviadas juntas`);
        else console.log(`  ${who} ${m.down ? 'APERTOU' : 'SOLTOU '} ${btn} → o Windows aceitou ${m.sent}/${m.n} teclas. Se o Roblox roda como administrador, rode o help.bat como administrador também.`);
      }
      else if (m.type === 'input') {
        // Gatilho entregue pelo hook (teclado: vk → códigos observados; mouse/scroll: código)
        const codes = m.code ? [m.code] : (vkToCodes.get(m.vk) || []);
        for (const code of codes) { if (m.up) dispatchUp(code); else dispatchDown(code, m.at); }
      }
      else if (m.type === 'rec-stop') macroSys.stopRecording('tecla de parada');
      else if (m.type === 'cap') onCaptured(m);
      else if (m.type === 'ready') { hookHandle.ready = true; syncHookConfig(); console.log('  ✓ Hook global ativo (gatilhos de teclado/mouse/scroll sem polling + gravação de ações).'); }
      else if (m.type === 'warn') console.log('  [hook]', m.error);
      else if (m.type === 'error') console.log('  [hook] indisponível:', m.error, '(scroll e gravação de ação não vão funcionar; teclas e botões seguem ok)');
    });
    const w = inputWorker;
    w.on('error', (e) => { console.log('  [hook] erro no worker:', e.message); });
    w.on('exit', () => {
      if (inputWorker === w) { inputWorker = null; hookHandle.ready = false; }
      restartInputHook();
    });
  } catch (e) {
    console.log('  [hook] não iniciou:', e.message);
  }
}

// Passa ao hook (memória compartilhada) o que ele precisa saber, sem mensagens:
// botões bloqueados, "segurar junto" direto (◄ ► meio), botões e teclas observados.
const MOUSE_BITS = { MouseLeft: 1, MouseRight: 2, MouseMiddle: 4, MouseBack: 8, MouseForward: 16 };
let vkToCodes = new Map();
let flagCodes = new Set();
function syncHookConfig() {
  flagCodes = new Set();
  for (const hk of Object.values(hotkeyConfig)) {
    if (hk.toggleKey) flagCodes.add(hk.toggleKey);
    if (hk.cycleKey) flagCodes.add(hk.cycleKey);
  }
  Atomics.store(hookShared, 4, macroSys.blockedButtons());
  const d = macroSys.directChords();
  for (const slot of [1, 2, 3]) {
    const base = 5 + (slot - 1) * 6;
    const c = d[slot];
    const keys = c ? c.keys : [];
    Atomics.store(hookShared, base, 0); // zera a contagem antes de trocar as teclas
    keys.forEach((k, i) => Atomics.store(hookShared, base + 1 + i, (k.vk & 0xff) | ((k.scan & 0xff) << 8) | ((k.ext ? 1 : 0) << 16)));
    Atomics.store(hookShared, base + 5, c && c.block ? 1 : 0);
    Atomics.store(hookShared, base, keys.length);
  }
  let mouse = 0;
  const bits = new Int32Array(8);
  const map = new Map();
  for (const code of new Set([...macroSys.watchedCodes(), ...flagCodes])) {
    if (MOUSE_BITS[code]) { mouse |= MOUSE_BITS[code]; continue; }
    const vk = codeToVk(code);
    if (!vk || vk > 255) continue;
    bits[vk >>> 5] |= 1 << (vk & 31);
    if (!map.has(vk)) map.set(vk, []);
    map.get(vk).push(code);
  }
  vkToCodes = map;
  Atomics.store(hookShared, 23, mouse);
  for (let i = 0; i < 8; i++) Atomics.store(hookShared, 24 + i, bits[i]);
}

/** Um gatilho apertado/solto (venha do hook ou do polling): atalhos de flag + ações. */
function dispatchDown(code, at) {
  if (captureQuiet()) return; // definindo botão no site: não dispara nada
  if (flagCodes.has(code) || keymap.SCROLL_CODES.has(code)) triggerForCode(code);
  macroSys.onDown(code, at);
}
function dispatchUp(code) { macroSys.onUp(code); }

// O hook caiu (erro no worker): sobe de novo sozinho, sem precisar reabrir o
// Helper. No máximo 5 vezes por minuto, para não ficar em loop se o Windows recusar.
let hookRestarts = [];
let shuttingDown = false;
function restartInputHook() {
  if (shuttingDown || inputWorker) return;
  const now = Date.now();
  hookRestarts = hookRestarts.filter((t) => now - t < 60000);
  if (hookRestarts.length >= 5) { console.log('  [hook] caiu várias vezes seguidas; scroll/gravação pausados. Reabra o Helper.'); return; }
  hookRestarts.push(now);
  console.log('  [hook] reiniciando o hook global…');
  setTimeout(() => { inputHookStarted = false; startInputHook(); }, 1500);
}

// ---- Captura de botão para o site ("Definir botão") ----
// O site pede e o hook global do Windows informa o próximo botão/tecla. Funciona
// igual em qualquer navegador (inclusive os laterais do mouse, que alguns
// navegadores/mouses não repassam à página). Nada é gravado; só em memória.
const CAPTURE_MAX_MS = 20000;
const CAPTURE_ARM_MS = 120; // ignora o próprio clique que abriu a captura
const capture = { active: false, id: 0, startedAt: 0, endedAt: 0, code: null, opts: {}, timer: null };
// Durante a captura (e logo depois) os botões NÃO disparam ações nem atalhos.
const captureQuiet = () => capture.active || Date.now() - capture.endedAt < 400;

function endCapture() {
  if (capture.active) capture.endedAt = Date.now();
  capture.active = false;
  Atomics.store(hookShared, 3, 0);
  if (capture.timer) { clearTimeout(capture.timer); capture.timer = null; }
}

function startCapture(opts) {
  if (!IS_WIN || !HAS_FFI) return { ok: false, message: 'Captura pelo Helper só funciona no Windows.' };
  startInputHook();
  if (!inputWorker) return { ok: false, message: 'Hook do Windows indisponível.' };
  endCapture();
  capture.id++;
  capture.active = true;
  capture.startedAt = Date.now();
  capture.code = null;
  capture.opts = {
    mouse: opts.mouse !== false,
    scroll: opts.scroll !== false && opts.mouse !== false,
    keyboard: opts.keyboard !== false,
  };
  capture.timer = setTimeout(endCapture, CAPTURE_MAX_MS);
  Atomics.store(hookShared, 3, capture.opts.mouse ? 1 : 2); // 2 = só teclado
  return { ok: true, id: capture.id, hookReady: hookHandle.ready, message: 'Pressione um botão ou tecla.' };
}

function onCaptured(m) {
  if (!capture.active || Date.now() - capture.startedAt < CAPTURE_ARM_MS) return;
  const code = m.code || (m.vk != null ? keymap.codeFromHook(m.vk, m.scan || 0, m.ext) : null);
  if (!code) return;
  const isScroll = keymap.SCROLL_CODES.has(code);
  const isMouse = keymap.MOUSE_CODES.has(code);
  if (isScroll && !capture.opts.scroll) return;
  if (isMouse && !capture.opts.mouse) return;
  if (!isScroll && !isMouse && !capture.opts.keyboard) return;
  capture.code = code;
  endCapture();
}

/**
 * Reserva por polling (GetAsyncKeyState), usada só para o que o hook NÃO cobre:
 * tudo quando o hook não está ativo; só as teclas quando o hook de teclado não
 * instalou. Com o hook ativo, gatilhos chegam no instante do evento e este loop
 * fica parado (sem custo de CPU). Bordas de teclas que o próprio macro injetou
 * são ignoradas.
 */
const POLL_MS = 8;
function startHotkeyListener() {
  startInputHook();
  syncHookConfig();
  if (hotkeyRunning || !HAS_FFI) return;
  hotkeyRunning = true;
  const prevState = {}; // por code-string: estado da tecla/botão no poll anterior
  const poll = () => {
    if (!hotkeyRunning) return;
    const hookMouse = hookHandle.ready;
    const hookKeys = hookHandle.ready && Atomics.load(hookShared, 32) === 1;
    if (hookMouse && hookKeys) {
      // tudo pelo hook: solta o que tinha ficado "apertado" no polling e descansa
      for (const code of Object.keys(prevState)) if (prevState[code]) { prevState[code] = false; dispatchUp(code); }
      setTimeout(poll, 100);
      return;
    }
    const all = new Set([...flagCodes, ...macroSys.watchedCodes()]);
    for (const code of all) {
      const isMouse = !!MOUSE_BITS[code];
      if ((isMouse && hookMouse) || (!isMouse && hookKeys)) {
        if (prevState[code]) { prevState[code] = false; dispatchUp(code); }
        continue;
      }
      const vk = codeToVk(code);
      if (!vk) continue; // ScrollUp/Down vêm do hook, não do polling
      let pressed = false;
      try { pressed = (GetAsyncKeyState(vk) & 0x8000) !== 0; } catch {}
      const was = !!prevState[code];
      prevState[code] = pressed;
      if (pressed === was) continue;
      if (pressed) {
        if (macroSys.isSelfInjected(code)) continue; // fomos nós (macro) que apertamos
        dispatchDown(code, performance.timeOrigin + performance.now());
      } else {
        dispatchUp(code);
      }
    }
    setTimeout(poll, POLL_MS);
  };
  setTimeout(poll, POLL_MS);
}

// ──────────────────────── HTTP Server ────────────────────────

function readBody(req) {
  return new Promise((resolve) => {
    const chunks = []; let size = 0;
    req.on('data', (c) => { size += c.length; if (size > 4 * 1024 * 1024) { resolve(null); req.destroy(); return; } chunks.push(c); });
    req.on('end', () => { try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}')); } catch { resolve(null); } });
    req.on('error', () => resolve(null));
  });
}

function sendJson(res, obj, code = 200) {
  const body = JSON.stringify(obj);
  res.writeHead(code, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Length': Buffer.byteLength(body),
  });
  res.end(body);
}

// Helper só com API local (127.0.0.1): não serve o site nem lê/grava arquivos.
// O site é hospedado à parte e conversa com o Helper via CORS.

// Qualquer erro numa requisição responde 500 em vez de derrubar o Helper.
const server = http.createServer((req, res) => {
  handleRequest(req, res).catch((e) => {
    console.log(`  [!] erro ao responder ${req.method} ${req.url}: ${e && e.message}`);
    try { if (!res.headersSent) sendJson(res, { ok: false, message: `Erro interno no Helper: ${e && e.message}` }, 500); else res.end(); } catch {}
  });
});
server.keepAliveTimeout = 2000;

async function handleRequest(req, res) {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
      // Permite que um site HTTPS público acesse este helper em localhost
      // (modelo antigo de Private Network Access do Chrome). Inofensivo nos demais.
      'Access-Control-Allow-Private-Network': 'true',
    });
    res.end(); return;
  }
  const rawPath = (req.url || '').split('?')[0].replace(/\/+$/, '');
  const urlPath = rawPath || '/status';

  if (req.method === 'GET') {
    // API: /status responde JSON. (Se o site estiver embutido, use / para o site.)
    if (urlPath === '/status') return sendJson(res, getStatusCached());
    if (urlPath === '/debug') {
      const det = detectRunningRoblox();
      const pid = det.pid;
      if (det.state === 'running' && engine) engine.attach(pid);
      return sendJson(res, { ffiReady: HAS_FFI, loadError: LOAD_ERROR, peSize: PE_SIZE, meSize: ME_SIZE, robloxPid: pid, injection: engine ? engine.info() : null, detection: publicDetection(det) });
    }
    // ── Macros ──
    if (urlPath === '/macros') return sendJson(res, { ok: true, ...macroSys.getConfig() });
    if (urlPath === '/macro/state') return sendJson(res, macroSys.state());
    if (urlPath === '/macro/history') {
      const since = Number(new URL(req.url, 'http://x').searchParams.get('since')) || 0;
      return sendJson(res, { ok: true, ...macroSys.getHistory(since) });
    }
    if (urlPath === '/macro/record/status') return sendJson(res, { ok: true, ...macroSys.recordingStatus() });
    if (urlPath === '/capture/status') return sendJson(res, { ok: true, id: capture.id, active: capture.active, code: capture.code });
    if (urlPath === '/' || urlPath === '') return sendJson(res, getStatusCached());
    return sendJson(res, { ok: false, message: 'rota desconhecida' }, 404);
  }

  if (req.method === 'POST') {
    statusCache.value = null; // operação nova: o próximo /status lê tudo na hora
    const data = await readBody(req);
    if (data === null) return sendJson(res, { ok: false, message: 'JSON inválido' }, 400);
    switch (urlPath) {
      case '/apply': {
        if (!data.flags || typeof data.flags !== 'object') return sendJson(res, { ok: false, message: "campo 'flags' deve ser um objeto" }, 400);
        return sendJson(res, await applyFlags(data.flags, data.dumpVersion));
      }
      case '/set-offsets':
        return sendJson(res, setSiteOffsets(data.version, data.names, data.addresses));
      case '/restore':
        return sendJson(res, await pauseAllFlags(null, data.dumpVersion));
      case '/toggle':
        if (!data.name) return sendJson(res, { ok: false, message: "campo 'name' é obrigatório" }, 400);
        return sendJson(res, await toggleFlag(data.name, data.flags || {}, data.dumpVersion));
      case '/cycle':
        if (!data.name) return sendJson(res, { ok: false, message: "campo 'name' é obrigatório" }, 400);
        return sendJson(res, await cycleFlag(data.name, data.cycleValues || [], data.flags || {}, data.dumpVersion));
      case '/pause':
        return sendJson(res, await pauseAllFlags(data.flags || null, data.dumpVersion));
      case '/resume':
        return sendJson(res, await resumeAllFlags(data.flags || {}, data.dumpVersion));
      case '/set-originals': {
        // Originais que um Helper anterior capturou NESTE mesmo processo do Roblox.
        if (!engine) return sendJson(res, { ok: false, seeded: 0, message: 'FFI indisponível.' });
        const det = detectRunningRoblox();
        if (det.state !== 'running' || !engine.attach(det.pid).ok) return sendJson(res, { ok: false, seeded: 0, message: 'Roblox não encontrado.' });
        const list = Array.isArray(data.sessions) ? data.sessions.slice(0, 5) : [];
        const mine = list.find((x) => x && x.session === engine.sessionId());
        const r = mine ? engine.seedOriginals(mine.session, mine.items) : { ok: true, seeded: 0 };
        return sendJson(res, { ...r, message: `${r.seeded} valor(es) original(is) recuperado(s).` });
      }
      case '/set-hotkeys':
        hotkeyConfig = data.hotkeys || {}; hotkeyFlags = data.flags || {}; startHotkeyListener();
        return sendJson(res, { ok: true, message: `${Object.keys(hotkeyConfig).length} hotkeys configuradas.` });
      // ── Macros ──
      case '/set-macros': {
        const r = macroSys.setConfig({ macros: data.macros, settings: data.settings });
        syncHookConfig();
        startHotkeyListener();
        return sendJson(res, { ok: true, ...r, message: `${r.count} ação(ões) sincronizada(s), ${r.active} com gatilho ativo.` });
      }
      case '/macro/run': {
        if (!data.macro || typeof data.macro !== 'object') return sendJson(res, { ok: false, message: "campo 'macro' é obrigatório" }, 400);
        startHotkeyListener();
        return sendJson(res, macroSys.run(data.macro, { countdown: Math.min(10000, Math.max(0, Number(data.countdown) || 0)) }));
      }
      case '/macro/stop': {
        const n = data.id ? (macroSys.stop(String(data.id)) ? 1 : 0) : macroSys.stopAll();
        return sendJson(res, { ok: true, stopped: n, message: n ? `${n} macro(s) parado(s).` : 'Nenhum macro rodando.' });
      }
      case '/macro/record/start':
        startHotkeyListener();
        return sendJson(res, macroSys.startRecording(data));
      case '/macro/record/stop':
        return sendJson(res, macroSys.stopRecording('parado pelo site'));
      case '/capture/start':
        return sendJson(res, startCapture(data));
      case '/capture/stop':
        endCapture();
        return sendJson(res, { ok: true, message: 'Captura encerrada.' });
      case '/macro/history/clear':
        return sendJson(res, { ...macroSys.clearHistory(), message: 'Histórico limpo.' });
      case '/macro/cursor':
        return sendJson(res, await macroSys.pickCursor(data.delay));
      default:
        return sendJson(res, { ok: false, message: 'rota desconhecida' }, 404);
    }
  }
  sendJson(res, { ok: false, message: 'método não permitido' }, 405);
}

// ──────────────────────── Autoteste / Startup ────────────────────────

function selfTest() {
  console.log('── Autoteste de detecção ──');
  console.log(`FFI pronto: ${HAS_FFI}${LOAD_ERROR ? ' (erro: ' + LOAD_ERROR + ')' : ''}`);
  console.log(`sizeof PROCESSENTRY32W = ${PE_SIZE}, MODULEENTRY32W = ${ME_SIZE}`);
  if (!HAS_FFI) { console.log('FFI não disponível — abortando teste.'); return; }
  const det = detectRunningRoblox();
  for (const i of det.instances) console.log(`Instância PID ${i.pid}: ${i.version ?? 'versão desconhecida'}${i.path ? ' — ' + i.path : ''}${i.error ? ' (' + i.error + ')' : ''}`);
  console.log(det.reason);
  const pid = det.pid;
  console.log(`Roblox PID usado pelo Helper: ${pid ?? 'nenhum'}`);
  if (pid) {
    const att = engine.attach(pid);
    console.log(att.ok ? `Processo aberto: base ${engine.info().base}, ${engine.info().moduleSize} bytes` : `Falhou: ${att.message}`);
  } else if (det.state === 'not-running') {
    console.log('→ Abra o Roblox e entre em um jogo. Se já estiver aberto, rode como administrador.');
  }
  console.log('───────────────────────────');
}

if (process.argv.includes('--test')) {
  selfTest();
  process.exit(0);
}

const port = parseInt(process.argv[2]) || DEFAULT_PORT;

function tryListen(p, tries = 5) {
  server.listen(p, '127.0.0.1', () => {
    const st = getStatus();
    console.log('┌─ Painel do BOPE — Helper Local [Node.js · sem internet]');
    console.log(`│  versão ${HELPER_VERSION} · http://127.0.0.1:${p}`);
    console.log(`│  FFI pronto: ${HAS_FFI}${LOAD_ERROR ? ' — ' + LOAD_ERROR : ''}`);
    console.log(`│  Roblox: ${st.detection ? st.detection.reason : 'não detectado — abra o Roblox e entre em um jogo'}${st.robloxPid ? ` (PID ${st.robloxPid})` : ''}`);
    console.log('│  Abra o SITE (hospedado) no navegador — ele fala com este Helper em 127.0.0.1.');
    if (!IS_WIN) console.log('│  ⚠ Injeção em memória só funciona no Windows');
    console.log('│  Hotkeys (teclado + botões do mouse) funcionam GLOBALMENTE, mesmo com o Roblox em foco.');
    console.log('│  100% em memória: o Helper NÃO grava nada no seu PC (config fica no site).');
    const mc = macroSys.getConfig();
    console.log(`│  Ações: ${mc.macros.length} em memória · tecla de parada ${mc.settings.stopKey || 'F8'}${IS_WIN ? '' : ' · (fora do Windows: execução simulada)'}`);
    console.log('│  Dica: "node 626.js --test" testa só a detecção.');
    console.log('└─ Ctrl+C para encerrar.');
  });
  server.on('error', (e) => {
    if (e.code === 'EADDRINUSE' && tries > 1) {
      console.log(`[!] porta ${p} ocupada, tentando ${p + 1}…`);
      server.close();
      tryListen(p + 1, tries - 1);
    } else { console.error(`[x] não consegui abrir porta: ${e.message}`); process.exit(1); }
  });
}

tryListen(port);
startHotkeyListener(); // começa a ouvir hotkeys/ações assim que o site enviar a config

// Um erro inesperado em qualquer parte (timer, worker, FFI) não fecha o Helper:
// mostra no console e segue rodando, para o site não perder a conexão.
let lastCrashLog = 0;
function survive(kind, e) {
  const now = Date.now();
  if (now - lastCrashLog < 2000) return; // sem spam se repetir em loop
  lastCrashLog = now;
  console.log(`  [!] ${kind}: ${e && e.stack ? e.stack.split('\n').slice(0, 3).join(' | ') : e} — o Helper continua rodando.`);
}
process.on('uncaughtException', (e) => {
  if (e && e.code === 'EADDRINUSE') return; // tratado em tryListen
  survive('erro inesperado', e);
});
process.on('unhandledRejection', (e) => survive('erro inesperado (assíncrono)', e));

// Ctrl+C: para os macros (eles soltam teclas/botões segurados) antes de sair.
process.on('SIGINT', () => {
  shuttingDown = true;
  try { macroSys.stopAll(); } catch {}
  setTimeout(() => { try { macroSys.shutdown(); } catch {} process.exit(0); }, 200);
});
