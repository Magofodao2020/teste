#!/usr/bin/env node
/**
 * Painel do BOPE — Helper Local (Node.js)
 * =============================================================
 *
 * Executa as ações e escreve as flags dos presets na memória do Roblox em
 * execução, usando os offsets que o SITE envia. Sem internet, sem arquivos:
 * tudo fica em memória enquanto o Helper está aberto.
 *
 * Requisitos: Node.js 18+, Windows, Roblox rodando (como admin de preferência)
 * Uso: npm install && node 626.js
 *      node 626.js --test   (só testa a detecção do Roblox e sai)
 */

const http = require('http');
const path = require('path');
const keymap = require('./569');
const { createMacroSystem } = require('./521');
const { createFlagEngine, inferTypeFromName, cleanFlagName } = require('./633');

const HELPER_VERSION = '2.4.1';
// Identifica esta execução (o site reenvia offsets/ações/atalhos quando muda).
const STARTED_AT = Date.now();
const DEFAULT_PORT = 7962;
// Atividade por-evento no console só em modo debug (nunca é gravada em arquivo).
const DEBUG = process.env.GERENCIADOR_DEBUG === '1' || process.argv.includes('--verbose');
const dbg = (...a) => { if (DEBUG) console.log(...a); };

// ──────────────────────── Windows API (koffi) ────────────────────────

let koffi = null;
let IS_WIN = process.platform === 'win32';
let LOAD_ERROR = null;

// bindings
let OpenProcess, CloseHandle, CreateToolhelp32Snapshot;
let Process32FirstW, Process32NextW, Module32FirstW, Module32NextW;
let ReadProcessMemory, WriteProcessMemory, VirtualQueryEx, VirtualProtectEx;
let NtWriteVirtualMemory, NtReadVirtualMemory, GetExitCodeProcess, GetProcessTimes;
let FindWindowW, GetWindowThreadProcessId, GetAsyncKeyState;
let MapVirtualKeyW, GetForegroundWindow, GetCursorPosFn;
let QueryFullProcessImageNameW;
let PE_SIZE = 568, ME_SIZE = 1080;

if (IS_WIN) {
  try {
    koffi = require('koffi');

    const kernel32 = koffi.load('kernel32.dll');
    const ntdll = koffi.load('ntdll.dll');
    const user32 = koffi.load('user32.dll');

    // Structs
    const PROCESSENTRY32W = koffi.struct('PROCESSENTRY32W', {
      dwSize: 'uint32', cntUsage: 'uint32', th32ProcessID: 'uint32',
      th32DefaultHeapID: 'uintptr_t', th32ModuleID: 'uint32', cntThreads: 'uint32',
      th32ParentProcessID: 'uint32', pcPriClassBase: 'int32', dwFlags: 'uint32',
      szExeFile: koffi.array('uint16', 260),
    });
    const MODULEENTRY32W = koffi.struct('MODULEENTRY32W', {
      dwSize: 'uint32', th32ModuleID: 'uint32', th32ProcessID: 'uint32',
      GlblcntUsage: 'uint32', ProccntUsage: 'uint32',
      modBaseAddr: 'uintptr_t', modBaseSize: 'uint32', hModule: 'uintptr_t',
      szModule: koffi.array('uint16', 256), szExePath: koffi.array('uint16', 260),
    });
    PE_SIZE = koffi.sizeof(PROCESSENTRY32W);
    ME_SIZE = koffi.sizeof(MODULEENTRY32W);

    // Ponteiros de saída
    const PE_IO = koffi.inout(koffi.pointer(PROCESSENTRY32W));
    const ME_IO = koffi.inout(koffi.pointer(MODULEENTRY32W));
    const OUT_U32 = koffi.out(koffi.pointer('uint32'));
    const OUT_UPTR = koffi.out(koffi.pointer('uintptr_t'));

    OpenProcess = kernel32.func('OpenProcess', 'void*', ['uint32', 'int', 'uint32']);
    CloseHandle = kernel32.func('CloseHandle', 'int', ['void*']);
    CreateToolhelp32Snapshot = kernel32.func('CreateToolhelp32Snapshot', 'void*', ['uint32', 'uint32']);
    Process32FirstW = kernel32.func('Process32FirstW', 'int', ['void*', PE_IO]);
    Process32NextW = kernel32.func('Process32NextW', 'int', ['void*', PE_IO]);
    Module32FirstW = kernel32.func('Module32FirstW', 'int', ['void*', ME_IO]);
    Module32NextW = kernel32.func('Module32NextW', 'int', ['void*', ME_IO]);

    ReadProcessMemory = kernel32.func('ReadProcessMemory', 'int', ['void*', 'uintptr_t', 'void*', 'uintptr_t', OUT_UPTR]);
    WriteProcessMemory = kernel32.func('WriteProcessMemory', 'int', ['void*', 'uintptr_t', 'void*', 'uintptr_t', OUT_UPTR]);
    VirtualQueryEx = kernel32.func('VirtualQueryEx', 'uintptr_t', ['void*', 'uintptr_t', 'void*', 'uintptr_t']);
    VirtualProtectEx = kernel32.func('VirtualProtectEx', 'int', ['void*', 'uintptr_t', 'uintptr_t', 'uint32', OUT_U32]);

    NtWriteVirtualMemory = ntdll.func('NtWriteVirtualMemory', 'int32', ['void*', 'uintptr_t', 'void*', 'uintptr_t', OUT_UPTR]);
    NtReadVirtualMemory = ntdll.func('NtReadVirtualMemory', 'int32', ['void*', 'uintptr_t', 'void*', 'uintptr_t', OUT_UPTR]);
    GetExitCodeProcess = kernel32.func('GetExitCodeProcess', 'int', ['void*', OUT_U32]);
    GetProcessTimes = kernel32.func('GetProcessTimes', 'int', ['void*', 'void*', 'void*', 'void*', 'void*']);

    FindWindowW = user32.func('FindWindowW', 'uintptr_t', ['void*', 'str16']);
    GetWindowThreadProcessId = user32.func('GetWindowThreadProcessId', 'uint32', ['uintptr_t', OUT_U32]);
    GetAsyncKeyState = user32.func('GetAsyncKeyState', 'int16', ['int']);
    MapVirtualKeyW = user32.func('MapVirtualKeyW', 'uint32', ['uint32', 'uint32']);
    GetForegroundWindow = user32.func('GetForegroundWindow', 'uintptr_t', []);
    GetCursorPosFn = user32.func('GetCursorPos', 'int', ['void*']);
    // Caminho do .exe do processo → contém "version-XXXX" (build que o Roblox roda agora).
    QueryFullProcessImageNameW = kernel32.func('QueryFullProcessImageNameW', 'int', ['void*', 'uint32', 'void*', koffi.inout(koffi.pointer('uint32'))]);

    // Flick/cliques: coordenadas em pixels FÍSICOS (senão, com escala de tela 125%/150%,
    // a posição gravada e a reproduzida não batem). Tem que ser antes de qualquer janela.
    try {
      const SetProcessDpiAwarenessContext = user32.func('SetProcessDpiAwarenessContext', 'int', ['intptr_t']);
      if (!SetProcessDpiAwarenessContext(-4)) throw new Error('v2');
    } catch {
      try { user32.func('SetProcessDPIAware', 'int', [])(); } catch {}
    }
    // Timer do Windows a 1ms: deixa os tempos dos macros precisos.
    try { koffi.load('winmm.dll').func('timeBeginPeriod', 'uint32', ['uint32'])(1); } catch {}
  } catch (e) {
    LOAD_ERROR = e.message;
    console.error('[!] Erro ao carregar koffi / APIs do Windows:', e.message);
    console.error('    Rode "npm install" na pasta helper.');
    koffi = null;
  }
}

const HAS_FFI = IS_WIN && koffi !== null;

// decodifica WCHAR[] (array de uint16) ou string
function decodeWChar(val) {
  if (typeof val === 'string') return val;
  if (!val || typeof val.length !== 'number') return '';
  let s = '';
  for (let i = 0; i < val.length; i++) {
    const c = val[i];
    if (!c) break;
    s += String.fromCharCode(c);
  }
  return s;
}

// ──────────────────────── Offsets (vindos do site) ────────────────────────
//
// O Helper NÃO acessa a internet. Os offsets de FFlags chegam do site
// (POST /set-offsets), já baixados e validados no navegador, e ficam SÓ em
// memória durante esta execução. Fechou o Helper, nada fica para trás.

const RVA_MIN = 0x100000;
const RVA_MAX = 0x10000000;

let siteOffsets = null; // { version, entries: { nomeLimpo: { rva, fullName, type } } }

function setSiteOffsets(version, names, addresses) {
  const v = typeof version === 'string' ? version.trim().toLowerCase() : '';
  if (!/^version-[0-9a-f]{16}$/.test(v)) return { ok: false, message: 'Versão do dataset inválida.' };
  if (!Array.isArray(names) || !Array.isArray(addresses) || names.length !== addresses.length) {
    return { ok: false, message: "Campos 'names' e 'addresses' devem ser listas do mesmo tamanho." };
  }
  const entries = {};
  for (let i = 0; i < names.length; i++) {
    const ident = names[i], addr = addresses[i];
    if (typeof ident !== 'string' || !/^[A-Za-z_]\w{0,127}$/.test(ident)) continue;
    if (typeof addr !== 'string' || !/^0x[0-9a-fA-F]{1,8}$/.test(addr)) continue;
    const rva = parseInt(addr.slice(2), 16);
    if (rva < RVA_MIN || rva > RVA_MAX) continue;
    const clean = cleanFlagName(ident);
    if (!entries[clean]) entries[clean] = { rva, fullName: ident, type: inferTypeFromName(ident) || 'unknown' };
  }
  const count = Object.keys(entries).length;
  if (count < 500) return { ok: false, message: `Dataset com poucos offsets válidos (${count}).` };
  siteOffsets = { version: v, entries };
  return { ok: true, version: v, count, message: `Offsets do dataset ${v} carregados em memória (${count}).` };
}

const NO_OFFSETS_MSG = 'O Helper ainda não recebeu os offsets do site. Abra o site com o Helper aberto e tente de novo.';

/**
 * Portão de escrita na memória (inspirado no _live_writes_gated do FastFlag
 * Manager). Se o build dos offsets carregados ≠ build do Roblox rodando, os
 * endereços (base + rva) apontam para o lugar errado e QUALQUER escrita
 * (aplicar / toggle / cycle / PAUSE) crasha o Roblox no próximo frame.
 * Nesse caso a gente NÃO escreve e devolve o motivo — em vez de crashar.
 *
 * A versão do Roblox é identificada DE NOVO aqui, imediatamente antes da
 * escrita (o processo pode ter sido fechado/reaberto desde o attach ou durante
 * o download dos offsets). Sem versão confirmada → bloqueia (fail-closed).
 * expectedVersion: versão da configuração/dataset escolhida no site (opcional).
 */
function liveWritesGated(sourceBuild, expectedVersion) {
  const det = detectRunningRoblox();
  const norm = (v) => (v ? String(v).trim().toLowerCase() : null);
  const block = (reason, mismatch = false) => ({
    gated: true, mismatch, running: det.version, offsets: sourceBuild || null, detection: det, reason,
  });
  if (det.state !== 'running') return block(det.reason);
  if (!engine || engine.pid() !== det.pid) {
    return block('O processo do Roblox mudou durante a operação (foi fechado ou reaberto). Nada foi escrito — tente de novo.');
  }
  if (!sourceBuild) {
    return block(`Não foi possível identificar a versão dos offsets carregados. Versão em execução: ${det.version}. `
      + 'Sem a versão dos offsets não dá para garantir compatibilidade, então nada foi escrito.');
  }
  if (norm(sourceBuild) !== det.version) {
    return block(`Versão incompatível. offsets → ${norm(sourceBuild)} · processo em execução → ${det.version}. `
      + 'Escrever na memória agora apontaria para endereços errados e crasharia o Roblox. '
      + 'Atualize os offsets (ou o Roblox) para a mesma versão e tente de novo.', true);
  }
  if (expectedVersion && norm(expectedVersion) !== det.version) {
    return block('Versão incompatível. A configuração selecionada pertence a outra versão do Roblox: '
      + `configuração → ${norm(expectedVersion)} · processo em execução → ${det.version}.`, true);
  }
  return { gated: false, detection: det };
}

// Resposta padrão de bloqueio (mesmos campos que o site/console já usam).
function gatedResponse(g, extra = {}) {
  return {
    ok: false, blocked: true, buildMismatch: g.mismatch, running: g.running, offsets: g.offsets,
    detection: publicDetection(g.detection), message: g.reason, ...extra,
  };
}

// ──────────────────────── Memory Injector ────────────────────────

const TH32CS_SNAPPROCESS = 0x02;
const TH32CS_SNAPMODULE = 0x08;
const TH32CS_SNAPMODULE32 = 0x10;
const PROCESS_VM_READ = 0x0010;
const PROCESS_VM_WRITE = 0x0020;
const PROCESS_VM_OPERATION = 0x0008;
const PROCESS_QUERY_INFORMATION = 0x0400;
const PROCESS_QUERY_LIMITED_INFORMATION = 0x1000;
const PROCESS_ACCESS = PROCESS_VM_READ | PROCESS_VM_WRITE | PROCESS_VM_OPERATION | PROCESS_QUERY_INFORMATION;

// ──────────────── Identificação da versão do Roblox em execução ────────────────
//
// Mesmo princípio do RbxDumperV2 (main.cpp → init()):
//   processo RobloxPlayerBeta.exe → PID → módulos do processo →
//   módulo RobloxPlayerBeta.exe → caminho REAL do módulo → "version-…".
// A versão vem só do processo em execução. Nunca de pastas de versões no disco,
// da seleção do site ou da "última instalada": com Fishstrap/Bloxstrap pode haver
// várias versões instaladas ao mesmo tempo. Nada disto é guardado (sem cache).

const ROBLOX_EXE = 'robloxplayerbeta.exe';
const RX_VERSION_DIR = /^version-[0-9a-f]+$/i;
const INVALID_HANDLE = 0xFFFFFFFFFFFFFFFFn;

function isValidHandle(h) {
  if (!h) return false;
  try {
    const a = BigInt.asUintN(64, BigInt(koffi.address(h)));
    return a !== 0n && a !== INVALID_HANDLE && a !== 0xFFFFFFFFn;
  } catch { return true; }
}

// "…\<qualquer coisa>\version-XXXX\RobloxPlayerBeta.exe" → "version-xxxx".
// Usa a pasta que CONTÉM o .exe (layout do Roblox, Bloxstrap e Fishstrap), para
// não confundir com "version-" em outro trecho do caminho (ex.: nome de usuário).
function versionFromImagePath(p) {
  if (!p) return null;
  const parts = String(p).split(/[\\/]+/).filter(Boolean);
  if (parts.length < 2 || parts[parts.length - 1].toLowerCase() !== ROBLOX_EXE) return null;
  const dir = parts[parts.length - 2];
  return RX_VERSION_DIR.test(dir) ? dir.toLowerCase() : null;
}

// Todos os PIDs de RobloxPlayerBeta.exe (ordem crescente). null = falha ao listar.
function listRobloxPids() {
  let snap = null;
  try {
    snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (!isValidHandle(snap)) return null;
    const pids = [];
    const pe = { dwSize: PE_SIZE };
    let ok = Process32FirstW(snap, pe);
    while (ok) {
      if (decodeWChar(pe.szExeFile).toLowerCase() === ROBLOX_EXE) pids.push(pe.th32ProcessID);
      pe.dwSize = PE_SIZE;
      ok = Process32NextW(snap, pe);
    }
    return pids.sort((a, b) => a - b);
  } catch { return null; } finally {
    if (snap) { try { CloseHandle(snap); } catch {} }
  }
}

// Módulo RobloxPlayerBeta.exe DENTRO do processo: caminho real, base e tamanho
// (igual ao getModulePathByName do main.cpp). Tenta 2x: o snapshot de módulos pode
// falhar de forma transitória (ERROR_BAD_LENGTH) enquanto o processo carrega DLLs.
function robloxModuleOf(pid) {
  for (let attempt = 0; attempt < 2; attempt++) {
    let snap = null;
    try {
      snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, pid);
      if (!isValidHandle(snap)) continue;
      const me = { dwSize: ME_SIZE };
      let ok = Module32FirstW(snap, me);
      while (ok) {
        if (decodeWChar(me.szModule).toLowerCase() === ROBLOX_EXE) {
          return { path: decodeWChar(me.szExePath) || null, base: Number(me.modBaseAddr), size: Number(me.modBaseSize) };
        }
        me.dwSize = ME_SIZE;
        ok = Module32NextW(snap, me);
      }
      return null;
    } catch {} finally {
      if (snap) { try { CloseHandle(snap); } catch {} }
    }
  }
  return null;
}
function modulePathOf(pid) {
  const m = robloxModuleOf(pid);
  return m ? m.path : null;
}

// Caminho real da imagem do processo (QueryFullProcessImageNameW). Só precisa de
// PROCESS_QUERY_LIMITED_INFORMATION, então funciona mesmo sem admin na maioria dos casos.
function imagePathOf(pid) {
  let h = null;
  try {
    h = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, 0, pid);
    if (!isValidHandle(h)) return null;
    const buf = Buffer.alloc(32768 * 2);
    const size = [32768];
    if (QueryFullProcessImageNameW(h, 0, buf, size) && size[0] > 0) return buf.toString('utf16le', 0, size[0] * 2);
  } catch {} finally {
    if (h) { try { CloseHandle(h); } catch {} }
  }
  return null;
}

// Identidade + versão de UM processo. Se as duas fontes existirem e discordarem → desconhecida.
function identifyProcess(pid) {
  const modPath = modulePathOf(pid);
  const imgPath = imagePathOf(pid);
  const path = modPath || imgPath;
  if (!path) return { pid, path: null, version: null, error: 'sem acesso ao caminho do processo (rode o Helper como administrador)' };
  const vMod = versionFromImagePath(modPath);
  const vImg = versionFromImagePath(imgPath);
  if (modPath && imgPath && vMod !== vImg) return { pid, path, version: null, error: 'caminhos do processo divergentes' };
  const version = vMod || vImg;
  if (!version) return { pid, path, version: null, error: 'o executável não está dentro de uma pasta de versão (version-XXXX)' };
  return { pid, path, version, error: null };
}

// PID dono da janela "Roblox" (mesma busca do main.cpp: FindWindowA(nullptr, "Roblox")).
function robloxWindowPid() {
  try {
    const hwnd = FindWindowW(null, 'Roblox');
    if (!hwnd) return null;
    const out = [0];
    GetWindowThreadProcessId(hwnd, out);
    return out[0] || null;
  } catch { return null; }
}

/**
 * Identifica o Roblox em execução. Sempre consulta o Windows na hora (sem cache).
 *   state 'running'     → version + pid do processo que o Helper vai usar
 *   state 'not-running' → nenhum RobloxPlayerBeta.exe
 *   state 'unknown'     → não dá para afirmar com segurança (nunca chuta)
 * Várias instâncias: todas precisam ser identificadas e estar na MESMA versão;
 * senão → 'unknown'. O processo usado é o dono da janela "Roblox" (como o
 * RbxDumper) ou, se nenhuma instância tiver essa janela, o de menor PID.
 */
function detectRunningRoblox() {
  const base = { state: 'unknown', version: null, pid: null, path: null, instances: [] };
  if (!HAS_FFI) {
    return { ...base, reason: LOAD_ERROR ? `Não foi possível identificar a versão do Roblox (FFI indisponível: ${LOAD_ERROR}).` : 'Não foi possível identificar a versão do Roblox: a identificação só funciona no Windows.' };
  }
  const pids = listRobloxPids();
  if (pids === null) return { ...base, reason: 'Não foi possível identificar a versão do Roblox: falha ao listar os processos do Windows.' };
  if (!pids.length) return { ...base, state: 'not-running', reason: 'Roblox não está em execução. Abra o Roblox e entre em um jogo.' };

  const instances = pids.map(identifyProcess);
  const bad = instances.filter(i => !i.version);
  if (bad.length) {
    return { ...base, instances, reason: 'Não foi possível identificar a versão do Roblox: '
      + bad.map(i => `PID ${i.pid} — ${i.error}`).join('; ') + '.' };
  }
  const versions = [...new Set(instances.map(i => i.version))];
  if (versions.length > 1) {
    return { ...base, instances, reason: 'Não foi possível identificar a versão do Roblox: há instâncias em versões diferentes ('
      + instances.map(i => `PID ${i.pid} → ${i.version}`).join(', ') + '). Feche as instâncias extras.' };
  }
  const winPid = robloxWindowPid();
  const target = instances.find(i => i.pid === winPid) || instances[0];
  return { state: 'running', version: versions[0], pid: target.pid, path: target.path, instances, reason: `Versão em execução: ${versions[0]}` };
}

// O que vai para o site (sem caminhos completos da máquina do usuário).
function publicDetection(det) {
  if (!det) return null;
  return {
    state: det.state, version: det.version, pid: det.pid, reason: det.reason,
    instances: det.instances.map(i => ({ pid: i.pid, version: i.version })),
  };
}

// ──────────────────────── Injeção (camada do Windows) ────────────────────────
//
// A lógica de escrita fica em 633.js (validação, lote atômico, originais,
// restauração). Aqui só as chamadas ao Windows que ela usa.

const STILL_ACTIVE = 259;

function winOs() {
  return {
    openProcess(pid) {
      try { const h = OpenProcess(PROCESS_ACCESS, 0, pid); return isValidHandle(h) ? h : null; } catch { return null; }
    },
    closeHandle(h) { try { CloseHandle(h); } catch {} },
    isAlive(h) {
      try { const code = [0]; return !!GetExitCodeProcess(h, code) && code[0] === STILL_ACTIVE; } catch { return false; }
    },
    // Horário de criação do processo: distingue um Roblox reaberto com o mesmo PID.
    startTime(h) {
      try {
        const c = Buffer.alloc(8), e = Buffer.alloc(8), k = Buffer.alloc(8), u = Buffer.alloc(8);
        return GetProcessTimes(h, c, e, k, u) ? c.readBigUInt64LE(0).toString() : null;
      } catch { return null; }
    },
    moduleInfo(pid) {
      const m = robloxModuleOf(pid);
      return m && m.base && m.size ? { base: m.base, size: m.size } : null;
    },
    read(h, addr, len) {
      const buf = Buffer.alloc(len);
      try { const br = [0]; if (NtReadVirtualMemory(h, addr, buf, len, br) === 0 && Number(br[0]) === len) return buf; } catch {}
      try { const br = [0]; if (ReadProcessMemory(h, addr, buf, len, br) && Number(br[0]) === len) return buf; } catch {}
      return null;
    },
    write(h, addr, data) {
      try { const bw = [0]; if (NtWriteVirtualMemory(h, addr, data, data.length, bw) === 0 && Number(bw[0]) === data.length) return true; } catch {}
      try { const bw = [0]; if (WriteProcessMemory(h, addr, data, data.length, bw) && Number(bw[0]) === data.length) return true; } catch {}
      return false;
    },
    protect(h, addr, len, prot) {
      try { const old = [0]; return VirtualProtectEx(h, addr, len, prot, old) ? old[0] : null; } catch { return null; }
    },
    query(h, addr) {
      try {
        const mbi = Buffer.alloc(48); // MEMORY_BASIC_INFORMATION (x64)
        if (Number(VirtualQueryEx(h, addr, mbi, 48)) < 48) return null;
        return { base: Number(mbi.readBigUInt64LE(0)), size: Number(mbi.readBigUInt64LE(24)), state: mbi.readUInt32LE(32), protect: mbi.readUInt32LE(36) };
      } catch { return null; }
    },
  };
}

const engine = HAS_FFI ? createFlagEngine(winOs(), { log: dbg }) : null;

/**
 * Prepara qualquer escrita: identifica o Roblox AGORA, conecta a ESSE processo,
 * exige offsets do site da mesma versão. Devolve { entries } ou { error }.
 */
function liveSession(expectedVersion) {
  if (!HAS_FFI) return { error: { ok: false, message: LOAD_ERROR ? `FFI indisponível: ${LOAD_ERROR}` : 'A injeção só funciona no Windows.' } };
  const det = detectRunningRoblox();
  if (det.state !== 'running') return { error: { ok: false, blocked: true, detection: publicDetection(det), message: det.reason } };
  const att = engine.attach(det.pid);
  if (!att.ok) return { error: { ok: false, blocked: true, detection: publicDetection(det), message: att.message } };
  if (!siteOffsets) return { error: { ok: false, blocked: true, message: NO_OFFSETS_MSG } };
  const g = liveWritesGated(siteOffsets.version, expectedVersion);
  if (g.gated) return { error: gatedResponse(g) };
  return { entries: siteOffsets.entries, version: siteOffsets.version };
}

const entryOf = (entries, name) => entries[cleanFlagName(name)] || entries[name] || null;

function getStatus() {
  // Identificação feita na hora, a partir do processo (nada reaproveitado de antes).
  const det = detectRunningRoblox();
  const robloxRunning = det.instances.length > 0;
  const pid = det.pid;
  const runningBuild = det.state === 'running' ? det.version : null;
  const offsetsBuild = siteOffsets ? siteOffsets.version : null;
  const buildMatch = runningBuild && offsetsBuild ? runningBuild === offsetsBuild : null;
  return {
    ok: true, helper: 'gerenciador-helper', helperVersion: HELPER_VERSION,
    platform: process.platform, method: 'memory-injection', macros: true,
    ffiReady: HAS_FFI, loadError: LOAD_ERROR,
    robloxFound: robloxRunning, robloxPid: pid,
    startedAt: STARTED_AT,
    runningBuild, offsetsBuild, buildMatch,
    siteOffsetsBuild: offsetsBuild,
    detection: publicDetection(det),
    canApply: HAS_FFI && robloxRunning,
    alteredFlags: engine && engine.pid() === pid ? engine.liveCount() : 0,
  };
}

const plural = (n, um, varios) => `${n} ${n === 1 ? um : varios}`;

async function applyFlags(flags, expectedVersion) {
  const names = Object.keys(flags);
  const ctx = liveSession(expectedVersion);
  if (ctx.error) return { applied: 0, skipped: names, ...ctx.error };
  const r = engine.apply(names.map(name => ({ name, entry: entryOf(ctx.entries, name), value: flags[name] })));
  const applied = r.applied.length;
  // Resumo no console (só na janela do help.bat; nada é gravado em arquivo).
  console.log(`  [APLICAR] ${applied}/${names.length} aplicadas${r.rolledBack ? ` · lote desfeito (${r.rolledBack})` : ''}`);
  for (const f of r.skipped.slice(0, 15)) console.log(`    ✕ ${f.flag}: ${f.reason}`);
  if (r.skipped.length > 15) console.log(`    … e mais ${r.skipped.length - 15}`);
  const message = r.message
    || (applied === names.length ? `Todas as ${plural(applied, 'configuração aplicada', 'configurações aplicadas')} na memória.`
      : applied > 0 ? `${applied}/${names.length} configurações aplicadas. ${plural(r.skipped.length, 'ignorada', 'ignoradas')} (veja os motivos).`
      : 'Nenhuma configuração foi aplicada.')
    + (r.skipped.length && !r.message ? ' ' + r.skipped.slice(0, 3).map(f => `${f.flag}: ${f.reason}`).join(' · ') : '');
  return { ok: applied > 0, applied, skipped: r.skipped.map(f => f.flag), failures: r.skipped, rolledBack: r.rolledBack || 0, message, sourceBuild: ctx.version };
}

async function toggleFlag(name, flags, expectedVersion) {
  const ctx = liveSession(expectedVersion);
  if (ctx.error) return ctx.error;
  // Padrão DESLIGADO: o 1º toque LIGA (aplica o valor do preset), o 2º DESLIGA (volta ao original).
  if (engine.isLive(name)) {
    const r = engine.restore([name]);
    const done = r.restored[0];
    if (done) return { ok: true, enabled: false, flag: name, value: done.value, message: `⭘ '${name}' DESLIGADA → ${done.value}` };
    return { ok: false, enabled: true, flag: name, message: `'${name}' não foi desligada: ${r.failed[0] ? r.failed[0].reason : 'erro desconhecido'}` };
  }
  const value = flags[name];
  if (value == null || String(value) === '') return { ok: false, message: `Configuração '${name}' não tem valor definido no preset.` };
  const r = engine.apply([{ name, entry: entryOf(ctx.entries, name), value }]);
  if (r.ok) return { ok: true, enabled: true, flag: name, value: engine.liveValue(name), message: `✅ '${name}' LIGADA → ${engine.liveValue(name)}` };
  return { ok: false, enabled: false, flag: name, message: `Falha ao ligar '${name}': ${r.message || (r.skipped[0] && r.skipped[0].reason)}` };
}

async function cycleFlag(name, cycleValues, flags, expectedVersion) {
  if (!Array.isArray(cycleValues) || cycleValues.length < 2) return { ok: false, message: 'Precisa de pelo menos 2 valores.' };
  const ctx = liveSession(expectedVersion);
  if (ctx.error) return ctx.error;
  const vals = cycleValues.map(String);
  const current = engine.liveValue(name) ?? (flags[name] != null ? String(flags[name]) : null);
  const idx = vals.indexOf(current);
  const nextIdx = (idx + 1) % vals.length;
  const r = engine.apply([{ name, entry: entryOf(ctx.entries, name), value: vals[nextIdx] }]);
  if (!r.ok) return { ok: false, flag: name, message: `Falha ao ciclar '${name}': ${r.message || (r.skipped[0] && r.skipped[0].reason)}` };
  return { ok: true, flag: name, value: engine.liveValue(name), cycleIndex: nextIdx, message: `Configuração '${name}' ciclada para: ${engine.liveValue(name)}` };
}

/**
 * Pausa: volta ao valor original exato tudo o que o Helper alterou neste processo
 * do Roblox (ordem inversa). O que não foi alterado não é tocado.
 */
async function pauseAllFlags(_presetFlags, expectedVersion) {
  const ctx = liveSession(expectedVersion);
  if (ctx.error) return { reverted: 0, failed: 0, ...ctx.error, message: ctx.error.buildMismatch ? 'Pause cancelado para não crashar o Roblox: ' + ctx.error.message : ctx.error.message };
  const r = engine.restore();
  const reverted = r.restored.length, failed = r.failed.length;
  console.log(`  [PAUSAR] ${reverted} restauradas${failed ? `, ${failed} falharam` : ''}`);
  for (const f of r.failed.slice(0, 15)) console.log(`    ✕ ${f.flag}: ${f.reason}`);
  return {
    ok: failed === 0, reverted, failed, failures: r.failed, total: reverted + failed,
    message: reverted + failed === 0 ? 'Nada para pausar: nenhuma configuração foi alterada neste Roblox.'
      : `Configurações pausadas: ${plural(reverted, 'voltou', 'voltaram')} ao valor original`
        + (failed ? `, ${plural(failed, 'falhou', 'falharam')} (${r.failed.slice(0, 3).map(f => `${f.flag}: ${f.reason}`).join(' · ')})` : '') + '.',
  };
}

async function resumeAllFlags(flags, expectedVersion) {
  return applyFlags(flags, expectedVersion);
}

// ──────────────────────── Hotkey Listener ────────────────────────

let hotkeyConfig = {};
let hotkeyFlags = {};
let hotkeyRunning = false;

// Mapa code -> VK respeitando o layout atual do Windows (ABNT2, US…).
// Aceita qualquer tecla que o site capture (KeyboardEvent.code) + botões do mouse.
const codeToVk = keymap.makeCodeToVk(MapVirtualKeyW ? (a, b) => MapVirtualKeyW(a, b) : null);

// Debounce por (flag, ação): evita disparo duplo e spam de scroll.
const DEBOUNCE_MS = 180;
const lastFire = {};

function fireAction(fname, action) {
  const key = fname + '|' + action;
  const now = Date.now();
  if (now - (lastFire[key] || 0) < DEBOUNCE_MS) return; // debounce
  lastFire[key] = now;
  // Saída em tempo real no CMD, SÓ no momento da hotkey. Não é gravada em lugar
  // nenhum (sem .log/.txt/histórico); é apenas console enquanto o Helper roda.
  if (action === 'toggle') {
    toggleFlag(fname, hotkeyFlags)
      .then(r => {
        if (r.buildMismatch) console.log(`  [CONFIG] ${fname} = IGNORADO (versão incompatível — nada escrito)`);
        else if (r.blocked) console.log(`  [CONFIG] ${fname} = IGNORADO (${r.message})`);
        else if (r.ok) console.log(`  [CONFIG] ${fname} = ${r.enabled ? 'ON' : 'OFF'}${r.value != null ? ' -> ' + r.value : ''}`);
        else console.log(`  [CONFIG] ${fname} = FALHOU (${r.message})`);
      })
      .catch(e => console.log(`  [CONFIG] ${fname} = ERRO (${e.message})`));
  } else {
    const cv = (hotkeyConfig[fname] && hotkeyConfig[fname].cycleValues) || [];
    if (cv.length >= 2) {
      cycleFlag(fname, cv, hotkeyFlags)
        .then(r => {
          if (r.buildMismatch) console.log(`  [CONFIG] ${fname} = IGNORADO (versão incompatível — nada escrito)`);
          else if (r.blocked) console.log(`  [CONFIG] ${fname} = IGNORADO (${r.message})`);
          else if (r.ok) console.log(`  [CONFIG] ${fname} = CYCLE -> ${r.value}`);
          else console.log(`  [CONFIG] ${fname} = FALHOU (${r.message})`);
        })
        .catch(e => console.log(`  [CONFIG] ${fname} = ERRO (${e.message})`));
    } else {
      console.log(`  [CONFIG] ${fname} = CYCLE precisa de 2+ valores configurados`);
    }
  }
}

// Dispara toggle/cycle para toda flag vinculada a este "code" (tecla ou botão/scroll).
function triggerForCode(code) {
  for (const [fname, hk] of Object.entries(hotkeyConfig)) {
    if (hk.toggleKey === code) fireAction(fname, 'toggle');
    if (hk.cycleKey === code) fireAction(fname, 'cycle');
  }
}

// ---- Sistema de ações (100% em memória: nada é salvo no PC) ----
const cursorBuf = Buffer.alloc(8);
const macroSys = createMacroSystem({
  codeToVk,
  isWin: IS_WIN,
  hasFfi: HAS_FFI,
  log: (...a) => console.log(...a),   // erros/essencial (sempre)
  verbose: DEBUG,                       // atividade por-evento só em debug
  getRobloxPid: () => { if (!HAS_FFI) return null; const p = listRobloxPids(); return p && p.length ? p[0] : null; },
  getForegroundPid: () => {
    if (!HAS_FFI) return null;
    try {
      const hwnd = GetForegroundWindow();
      if (!hwnd) return null;
      const pid = [0];
      GetWindowThreadProcessId(hwnd, pid);
      return pid[0] || null;
    } catch { return null; }
  },
  getCursor: HAS_FFI ? () => (GetCursorPosFn(cursorBuf) ? { x: cursorBuf.readInt32LE(0), y: cursorBuf.readInt32LE(4) } : null) : null,
});

// ---- Hook global de entrada (worker separado): scroll + gravação de ações ----
let inputWorker = null;
let inputHookStarted = false; // só tenta uma vez por execução (evita respawn)
const hookShared = new Int32Array(new SharedArrayBuffer(16));
const hookHandle = { shared: hookShared, ready: false };
function startInputHook() {
  if (inputWorker || inputHookStarted || !IS_WIN) return;
  inputHookStarted = true;
  macroSys.attachHook(hookHandle);
  try {
    const { Worker } = require('worker_threads');
    inputWorker = new Worker(path.join(__dirname, '609.js'), { workerData: { shared: hookShared.buffer } });
    inputWorker.on('message', (m) => {
      if (!m) return;
      if (m.type === 'rec') macroSys.onRecEvent(m);
      else if (m.type === 'input' && m.code) { triggerForCode(m.code); macroSys.onDown(m.code); }
      else if (m.type === 'rec-stop') macroSys.stopRecording('tecla de parada');
      else if (m.type === 'ready') { hookHandle.ready = true; console.log('  ✓ Hook global ativo (scroll nas hotkeys + gravação de ações).'); }
      else if (m.type === 'warn') console.log('  [hook]', m.error);
      else if (m.type === 'error') console.log('  [hook] indisponível:', m.error, '(scroll e gravação de ação não vão funcionar; teclas e botões seguem ok)');
    });
    inputWorker.on('error', (e) => { console.log('  [hook] erro no worker:', e.message); inputWorker = null; hookHandle.ready = false; });
    inputWorker.on('exit', () => { inputWorker = null; hookHandle.ready = false; });
  } catch (e) {
    console.log('  [hook] não iniciou:', e.message);
  }
}

/**
 * Loop único de polling (GetAsyncKeyState lê o estado GLOBAL de teclado e mouse,
 * por isso funciona com o Roblox em foco). Observa:
 *   - hotkeys de flags (toggle/cycle)  → borda de subida
 *   - gatilhos de macro + tecla de parada → subida e descida (modo "segurar")
 * Bordas causadas por teclas que o PRÓPRIO macro injetou são ignoradas.
 */
function startHotkeyListener() {
  startInputHook();
  if (hotkeyRunning || !HAS_FFI) return;
  hotkeyRunning = true;
  const prevState = {}; // por code-string: estado da tecla/botão no poll anterior
  const poll = () => {
    if (!hotkeyRunning) return;
    const flagCodes = new Set();
    for (const hk of Object.values(hotkeyConfig)) {
      if (hk.toggleKey) flagCodes.add(hk.toggleKey);
      if (hk.cycleKey) flagCodes.add(hk.cycleKey);
    }
    const macroCodes = macroSys.watchedCodes();
    const all = new Set([...flagCodes, ...macroCodes]);
    for (const code of all) {
      const vk = codeToVk(code);
      if (!vk) continue; // ScrollUp/Down vêm do hook, não do polling
      let pressed = false;
      try { pressed = (GetAsyncKeyState(vk) & 0x8000) !== 0; } catch {}
      const was = !!prevState[code];
      prevState[code] = pressed;
      if (pressed === was) continue;
      if (pressed) {
        if (macroSys.isSelfInjected(code)) continue; // fomos nós (macro) que apertamos
        if (flagCodes.has(code)) triggerForCode(code);
        if (macroCodes.has(code)) macroSys.onDown(code);
      } else if (macroCodes.has(code)) {
        macroSys.onUp(code);
      }
    }
    setTimeout(poll, 15);
  };
  setTimeout(poll, 15);
}

// ──────────────────────── HTTP Server ────────────────────────

function readBody(req) {
  return new Promise((resolve) => {
    const chunks = []; let size = 0;
    req.on('data', (c) => { size += c.length; if (size > 4 * 1024 * 1024) { resolve(null); req.destroy(); return; } chunks.push(c); });
    req.on('end', () => { try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}')); } catch { resolve(null); } });
    req.on('error', () => resolve(null));
  });
}

function sendJson(res, obj, code = 200) {
  const body = JSON.stringify(obj);
  res.writeHead(code, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Length': Buffer.byteLength(body),
  });
  res.end(body);
}

// Helper só com API local (127.0.0.1): não serve o site nem lê/grava arquivos.
// O site é hospedado à parte e conversa com o Helper via CORS.

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
      // Permite que um site HTTPS público acesse este helper em localhost
      // (modelo antigo de Private Network Access do Chrome). Inofensivo nos demais.
      'Access-Control-Allow-Private-Network': 'true',
    });
    res.end(); return;
  }
  const rawPath = (req.url || '').split('?')[0].replace(/\/+$/, '');
  const urlPath = rawPath || '/status';

  if (req.method === 'GET') {
    // API: /status responde JSON. (Se o site estiver embutido, use / para o site.)
    if (urlPath === '/status') return sendJson(res, getStatus());
    if (urlPath === '/debug') {
      const det = detectRunningRoblox();
      const pid = det.pid;
      if (det.state === 'running' && engine) engine.attach(pid);
      return sendJson(res, { ffiReady: HAS_FFI, loadError: LOAD_ERROR, peSize: PE_SIZE, meSize: ME_SIZE, robloxPid: pid, injection: engine ? engine.info() : null, detection: publicDetection(det) });
    }
    // ── Macros ──
    if (urlPath === '/macros') return sendJson(res, { ok: true, ...macroSys.getConfig() });
    if (urlPath === '/macro/state') return sendJson(res, macroSys.state());
    if (urlPath === '/macro/record/status') return sendJson(res, { ok: true, ...macroSys.recordingStatus() });
    if (urlPath === '/' || urlPath === '') return sendJson(res, getStatus());
    return sendJson(res, { ok: false, message: 'rota desconhecida' }, 404);
  }

  if (req.method === 'POST') {
    const data = await readBody(req);
    if (data === null) return sendJson(res, { ok: false, message: 'JSON inválido' }, 400);
    switch (urlPath) {
      case '/apply': {
        if (!data.flags || typeof data.flags !== 'object') return sendJson(res, { ok: false, message: "campo 'flags' deve ser um objeto" }, 400);
        return sendJson(res, await applyFlags(data.flags, data.dumpVersion));
      }
      case '/set-offsets':
        return sendJson(res, setSiteOffsets(data.version, data.names, data.addresses));
      case '/restore':
        return sendJson(res, await pauseAllFlags(null, data.dumpVersion));
      case '/toggle':
        if (!data.name) return sendJson(res, { ok: false, message: "campo 'name' é obrigatório" }, 400);
        return sendJson(res, await toggleFlag(data.name, data.flags || {}, data.dumpVersion));
      case '/cycle':
        if (!data.name) return sendJson(res, { ok: false, message: "campo 'name' é obrigatório" }, 400);
        return sendJson(res, await cycleFlag(data.name, data.cycleValues || [], data.flags || {}, data.dumpVersion));
      case '/pause':
        return sendJson(res, await pauseAllFlags(data.flags || null, data.dumpVersion));
      case '/resume':
        return sendJson(res, await resumeAllFlags(data.flags || {}, data.dumpVersion));
      case '/set-hotkeys':
        hotkeyConfig = data.hotkeys || {}; hotkeyFlags = data.flags || {}; startHotkeyListener();
        return sendJson(res, { ok: true, message: `${Object.keys(hotkeyConfig).length} hotkeys configuradas.` });
      // ── Macros ──
      case '/set-macros': {
        const r = macroSys.setConfig({ macros: data.macros, settings: data.settings });
        startHotkeyListener();
        return sendJson(res, { ok: true, ...r, message: `${r.count} ação(ões) sincronizada(s), ${r.active} com gatilho ativo.` });
      }
      case '/macro/run': {
        if (!data.macro || typeof data.macro !== 'object') return sendJson(res, { ok: false, message: "campo 'macro' é obrigatório" }, 400);
        startHotkeyListener();
        return sendJson(res, macroSys.run(data.macro, { countdown: Math.min(10000, Math.max(0, Number(data.countdown) || 0)) }));
      }
      case '/macro/stop': {
        const n = data.id ? (macroSys.stop(String(data.id)) ? 1 : 0) : macroSys.stopAll();
        return sendJson(res, { ok: true, stopped: n, message: n ? `${n} macro(s) parado(s).` : 'Nenhum macro rodando.' });
      }
      case '/macro/record/start':
        startHotkeyListener();
        return sendJson(res, macroSys.startRecording(data));
      case '/macro/record/stop':
        return sendJson(res, macroSys.stopRecording('parado pelo site'));
      case '/macro/cursor':
        return sendJson(res, await macroSys.pickCursor(data.delay));
      default:
        return sendJson(res, { ok: false, message: 'rota desconhecida' }, 404);
    }
  }
  sendJson(res, { ok: false, message: 'método não permitido' }, 405);
});

// ──────────────────────── Autoteste / Startup ────────────────────────

function selfTest() {
  console.log('── Autoteste de detecção ──');
  console.log(`FFI pronto: ${HAS_FFI}${LOAD_ERROR ? ' (erro: ' + LOAD_ERROR + ')' : ''}`);
  console.log(`sizeof PROCESSENTRY32W = ${PE_SIZE}, MODULEENTRY32W = ${ME_SIZE}`);
  if (!HAS_FFI) { console.log('FFI não disponível — abortando teste.'); return; }
  const det = detectRunningRoblox();
  for (const i of det.instances) console.log(`Instância PID ${i.pid}: ${i.version ?? 'versão desconhecida'}${i.path ? ' — ' + i.path : ''}${i.error ? ' (' + i.error + ')' : ''}`);
  console.log(det.reason);
  const pid = det.pid;
  console.log(`Roblox PID usado pelo Helper: ${pid ?? 'nenhum'}`);
  if (pid) {
    const att = engine.attach(pid);
    console.log(att.ok ? `Processo aberto: base ${engine.info().base}, ${engine.info().moduleSize} bytes` : `Falhou: ${att.message}`);
  } else if (det.state === 'not-running') {
    console.log('→ Abra o Roblox e entre em um jogo. Se já estiver aberto, rode como administrador.');
  }
  console.log('───────────────────────────');
}

if (process.argv.includes('--test')) {
  selfTest();
  process.exit(0);
}

const port = parseInt(process.argv[2]) || DEFAULT_PORT;

function tryListen(p, tries = 5) {
  server.listen(p, '127.0.0.1', () => {
    const st = getStatus();
    console.log('┌─ Painel do BOPE — Helper Local [Node.js · sem internet]');
    console.log(`│  versão ${HELPER_VERSION} · http://127.0.0.1:${p}`);
    console.log(`│  FFI pronto: ${HAS_FFI}${LOAD_ERROR ? ' — ' + LOAD_ERROR : ''}`);
    console.log(`│  Roblox: ${st.detection ? st.detection.reason : 'não detectado — abra o Roblox e entre em um jogo'}${st.robloxPid ? ` (PID ${st.robloxPid})` : ''}`);
    console.log('│  Abra o SITE (hospedado) no navegador — ele fala com este Helper em 127.0.0.1.');
    if (!IS_WIN) console.log('│  ⚠ Injeção em memória só funciona no Windows');
    console.log('│  Hotkeys (teclado + botões do mouse) funcionam GLOBALMENTE, mesmo com o Roblox em foco.');
    console.log('│  100% em memória: o Helper NÃO grava nada no seu PC (config fica no site).');
    const mc = macroSys.getConfig();
    console.log(`│  Ações: ${mc.macros.length} em memória · tecla de parada ${mc.settings.stopKey || 'F8'}${IS_WIN ? '' : ' · (fora do Windows: execução simulada)'}`);
    console.log('│  Dica: "node 626.js --test" testa só a detecção.');
    console.log('└─ Ctrl+C para encerrar.');
  });
  server.on('error', (e) => {
    if (e.code === 'EADDRINUSE' && tries > 1) {
      console.log(`[!] porta ${p} ocupada, tentando ${p + 1}…`);
      server.close();
      tryListen(p + 1, tries - 1);
    } else { console.error(`[x] não consegui abrir porta: ${e.message}`); process.exit(1); }
  });
}

tryListen(port);
startHotkeyListener(); // começa a ouvir hotkeys/ações assim que o site enviar a config

// Ctrl+C: para os macros (eles soltam teclas/botões segurados) antes de sair.
process.on('SIGINT', () => {
  try { macroSys.stopAll(); } catch {}
  setTimeout(() => { try { macroSys.shutdown(); } catch {} process.exit(0); }, 200);
});
