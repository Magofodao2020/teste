#!/usr/bin/env node
/**
 * Painel do BOPE — Helper Local (Node.js)
 * =============================================================
 *
 * Executa as ações e escreve as flags dos presets na memória do Roblox em
 * execução, usando os offsets que o SITE envia. Sem internet, sem arquivos:
 * tudo fica em memória enquanto o Helper está aberto.
 *
 * Requisitos: Node.js 18+, Windows, Roblox rodando (como admin de preferência)
 * Uso: npm install && node 626.js
 *      node 626.js --test   (só testa a detecção do Roblox e sai)
 */

const http = require('http');
const path = require('path');
const keymap = require('./569');
const { createMacroSystem } = require('./521');

const HELPER_VERSION = '2.3.1';
// Identifica esta execução (o site reenvia offsets/ações/atalhos quando muda).
const STARTED_AT = Date.now();
const DEFAULT_PORT = 7962;
// Atividade por-evento no console só em modo debug (nunca é gravada em arquivo).
const DEBUG = process.env.GERENCIADOR_DEBUG === '1' || process.argv.includes('--verbose');
const dbg = (...a) => { if (DEBUG) console.log(...a); };

// ──────────────────────── Windows API (koffi) ────────────────────────

let koffi = null;
let IS_WIN = process.platform === 'win32';
let LOAD_ERROR = null;

// bindings
let OpenProcess, CloseHandle, CreateToolhelp32Snapshot;
let Process32FirstW, Process32NextW, Module32FirstW, Module32NextW;
let ReadProcessMemory, WriteProcessMemory, VirtualQueryEx;
let NtWriteVirtualMemory, NtReadVirtualMemory, NtQueryInformationProcess;
let FindWindowW, GetWindowThreadProcessId, GetAsyncKeyState;
let MapVirtualKeyW, GetForegroundWindow, GetCursorPosFn;
let QueryFullProcessImageNameW;
let PE_SIZE = 568, ME_SIZE = 1080;

if (IS_WIN) {
  try {
    koffi = require('koffi');

    const kernel32 = koffi.load('kernel32.dll');
    const ntdll = koffi.load('ntdll.dll');
    const user32 = koffi.load('user32.dll');

    // Structs
    const PROCESSENTRY32W = koffi.struct('PROCESSENTRY32W', {
      dwSize: 'uint32', cntUsage: 'uint32', th32ProcessID: 'uint32',
      th32DefaultHeapID: 'uintptr_t', th32ModuleID: 'uint32', cntThreads: 'uint32',
      th32ParentProcessID: 'uint32', pcPriClassBase: 'int32', dwFlags: 'uint32',
      szExeFile: koffi.array('uint16', 260),
    });
    const MODULEENTRY32W = koffi.struct('MODULEENTRY32W', {
      dwSize: 'uint32', th32ModuleID: 'uint32', th32ProcessID: 'uint32',
      GlblcntUsage: 'uint32', ProccntUsage: 'uint32',
      modBaseAddr: 'uintptr_t', modBaseSize: 'uint32', hModule: 'uintptr_t',
      szModule: koffi.array('uint16', 256), szExePath: koffi.array('uint16', 260),
    });
    PE_SIZE = koffi.sizeof(PROCESSENTRY32W);
    ME_SIZE = koffi.sizeof(MODULEENTRY32W);

    // Ponteiros de saída
    const PE_IO = koffi.inout(koffi.pointer(PROCESSENTRY32W));
    const ME_IO = koffi.inout(koffi.pointer(MODULEENTRY32W));
    const OUT_U32 = koffi.out(koffi.pointer('uint32'));
    const OUT_UPTR = koffi.out(koffi.pointer('uintptr_t'));

    OpenProcess = kernel32.func('OpenProcess', 'void*', ['uint32', 'int', 'uint32']);
    CloseHandle = kernel32.func('CloseHandle', 'int', ['void*']);
    CreateToolhelp32Snapshot = kernel32.func('CreateToolhelp32Snapshot', 'void*', ['uint32', 'uint32']);
    Process32FirstW = kernel32.func('Process32FirstW', 'int', ['void*', PE_IO]);
    Process32NextW = kernel32.func('Process32NextW', 'int', ['void*', PE_IO]);
    Module32FirstW = kernel32.func('Module32FirstW', 'int', ['void*', ME_IO]);
    Module32NextW = kernel32.func('Module32NextW', 'int', ['void*', ME_IO]);

    ReadProcessMemory = kernel32.func('ReadProcessMemory', 'int', ['void*', 'uintptr_t', 'void*', 'uintptr_t', OUT_UPTR]);
    WriteProcessMemory = kernel32.func('WriteProcessMemory', 'int', ['void*', 'uintptr_t', 'void*', 'uintptr_t', OUT_UPTR]);
    VirtualQueryEx = kernel32.func('VirtualQueryEx', 'uintptr_t', ['void*', 'uintptr_t', 'void*', 'uintptr_t']);

    NtWriteVirtualMemory = ntdll.func('NtWriteVirtualMemory', 'int32', ['void*', 'uintptr_t', 'void*', 'uintptr_t', OUT_UPTR]);
    NtReadVirtualMemory = ntdll.func('NtReadVirtualMemory', 'int32', ['void*', 'uintptr_t', 'void*', 'uintptr_t', OUT_UPTR]);
    NtQueryInformationProcess = ntdll.func('NtQueryInformationProcess', 'int32', ['void*', 'uint32', 'void*', 'uint32', OUT_U32]);

    FindWindowW = user32.func('FindWindowW', 'uintptr_t', ['void*', 'str16']);
    GetWindowThreadProcessId = user32.func('GetWindowThreadProcessId', 'uint32', ['uintptr_t', OUT_U32]);
    GetAsyncKeyState = user32.func('GetAsyncKeyState', 'int16', ['int']);
    MapVirtualKeyW = user32.func('MapVirtualKeyW', 'uint32', ['uint32', 'uint32']);
    GetForegroundWindow = user32.func('GetForegroundWindow', 'uintptr_t', []);
    GetCursorPosFn = user32.func('GetCursorPos', 'int', ['void*']);
    // Caminho do .exe do processo → contém "version-XXXX" (build que o Roblox roda agora).
    QueryFullProcessImageNameW = kernel32.func('QueryFullProcessImageNameW', 'int', ['void*', 'uint32', 'void*', koffi.inout(koffi.pointer('uint32'))]);

    // Flick/cliques: coordenadas em pixels FÍSICOS (senão, com escala de tela 125%/150%,
    // a posição gravada e a reproduzida não batem). Tem que ser antes de qualquer janela.
    try {
      const SetProcessDpiAwarenessContext = user32.func('SetProcessDpiAwarenessContext', 'int', ['intptr_t']);
      if (!SetProcessDpiAwarenessContext(-4)) throw new Error('v2');
    } catch {
      try { user32.func('SetProcessDPIAware', 'int', [])(); } catch {}
    }
    // Timer do Windows a 1ms: deixa os tempos dos macros precisos.
    try { koffi.load('winmm.dll').func('timeBeginPeriod', 'uint32', ['uint32'])(1); } catch {}
  } catch (e) {
    LOAD_ERROR = e.message;
    console.error('[!] Erro ao carregar koffi / APIs do Windows:', e.message);
    console.error('    Rode "npm install" na pasta helper.');
    koffi = null;
  }
}

const HAS_FFI = IS_WIN && koffi !== null;

// decodifica WCHAR[] (array de uint16) ou string
function decodeWChar(val) {
  if (typeof val === 'string') return val;
  if (!val || typeof val.length !== 'number') return '';
  let s = '';
  for (let i = 0; i < val.length; i++) {
    const c = val[i];
    if (!c) break;
    s += String.fromCharCode(c);
  }
  return s;
}

// ──────────────────────── Prefixos / tipos ────────────────────────

const PREFIX_TYPE = [
  ['DFFlag', 'bool'], ['SFFlag', 'bool'], ['FFlag', 'bool'], ['GFFlag', 'bool'],
  ['DFInt', 'int'], ['SFInt', 'int'], ['FInt', 'int'],
  ['DFLog', 'int'], ['FLog', 'int'],
  ['DFFloat', 'float'], ['SFFloat', 'float'], ['FFloat', 'float'],
  ['DFString', 'string'], ['SFString', 'string'], ['FString', 'string'],
];
const SORTED_PREFIXES = PREFIX_TYPE.map(p => p[0]).sort((a, b) => b.length - a.length);

function inferTypeFromName(name) {
  for (const [pre, t] of PREFIX_TYPE) if (name.startsWith(pre)) return t;
  return null;
}
function cleanFlagName(name) {
  for (const pre of SORTED_PREFIXES) if (name.startsWith(pre)) return name.slice(pre.length);
  return name;
}
function inferType(val) {
  const s = String(val).toLowerCase().trim();
  if (s === 'true' || s === 'false') return 'bool';
  if (s !== '' && !isNaN(Number(s))) return s.includes('.') ? 'float' : 'int';
  return 'string';
}

// ──────────────────────── Offsets (vindos do site) ────────────────────────
//
// O Helper NÃO acessa a internet. Os offsets de FFlags chegam do site
// (POST /set-offsets), já baixados e validados no navegador, e ficam SÓ em
// memória durante esta execução. Fechou o Helper, nada fica para trás.

const RVA_MIN = 0x100000;
const RVA_MAX = 0x10000000;

let siteOffsets = null; // { version, entries: { nomeLimpo: { rva, fullName, type } } }

function setSiteOffsets(version, names, addresses) {
  const v = typeof version === 'string' ? version.trim().toLowerCase() : '';
  if (!/^version-[0-9a-f]{16}$/.test(v)) return { ok: false, message: 'Versão do dataset inválida.' };
  if (!Array.isArray(names) || !Array.isArray(addresses) || names.length !== addresses.length) {
    return { ok: false, message: "Campos 'names' e 'addresses' devem ser listas do mesmo tamanho." };
  }
  const entries = {};
  for (let i = 0; i < names.length; i++) {
    const ident = names[i], addr = addresses[i];
    if (typeof ident !== 'string' || !/^[A-Za-z_]\w{0,127}$/.test(ident)) continue;
    if (typeof addr !== 'string' || !/^0x[0-9a-fA-F]{1,8}$/.test(addr)) continue;
    const rva = parseInt(addr.slice(2), 16);
    if (rva < RVA_MIN || rva > RVA_MAX) continue;
    const clean = cleanFlagName(ident);
    if (!entries[clean]) entries[clean] = { rva, fullName: ident, type: inferTypeFromName(ident) || 'unknown' };
  }
  const count = Object.keys(entries).length;
  if (count < 500) return { ok: false, message: `Dataset com poucos offsets válidos (${count}).` };
  siteOffsets = { version: v, entries };
  return { ok: true, version: v, count, message: `Offsets do dataset ${v} carregados em memória (${count}).` };
}

/** Offsets recebidos do site, com o endereço absoluto no processo atual. */
function loadOffsets(baseAddr) {
  if (!siteOffsets) return { flagOffsets: {}, sourceBuild: null };
  const flagOffsets = {};
  for (const [k, v] of Object.entries(siteOffsets.entries)) flagOffsets[k] = { ...v, absAddr: baseAddr + v.rva };
  return { flagOffsets, sourceBuild: siteOffsets.version };
}

const NO_OFFSETS_MSG = 'O Helper ainda não recebeu os offsets do site. Abra o site com o Helper aberto e tente de novo.';

/**
 * Portão de escrita na memória (inspirado no _live_writes_gated do FastFlag
 * Manager). Se o build dos offsets carregados ≠ build do Roblox rodando, os
 * endereços (base + rva) apontam para o lugar errado e QUALQUER escrita
 * (aplicar / toggle / cycle / PAUSE) crasha o Roblox no próximo frame.
 * Nesse caso a gente NÃO escreve e devolve o motivo — em vez de crashar.
 *
 * A versão do Roblox é identificada DE NOVO aqui, imediatamente antes da
 * escrita (o processo pode ter sido fechado/reaberto desde o attach ou durante
 * o download dos offsets). Sem versão confirmada → bloqueia (fail-closed).
 * expectedVersion: versão da configuração/dataset escolhida no site (opcional).
 */
function liveWritesGated(sourceBuild, expectedVersion) {
  const det = detectRunningRoblox();
  const norm = (v) => (v ? String(v).trim().toLowerCase() : null);
  const block = (reason, mismatch = false) => ({
    gated: true, mismatch, running: det.version, offsets: sourceBuild || null, detection: det, reason,
  });
  if (det.state !== 'running') return block(det.reason);
  if (!injector || injector.pid !== det.pid) {
    return block('O processo do Roblox mudou durante a operação (foi fechado ou reaberto). Nada foi escrito — tente de novo.');
  }
  if (!sourceBuild) {
    return block(`Não foi possível identificar a versão dos offsets carregados. Versão em execução: ${det.version}. `
      + 'Sem a versão dos offsets não dá para garantir compatibilidade, então nada foi escrito.');
  }
  if (norm(sourceBuild) !== det.version) {
    return block(`Versão incompatível. offsets → ${norm(sourceBuild)} · processo em execução → ${det.version}. `
      + 'Escrever na memória agora apontaria para endereços errados e crasharia o Roblox. '
      + 'Atualize os offsets (ou o Roblox) para a mesma versão e tente de novo.', true);
  }
  if (expectedVersion && norm(expectedVersion) !== det.version) {
    return block('Versão incompatível. A configuração selecionada pertence a outra versão do Roblox: '
      + `configuração → ${norm(expectedVersion)} · processo em execução → ${det.version}.`, true);
  }
  return { gated: false, detection: det };
}

// Resposta padrão de bloqueio (mesmos campos que o site/console já usam).
function gatedResponse(g, extra = {}) {
  return {
    ok: false, blocked: true, buildMismatch: g.mismatch, running: g.running, offsets: g.offsets,
    detection: publicDetection(g.detection), message: g.reason, ...extra,
  };
}

// ──────────────────────── Memory Injector ────────────────────────

const TH32CS_SNAPPROCESS = 0x02;
const TH32CS_SNAPMODULE = 0x08;
const TH32CS_SNAPMODULE32 = 0x10;
const PROCESS_VM_READ = 0x0010;
const PROCESS_VM_WRITE = 0x0020;
const PROCESS_VM_OPERATION = 0x0008;
const PROCESS_QUERY_INFORMATION = 0x0400;
const PROCESS_QUERY_LIMITED_INFORMATION = 0x1000;
const PROCESS_ACCESS = PROCESS_VM_READ | PROCESS_VM_WRITE | PROCESS_VM_OPERATION | PROCESS_QUERY_INFORMATION;

// ──────────────── Identificação da versão do Roblox em execução ────────────────
//
// Mesmo princípio do RbxDumperV2 (main.cpp → init()):
//   processo RobloxPlayerBeta.exe → PID → módulos do processo →
//   módulo RobloxPlayerBeta.exe → caminho REAL do módulo → "version-…".
// A versão vem só do processo em execução. Nunca de pastas de versões no disco,
// da seleção do site ou da "última instalada": com Fishstrap/Bloxstrap pode haver
// várias versões instaladas ao mesmo tempo. Nada disto é guardado (sem cache).

const ROBLOX_EXE = 'robloxplayerbeta.exe';
const RX_VERSION_DIR = /^version-[0-9a-f]+$/i;
const INVALID_HANDLE = 0xFFFFFFFFFFFFFFFFn;

function isValidHandle(h) {
  if (!h) return false;
  try {
    const a = BigInt.asUintN(64, BigInt(koffi.address(h)));
    return a !== 0n && a !== INVALID_HANDLE && a !== 0xFFFFFFFFn;
  } catch { return true; }
}

// "…\<qualquer coisa>\version-XXXX\RobloxPlayerBeta.exe" → "version-xxxx".
// Usa a pasta que CONTÉM o .exe (layout do Roblox, Bloxstrap e Fishstrap), para
// não confundir com "version-" em outro trecho do caminho (ex.: nome de usuário).
function versionFromImagePath(p) {
  if (!p) return null;
  const parts = String(p).split(/[\\/]+/).filter(Boolean);
  if (parts.length < 2 || parts[parts.length - 1].toLowerCase() !== ROBLOX_EXE) return null;
  const dir = parts[parts.length - 2];
  return RX_VERSION_DIR.test(dir) ? dir.toLowerCase() : null;
}

// Todos os PIDs de RobloxPlayerBeta.exe (ordem crescente). null = falha ao listar.
function listRobloxPids() {
  let snap = null;
  try {
    snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (!isValidHandle(snap)) return null;
    const pids = [];
    const pe = { dwSize: PE_SIZE };
    let ok = Process32FirstW(snap, pe);
    while (ok) {
      if (decodeWChar(pe.szExeFile).toLowerCase() === ROBLOX_EXE) pids.push(pe.th32ProcessID);
      pe.dwSize = PE_SIZE;
      ok = Process32NextW(snap, pe);
    }
    return pids.sort((a, b) => a - b);
  } catch { return null; } finally {
    if (snap) { try { CloseHandle(snap); } catch {} }
  }
}

// Caminho do módulo RobloxPlayerBeta.exe DENTRO do processo (igual ao
// getModulePathByName do main.cpp). Tenta 2x: o snapshot de módulos pode falhar
// de forma transitória (ERROR_BAD_LENGTH) enquanto o processo carrega DLLs.
function modulePathOf(pid) {
  for (let attempt = 0; attempt < 2; attempt++) {
    let snap = null;
    try {
      snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, pid);
      if (!isValidHandle(snap)) continue;
      const me = { dwSize: ME_SIZE };
      let ok = Module32FirstW(snap, me);
      while (ok) {
        if (decodeWChar(me.szModule).toLowerCase() === ROBLOX_EXE) return decodeWChar(me.szExePath) || null;
        me.dwSize = ME_SIZE;
        ok = Module32NextW(snap, me);
      }
      return null;
    } catch {} finally {
      if (snap) { try { CloseHandle(snap); } catch {} }
    }
  }
  return null;
}

// Caminho real da imagem do processo (QueryFullProcessImageNameW). Só precisa de
// PROCESS_QUERY_LIMITED_INFORMATION, então funciona mesmo sem admin na maioria dos casos.
function imagePathOf(pid) {
  let h = null;
  try {
    h = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, 0, pid);
    if (!isValidHandle(h)) return null;
    const buf = Buffer.alloc(32768 * 2);
    const size = [32768];
    if (QueryFullProcessImageNameW(h, 0, buf, size) && size[0] > 0) return buf.toString('utf16le', 0, size[0] * 2);
  } catch {} finally {
    if (h) { try { CloseHandle(h); } catch {} }
  }
  return null;
}

// Identidade + versão de UM processo. Se as duas fontes existirem e discordarem → desconhecida.
function identifyProcess(pid) {
  const modPath = modulePathOf(pid);
  const imgPath = imagePathOf(pid);
  const path = modPath || imgPath;
  if (!path) return { pid, path: null, version: null, error: 'sem acesso ao caminho do processo (rode o Helper como administrador)' };
  const vMod = versionFromImagePath(modPath);
  const vImg = versionFromImagePath(imgPath);
  if (modPath && imgPath && vMod !== vImg) return { pid, path, version: null, error: 'caminhos do processo divergentes' };
  const version = vMod || vImg;
  if (!version) return { pid, path, version: null, error: 'o executável não está dentro de uma pasta de versão (version-XXXX)' };
  return { pid, path, version, error: null };
}

// PID dono da janela "Roblox" (mesma busca do main.cpp: FindWindowA(nullptr, "Roblox")).
function robloxWindowPid() {
  try {
    const hwnd = FindWindowW(null, 'Roblox');
    if (!hwnd) return null;
    const out = [0];
    GetWindowThreadProcessId(hwnd, out);
    return out[0] || null;
  } catch { return null; }
}

/**
 * Identifica o Roblox em execução. Sempre consulta o Windows na hora (sem cache).
 *   state 'running'     → version + pid do processo que o Helper vai usar
 *   state 'not-running' → nenhum RobloxPlayerBeta.exe
 *   state 'unknown'     → não dá para afirmar com segurança (nunca chuta)
 * Várias instâncias: todas precisam ser identificadas e estar na MESMA versão;
 * senão → 'unknown'. O processo usado é o dono da janela "Roblox" (como o
 * RbxDumper) ou, se nenhuma instância tiver essa janela, o de menor PID.
 */
function detectRunningRoblox() {
  const base = { state: 'unknown', version: null, pid: null, path: null, instances: [] };
  if (!HAS_FFI) {
    return { ...base, reason: LOAD_ERROR ? `Não foi possível identificar a versão do Roblox (FFI indisponível: ${LOAD_ERROR}).` : 'Não foi possível identificar a versão do Roblox: a identificação só funciona no Windows.' };
  }
  const pids = listRobloxPids();
  if (pids === null) return { ...base, reason: 'Não foi possível identificar a versão do Roblox: falha ao listar os processos do Windows.' };
  if (!pids.length) return { ...base, state: 'not-running', reason: 'Roblox não está em execução. Abra o Roblox e entre em um jogo.' };

  const instances = pids.map(identifyProcess);
  const bad = instances.filter(i => !i.version);
  if (bad.length) {
    return { ...base, instances, reason: 'Não foi possível identificar a versão do Roblox: '
      + bad.map(i => `PID ${i.pid} — ${i.error}`).join('; ') + '.' };
  }
  const versions = [...new Set(instances.map(i => i.version))];
  if (versions.length > 1) {
    return { ...base, instances, reason: 'Não foi possível identificar a versão do Roblox: há instâncias em versões diferentes ('
      + instances.map(i => `PID ${i.pid} → ${i.version}`).join(', ') + '). Feche as instâncias extras.' };
  }
  const winPid = robloxWindowPid();
  const target = instances.find(i => i.pid === winPid) || instances[0];
  return { state: 'running', version: versions[0], pid: target.pid, path: target.path, instances, reason: `Versão em execução: ${versions[0]}` };
}

// O que vai para o site (sem caminhos completos da máquina do usuário).
function publicDetection(det) {
  if (!det) return null;
  return {
    state: det.state, version: det.version, pid: det.pid, reason: det.reason,
    instances: det.instances.map(i => ({ pid: i.pid, version: i.version })),
  };
}

class MemoryInjector {
  constructor() { this.pid = null; this.hProcess = null; this.baseAddress = 0; }

  reset() {
    if (this.hProcess) { try { CloseHandle(this.hProcess); } catch {} }
    this.hProcess = null; this.pid = null; this.baseAddress = 0;
  }

  // Enumera processos e retorna o PID do RobloxPlayerBeta.exe
  findRobloxPid() {
    if (!HAS_FFI) return null;
    let snap = null;
    try {
      snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
      if (!snap) return null;
      const pe = { dwSize: PE_SIZE };
      let ok = Process32FirstW(snap, pe);
      while (ok) {
        const name = decodeWChar(pe.szExeFile).toLowerCase();
        if (name === 'robloxplayerbeta.exe') return pe.th32ProcessID;
        // reset dwSize para a próxima iteração (koffi reescreve o objeto)
        pe.dwSize = PE_SIZE;
        ok = Process32NextW(snap, pe);
      }
    } catch (e) {
      // fallback: janela
      try {
        const hwnd = FindWindowW(null, 'Roblox');
        if (hwnd) {
          const pidArr = [0];
          GetWindowThreadProcessId(hwnd, pidArr);
          if (pidArr[0] > 0) return pidArr[0];
        }
      } catch {}
    } finally {
      if (snap) { try { CloseHandle(snap); } catch {} }
    }
    return null;
  }

  // pid vem de detectRunningRoblox() (processo identificado + versão confirmada).
  attach(pid) {
    if (!pid) { this.reset(); return false; }
    if (this.pid !== pid) this.reset();
    this.pid = pid;
    return true;
  }

  openProcess() {
    if (!this.pid) return false;
    if (this.hProcess) return true;
    try {
      this.hProcess = OpenProcess(PROCESS_ACCESS, 0, this.pid);
      if (!this.hProcess) this.hProcess = OpenProcess(PROCESS_ACCESS | PROCESS_QUERY_LIMITED_INFORMATION, 0, this.pid);
    } catch { return false; }
    return !!this.hProcess;
  }

  getBaseAddress() {
    if (this.baseAddress) return this.baseAddress;
    if (!this.hProcess && !this.openProcess()) return 0;

    // 1) PEB traversal
    try {
      const pbi = Buffer.alloc(48);
      const retLen = [0];
      const status = NtQueryInformationProcess(this.hProcess, 0, pbi, 48, retLen);
      if (status === 0) {
        const peb = pbi.readBigUInt64LE(8); // PebBaseAddress
        if (peb) {
          const imgBuf = Buffer.alloc(8);
          const br = [0];
          const rd = NtReadVirtualMemory(this.hProcess, Number(peb) + 0x10, imgBuf, 8, br);
          if (rd === 0 && Number(br[0]) === 8) {
            const base = Number(imgBuf.readBigUInt64LE(0));
            if (base) { this.baseAddress = base; return base; }
          }
        }
      }
    } catch {}

    // 2) Toolhelp32 módulos
    let snap = null;
    try {
      snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, this.pid);
      if (snap) {
        const me = { dwSize: ME_SIZE };
        let ok = Module32FirstW(snap, me);
        while (ok) {
          const name = decodeWChar(me.szModule).toLowerCase();
          if (name === 'robloxplayerbeta.exe') { this.baseAddress = Number(me.modBaseAddr); CloseHandle(snap); return this.baseAddress; }
          me.dwSize = ME_SIZE;
          ok = Module32NextW(snap, me);
        }
      }
    } catch {} finally {
      if (snap) { try { CloseHandle(snap); } catch {} }
    }
    return 0;
  }

  /** Bytes que representam o valor no formato da flag (bool 1 B, int/float 4 B). */
  static encode(flagType, value) {
    if (flagType === 'bool') return Buffer.from([['true', '1', 'yes'].includes(String(value).toLowerCase()) ? 1 : 0]);
    if (flagType === 'int') {
      const n = Number(value);
      if (!Number.isFinite(n)) return null;
      const b = Buffer.alloc(4); b.writeInt32LE(Math.max(-2147483648, Math.min(2147483647, Math.trunc(n)))); return b;
    }
    if (flagType === 'float') {
      const n = Number(value);
      if (!Number.isFinite(n)) return null;
      const b = Buffer.alloc(4); b.writeFloatLE(n); return b;
    }
    return null;
  }

  static sizeOf(flagType) {
    return flagType === 'bool' ? 1 : (flagType === 'int' || flagType === 'float') ? 4 : 0;
  }

  writeFlag(flagType, absAddr, value) {
    if (!this.hProcess) return { ok: false, msg: 'Sem handle do processo' };
    if (flagType === 'string') return this._writeStdString(absAddr, String(value));
    const data = MemoryInjector.encode(flagType, value);
    if (!data) return { ok: false, msg: flagType === 'int' || flagType === 'float' ? `Valor inválido para ${flagType}: "${value}"` : `Tipo não suportado: ${flagType}` };
    return this._writeRaw(absAddr, data);
  }

  /** Restaura exatamente os bytes lidos antes da 1ª escrita (sem arredondar float). */
  writeBytes(absAddr, data) {
    if (!this.hProcess) return { ok: false, msg: 'Sem handle do processo' };
    return this._writeRaw(absAddr, data);
  }

  readRaw(absAddr, size) {
    if (!this.hProcess || !size) return null;
    try {
      const buf = Buffer.alloc(size);
      const br = [0];
      const status = NtReadVirtualMemory(this.hProcess, absAddr, buf, size, br);
      if (status === 0 && Number(br[0]) === size) return buf;
    } catch {}
    return null;
  }

  /**
   * Só escreve onde o Roblox já permite escrita: memória MEM_COMMIT com
   * PAGE_READWRITE/PAGE_WRITECOPY, sem PAGE_GUARD, sem cruzar o fim da região.
   * A proteção da página NUNCA é alterada: se o endereço não é gravável, ele não
   * é de uma FFlag (offset errado) e escrever ali derrubaria o Roblox.
   */
  _checkRegion(absAddr, len) {
    if (!VirtualQueryEx) return { ok: true };
    try {
      const mbi = Buffer.alloc(48); // MEMORY_BASIC_INFORMATION (x64)
      if (Number(VirtualQueryEx(this.hProcess, absAddr, mbi, 48)) < 48) return { ok: false, msg: `endereço 0x${absAddr.toString(16)} fora da memória do processo` };
      const regionBase = Number(mbi.readBigUInt64LE(0));
      const regionSize = Number(mbi.readBigUInt64LE(24));
      const state = mbi.readUInt32LE(32);
      const protect = mbi.readUInt32LE(36);
      if (state !== 0x1000 /* MEM_COMMIT */) return { ok: false, msg: `memória não alocada em 0x${absAddr.toString(16)}` };
      if (protect & 0x100 /* PAGE_GUARD */) return { ok: false, msg: `página protegida (guard) em 0x${absAddr.toString(16)}` };
      const p = protect & 0xff;
      if (p !== 0x04 /* PAGE_READWRITE */ && p !== 0x08 /* PAGE_WRITECOPY */) return { ok: false, msg: `página não gravável em 0x${absAddr.toString(16)} (proteção 0x${p.toString(16)}) — offset não é de uma flag` };
      if (absAddr + len > regionBase + regionSize) return { ok: false, msg: `escrita passaria do fim da região em 0x${absAddr.toString(16)}` };
      return { ok: true };
    } catch { return { ok: false, msg: 'falha ao consultar a memória do processo' }; }
  }

  _writeStdString(absAddr, value) {
    const raw = Buffer.from(value, 'utf8');
    if (raw.length > 15) return { ok: false, msg: `String muito longa (${raw.length}B > 15B SSO)` };
    // std::string do MSVC: [0..15] buffer interno ou ponteiro, [16] tamanho, [24] capacidade.
    // Se o texto atual está no heap (capacidade > 15), trocar o objeto enquanto o jogo
    // lê pode fazê-lo usar um ponteiro inválido → crash. Nesse caso não escreve.
    const cur = this.readRaw(absAddr, 32);
    if (!cur) return { ok: false, msg: `Não foi possível ler o texto atual em 0x${absAddr.toString(16)}` };
    const cap = cur.readBigUInt64LE(24);
    if (cap !== 15n) return { ok: false, msg: 'O texto atual desta flag é longo (fora do buffer interno); trocar com o Roblox aberto pode crashar. Ignorada.' };
    // Mantém a capacidade (15) e escreve só buffer + tamanho.
    const obj = Buffer.alloc(24, 0);
    raw.copy(obj, 0);
    obj.writeBigUInt64LE(BigInt(raw.length), 16);
    return this._writeRaw(absAddr, obj);
  }

  _writeRaw(absAddr, data) {
    const region = this._checkRegion(absAddr, data.length);
    if (!region.ok) return { ok: false, msg: region.msg };
    // Valor já igual: não escreve nada (menos escritas = menos risco).
    const cur = this.readRaw(absAddr, data.length);
    if (!cur) return { ok: false, msg: `Não foi possível ler 0x${absAddr.toString(16)} antes de escrever` };
    if (cur.equals(data)) return { ok: true, unchanged: true, msg: `OK|igual 0x${absAddr.toString(16)}` };
    let wrote = false;
    try {
      const bw = [0];
      const status = NtWriteVirtualMemory(this.hProcess, absAddr, data, data.length, bw);
      wrote = status === 0 && Number(bw[0]) === data.length;
    } catch {}
    if (!wrote) {
      try {
        const bw = [0];
        wrote = !!WriteProcessMemory(this.hProcess, absAddr, data, data.length, bw) && Number(bw[0]) === data.length;
      } catch {}
    }
    if (!wrote) return { ok: false, msg: `Falha ao escrever em 0x${absAddr.toString(16)}` };
    const check = this.readRaw(absAddr, data.length);
    if (!check || !check.equals(data)) return { ok: false, msg: `Escrita em 0x${absAddr.toString(16)} não confirmada na leitura` };
    return { ok: true, msg: `OK 0x${absAddr.toString(16)}` };
  }

  readFlag(flagType, absAddr) {
    const buf = this.readRaw(absAddr, MemoryInjector.sizeOf(flagType));
    if (!buf) return null;
    if (flagType === 'bool') return buf.readUInt8(0) !== 0 ? 'true' : 'false';
    if (flagType === 'int') return String(buf.readInt32LE(0));
    return String(Math.round(buf.readFloatLE(0) * 10000) / 10000);
  }
}

const injector = HAS_FFI ? new MemoryInjector() : null;

function ensureAttached(pid) {
  if (!injector) return false;
  if (!injector.attach(pid)) return false;
  if (!injector.openProcess()) return false;
  if (!injector.getBaseAddress()) return false;
  return true;
}

// Identifica o Roblox em execução AGORA e conecta o injetor a ESSE processo.
function attachRunning() {
  const det = detectRunningRoblox();
  if (det.state !== 'running') return { ok: false, detection: det, message: det.reason };
  if (!ensureAttached(det.pid)) {
    return { ok: false, detection: det, message: `${det.reason}, mas sem acesso ao processo (PID ${det.pid}). Rode o Helper como administrador.` };
  }
  return { ok: true, detection: det };
}

// ──────────────────────── Estado / Ações ────────────────────────

// Estado das flags escritas NESTE processo do Roblox. Roblox reaberto = outro
// processo com os valores padrão do jogo → o estado recomeça do zero.
let injectedState = {};
let injectedPid = null;
function syncStatePid() {
  if (injector.pid !== injectedPid) { injectedState = {}; injectedPid = injector.pid; }
}
function stateFor(name) {
  syncStatePid();
  return injectedState[name] || (injectedState[name] = {});
}

// Guarda os bytes ORIGINAIS da flag antes da 1ª escrita neste processo. Nunca
// depois: assim o "original" jamais é um valor que o próprio Helper escreveu.
function captureOriginal(state, ft, absAddr) {
  if (state.originalCaptured || state.touched) return;
  state.touched = true; // a partir daqui a memória pode conter valor nosso
  const size = MemoryInjector.sizeOf(ft);
  const raw = size ? injector.readRaw(absAddr, size) : null;
  if (raw) {
    state.originalRaw = raw;
    state.original = injector.readFlag(ft, absAddr);
    state.originalCaptured = true;
  }
}

// Volta a flag ao valor original exato. Sem original conhecido NÃO escreve nada
// (escrever um "padrão" chutado, ex. 0 num inteiro do jogo, pode crashar o Roblox).
function revertFlag(name, state, ft, absAddr) {
  if (!state.written) { state.enabled = false; return { ok: true, unchanged: true }; }
  if (!state.originalCaptured || !state.originalRaw || state.originalRaw.length !== MemoryInjector.sizeOf(ft)) {
    return { ok: false, unknown: true, msg: 'valor original desconhecido (reinicie o Roblox para voltar ao padrão)' };
  }
  const r = injector.writeBytes(absAddr, state.originalRaw);
  if (r.ok) { state.enabled = false; state.written = false; }
  return r;
}

function getStatus() {
  // Identificação feita na hora, a partir do processo (nada reaproveitado de antes).
  const det = detectRunningRoblox();
  const robloxRunning = det.instances.length > 0;
  const pid = det.pid;
  const runningBuild = det.state === 'running' ? det.version : null;
  const offsetsBuild = siteOffsets ? siteOffsets.version : null;
  const buildMatch = runningBuild && offsetsBuild ? runningBuild === offsetsBuild : null;
  return {
    ok: true, helper: 'gerenciador-helper', helperVersion: HELPER_VERSION,
    platform: process.platform, method: 'memory-injection', macros: true,
    ffiReady: HAS_FFI, loadError: LOAD_ERROR,
    robloxFound: robloxRunning, robloxPid: pid,
    startedAt: STARTED_AT,
    runningBuild, offsetsBuild, buildMatch,
    siteOffsetsBuild: offsetsBuild,
    detection: publicDetection(det),
    canApply: HAS_FFI && robloxRunning,
  };
}

async function applyFlags(flags, expectedVersion) {
  if (!HAS_FFI) return { ok: false, applied: 0, skipped: Object.keys(flags), message: LOAD_ERROR ? `FFI indisponível: ${LOAD_ERROR}` : 'Injeção só funciona no Windows.' };
  const att = attachRunning();
  if (!att.ok) return { ok: false, blocked: true, applied: 0, skipped: Object.keys(flags), detection: publicDetection(att.detection), message: att.message };

  const base = injector.getBaseAddress();
  const { flagOffsets, sourceBuild } = loadOffsets(base);
  if (!Object.keys(flagOffsets).length) return { ok: false, blocked: true, applied: 0, skipped: Object.keys(flags), message: NO_OFFSETS_MSG };
  { const g = liveWritesGated(sourceBuild, expectedVersion); if (g.gated) return gatedResponse(g, { applied: 0, skipped: Object.keys(flags) }); }

  let applied = 0; const skipped = []; const failures = [];
  for (const [name, value] of Object.entries(flags)) {
    const clean = cleanFlagName(name);
    const od = flagOffsets[clean] || flagOffsets[name];
    if (!od) { skipped.push(name); failures.push({ flag: name, reason: 'Não encontrada nos offsets' }); continue; }
    let ft = inferTypeFromName(od.fullName) || inferTypeFromName(name);
    if (!ft || ft === 'unknown') ft = inferType(String(value));

    const state = stateFor(name);
    if (ft !== 'string') captureOriginal(state, ft, od.absAddr);

    const { ok, msg, unchanged } = injector.writeFlag(ft, od.absAddr, String(value));
    if (ok) {
      applied++;
      state.value = String(value);
      state.enabled = true;
      if (!unchanged) state.written = true;
    } else { skipped.push(name); failures.push({ flag: name, reason: msg }); }
  }
  const total = Object.keys(flags).length;
  const message = applied === total ? `Todas as ${applied} configurações aplicadas na memória.`
    : applied > 0 ? `${applied}/${total} configurações aplicadas. ${skipped.length} ignoradas.`
    : 'Nenhuma configuração foi aplicada.';
  return { ok: applied > 0, applied, skipped, failures, message, sourceBuild };
}

async function toggleFlag(name, flags, expectedVersion) {
  if (!HAS_FFI) return { ok: false, message: 'FFI indisponível.' };
  const att = attachRunning();
  if (!att.ok) return { ok: false, blocked: true, detection: publicDetection(att.detection), message: att.message };
  const base = injector.getBaseAddress();
  const { flagOffsets, sourceBuild } = loadOffsets(base);
  if (!sourceBuild) return { ok: false, blocked: true, message: NO_OFFSETS_MSG };
  { const g = liveWritesGated(sourceBuild, expectedVersion); if (g.gated) return gatedResponse(g); }
  const clean = cleanFlagName(name);
  const od = flagOffsets[clean] || flagOffsets[name];
  if (!od) return { ok: false, message: `Configuração '${name}' não encontrada.` };
  const ft = inferTypeFromName(od.fullName) || inferTypeFromName(name) || inferType(String(flags[name] ?? ''));
  const state = stateFor(name);
  // Padrão DESLIGADO: o 1º toque LIGA (aplica seu valor), o 2º DESLIGA (reverte).
  const isOn = state.enabled === true;

  // Captura o valor original do engine antes da 1ª escrita (para poder reverter depois).
  if (ft !== 'string' && ft !== 'unknown') captureOriginal(state, ft, od.absAddr);

  if (!isOn) {
    // LIGAR → aplicar o valor do usuário
    const userValue = flags[name] ?? state.value ?? '';
    if (userValue === '' && userValue !== 0 && userValue !== '0') {
      return { ok: false, message: `Configuração '${name}' não tem valor definido no preset.` };
    }
    const { ok, msg, unchanged } = injector.writeFlag(ft, od.absAddr, String(userValue));
    if (ok) { state.enabled = true; state.value = String(userValue); if (!unchanged) state.written = true; }
    return { ok, enabled: true, flag: name, value: String(userValue), message: ok ? `✅ '${name}' LIGADA → ${userValue}` : `Falha ao ligar '${name}': ${msg}` };
  } else {
    // DESLIGAR → voltar aos bytes originais (sem original conhecido, não escreve)
    if (ft === 'string' || ft === 'unknown') {
      state.enabled = false;
      return { ok: true, enabled: false, flag: name, message: `'${name}' é texto — reinicie o Roblox p/ restaurar o padrão.` };
    }
    const r = revertFlag(name, state, ft, od.absAddr);
    if (r.unknown) state.enabled = false; // nada escrito; o próximo toque liga de novo
    const shown = state.original ?? '—';
    return { ok: r.ok, enabled: false, flag: name, value: shown, message: r.ok ? `⭘ '${name}' DESLIGADA → ${shown}` : `'${name}' não foi revertida: ${r.msg}` };
  }
}

async function cycleFlag(name, cycleValues, flags, expectedVersion) {
  if (!HAS_FFI) return { ok: false, message: 'FFI indisponível.' };
  const att = attachRunning();
  if (!att.ok) return { ok: false, blocked: true, detection: publicDetection(att.detection), message: att.message };
  if (!cycleValues || cycleValues.length < 2) return { ok: false, message: 'Precisa de pelo menos 2 valores.' };
  const base = injector.getBaseAddress();
  const { flagOffsets, sourceBuild } = loadOffsets(base);
  if (!sourceBuild) return { ok: false, blocked: true, message: NO_OFFSETS_MSG };
  { const g = liveWritesGated(sourceBuild, expectedVersion); if (g.gated) return gatedResponse(g); }
  const clean = cleanFlagName(name);
  const od = flagOffsets[clean] || flagOffsets[name];
  if (!od) return { ok: false, message: `Configuração '${name}' não encontrada.` };
  const ft = inferTypeFromName(od.fullName) || inferTypeFromName(name) || inferType(String(cycleValues[0]));
  const state = stateFor(name);
  const current = state.value ?? flags[name] ?? String(cycleValues[0]);
  const strVals = cycleValues.map(String);
  const idx = strVals.indexOf(String(current));
  const nextIdx = (idx + 1) % strVals.length;
  const newVal = strVals[nextIdx];
  if (ft !== 'string') captureOriginal(state, ft, od.absAddr);
  const { ok, msg, unchanged } = injector.writeFlag(ft, od.absAddr, newVal);
  if (ok) { state.value = newVal; state.enabled = true; if (!unchanged) state.written = true; }
  return { ok, flag: name, value: newVal, cycleIndex: nextIdx, message: ok ? `Configuração '${name}' ciclada para: ${newVal}` : `Falha ao ciclar '${name}': ${msg}` };
}

/**
 * Pausa: devolve ao valor ORIGINAL exato (bytes lidos antes da 1ª escrita neste
 * processo) só as flags que o Helper realmente alterou. Nada de "padrão" chutado
 * (false/0): escrever um valor que o jogo nunca teve é o que crashava o Roblox.
 * Flags do preset que não foram escritas neste processo não são tocadas.
 */
async function pauseAllFlags(presetFlags, expectedVersion) {
  if (!HAS_FFI) return { ok: false, message: 'FFI indisponível.' };
  const att = attachRunning();
  if (!att.ok) return { ok: false, blocked: true, detection: publicDetection(att.detection), message: att.message };
  const base = injector.getBaseAddress();
  const { flagOffsets, sourceBuild } = loadOffsets(base);
  if (!sourceBuild) return { ok: false, blocked: true, reverted: 0, failed: 0, message: NO_OFFSETS_MSG };
  { const g = liveWritesGated(sourceBuild, expectedVersion); if (g.gated) return gatedResponse(g, { reverted: 0, failed: 0, message: 'Pause cancelado para não crashar o Roblox: ' + g.reason }); }

  syncStatePid(); // Roblox reaberto: nada deste processo foi alterado pelo Helper
  let reverted = 0, failed = 0, unknown = 0, skippedStr = 0;
  const failures = [];

  for (const [name, state] of Object.entries(injectedState)) {
    if (!state.written) { state.enabled = false; continue; }
    const od = flagOffsets[cleanFlagName(name)] || flagOffsets[name];
    if (!od) { failed++; failures.push({ flag: name, reason: 'sem offset' }); continue; }
    const ft = inferTypeFromName(od.fullName) || inferTypeFromName(name) || inferType(String(state.value ?? ''));
    if (ft === 'string' || ft === 'unknown') { skippedStr++; state.enabled = false; continue; } // texto não é revertível com segurança

    const r = revertFlag(name, state, ft, od.absAddr);
    if (r.ok) reverted++;
    else if (r.unknown) { unknown++; failures.push({ flag: name, reason: r.msg }); }
    else { failed++; failures.push({ flag: name, reason: r.msg }); }
  }
  const total = reverted + failed + unknown + skippedStr;

  return {
    ok: failed === 0,
    reverted, failed, unknown, skippedStrings: skippedStr, failures, total,
    message: (total === 0 ? 'Nada para pausar: nenhuma configuração foi alterada neste Roblox.'
      : `Configurações pausadas: ${reverted} voltaram ao valor original`)
      + (failed ? `, ${failed} falharam` : '')
      + (unknown ? `, ${unknown} sem valor original conhecido (não foram tocadas — reinicie o Roblox para voltar ao padrão)` : '')
      + (skippedStr ? `, ${skippedStr} de texto ignoradas (reinicie o Roblox para restaurar)` : '')
      + '.',
  };
}

async function resumeAllFlags(flags, expectedVersion) {
  const result = await applyFlags(flags, expectedVersion);
  for (const name of Object.keys(flags)) if (injectedState[name] && injectedState[name].written) injectedState[name].enabled = true;
  return result;
}

// ──────────────────────── Hotkey Listener ────────────────────────

let hotkeyConfig = {};
let hotkeyFlags = {};
let hotkeyRunning = false;

// Mapa code -> VK respeitando o layout atual do Windows (ABNT2, US…).
// Aceita qualquer tecla que o site capture (KeyboardEvent.code) + botões do mouse.
const codeToVk = keymap.makeCodeToVk(MapVirtualKeyW ? (a, b) => MapVirtualKeyW(a, b) : null);

// Debounce por (flag, ação): evita disparo duplo e spam de scroll.
const DEBOUNCE_MS = 180;
const lastFire = {};

function fireAction(fname, action) {
  const key = fname + '|' + action;
  const now = Date.now();
  if (now - (lastFire[key] || 0) < DEBOUNCE_MS) return; // debounce
  lastFire[key] = now;
  // Saída em tempo real no CMD, SÓ no momento da hotkey. Não é gravada em lugar
  // nenhum (sem .log/.txt/histórico); é apenas console enquanto o Helper roda.
  if (action === 'toggle') {
    toggleFlag(fname, hotkeyFlags)
      .then(r => {
        if (r.buildMismatch) console.log(`  [CONFIG] ${fname} = IGNORADO (versão incompatível — nada escrito)`);
        else if (r.blocked) console.log(`  [CONFIG] ${fname} = IGNORADO (${r.message})`);
        else if (r.ok) console.log(`  [CONFIG] ${fname} = ${r.enabled ? 'ON' : 'OFF'}${r.value != null ? ' -> ' + r.value : ''}`);
        else console.log(`  [CONFIG] ${fname} = FALHOU (${r.message})`);
      })
      .catch(e => console.log(`  [CONFIG] ${fname} = ERRO (${e.message})`));
  } else {
    const cv = (hotkeyConfig[fname] && hotkeyConfig[fname].cycleValues) || [];
    if (cv.length >= 2) {
      cycleFlag(fname, cv, hotkeyFlags)
        .then(r => {
          if (r.buildMismatch) console.log(`  [CONFIG] ${fname} = IGNORADO (versão incompatível — nada escrito)`);
          else if (r.blocked) console.log(`  [CONFIG] ${fname} = IGNORADO (${r.message})`);
          else if (r.ok) console.log(`  [CONFIG] ${fname} = CYCLE -> ${r.value}`);
          else console.log(`  [CONFIG] ${fname} = FALHOU (${r.message})`);
        })
        .catch(e => console.log(`  [CONFIG] ${fname} = ERRO (${e.message})`));
    } else {
      console.log(`  [CONFIG] ${fname} = CYCLE precisa de 2+ valores configurados`);
    }
  }
}

// Dispara toggle/cycle para toda flag vinculada a este "code" (tecla ou botão/scroll).
function triggerForCode(code) {
  for (const [fname, hk] of Object.entries(hotkeyConfig)) {
    if (hk.toggleKey === code) fireAction(fname, 'toggle');
    if (hk.cycleKey === code) fireAction(fname, 'cycle');
  }
}

// ---- Sistema de ações (100% em memória: nada é salvo no PC) ----
const cursorBuf = Buffer.alloc(8);
const macroSys = createMacroSystem({
  codeToVk,
  isWin: IS_WIN,
  hasFfi: HAS_FFI,
  log: (...a) => console.log(...a),   // erros/essencial (sempre)
  verbose: DEBUG,                       // atividade por-evento só em debug
  getRobloxPid: () => (HAS_FFI && injector ? injector.findRobloxPid() : null),
  getForegroundPid: () => {
    if (!HAS_FFI) return null;
    try {
      const hwnd = GetForegroundWindow();
      if (!hwnd) return null;
      const pid = [0];
      GetWindowThreadProcessId(hwnd, pid);
      return pid[0] || null;
    } catch { return null; }
  },
  getCursor: HAS_FFI ? () => (GetCursorPosFn(cursorBuf) ? { x: cursorBuf.readInt32LE(0), y: cursorBuf.readInt32LE(4) } : null) : null,
});

// ---- Hook global de entrada (worker separado): scroll + gravação de ações ----
let inputWorker = null;
let inputHookStarted = false; // só tenta uma vez por execução (evita respawn)
const hookShared = new Int32Array(new SharedArrayBuffer(16));
const hookHandle = { shared: hookShared, ready: false };
function startInputHook() {
  if (inputWorker || inputHookStarted || !IS_WIN) return;
  inputHookStarted = true;
  macroSys.attachHook(hookHandle);
  try {
    const { Worker } = require('worker_threads');
    inputWorker = new Worker(path.join(__dirname, '609.js'), { workerData: { shared: hookShared.buffer } });
    inputWorker.on('message', (m) => {
      if (!m) return;
      if (m.type === 'rec') macroSys.onRecEvent(m);
      else if (m.type === 'input' && m.code) { triggerForCode(m.code); macroSys.onDown(m.code); }
      else if (m.type === 'rec-stop') macroSys.stopRecording('tecla de parada');
      else if (m.type === 'ready') { hookHandle.ready = true; console.log('  ✓ Hook global ativo (scroll nas hotkeys + gravação de ações).'); }
      else if (m.type === 'warn') console.log('  [hook]', m.error);
      else if (m.type === 'error') console.log('  [hook] indisponível:', m.error, '(scroll e gravação de ação não vão funcionar; teclas e botões seguem ok)');
    });
    inputWorker.on('error', (e) => { console.log('  [hook] erro no worker:', e.message); inputWorker = null; hookHandle.ready = false; });
    inputWorker.on('exit', () => { inputWorker = null; hookHandle.ready = false; });
  } catch (e) {
    console.log('  [hook] não iniciou:', e.message);
  }
}

/**
 * Loop único de polling (GetAsyncKeyState lê o estado GLOBAL de teclado e mouse,
 * por isso funciona com o Roblox em foco). Observa:
 *   - hotkeys de flags (toggle/cycle)  → borda de subida
 *   - gatilhos de macro + tecla de parada → subida e descida (modo "segurar")
 * Bordas causadas por teclas que o PRÓPRIO macro injetou são ignoradas.
 */
function startHotkeyListener() {
  startInputHook();
  if (hotkeyRunning || !HAS_FFI) return;
  hotkeyRunning = true;
  const prevState = {}; // por code-string: estado da tecla/botão no poll anterior
  const poll = () => {
    if (!hotkeyRunning) return;
    const flagCodes = new Set();
    for (const hk of Object.values(hotkeyConfig)) {
      if (hk.toggleKey) flagCodes.add(hk.toggleKey);
      if (hk.cycleKey) flagCodes.add(hk.cycleKey);
    }
    const macroCodes = macroSys.watchedCodes();
    const all = new Set([...flagCodes, ...macroCodes]);
    for (const code of all) {
      const vk = codeToVk(code);
      if (!vk) continue; // ScrollUp/Down vêm do hook, não do polling
      let pressed = false;
      try { pressed = (GetAsyncKeyState(vk) & 0x8000) !== 0; } catch {}
      const was = !!prevState[code];
      prevState[code] = pressed;
      if (pressed === was) continue;
      if (pressed) {
        if (macroSys.isSelfInjected(code)) continue; // fomos nós (macro) que apertamos
        if (flagCodes.has(code)) triggerForCode(code);
        if (macroCodes.has(code)) macroSys.onDown(code);
      } else if (macroCodes.has(code)) {
        macroSys.onUp(code);
      }
    }
    setTimeout(poll, 15);
  };
  setTimeout(poll, 15);
}

// ──────────────────────── HTTP Server ────────────────────────

function readBody(req) {
  return new Promise((resolve) => {
    const chunks = []; let size = 0;
    req.on('data', (c) => { size += c.length; if (size > 4 * 1024 * 1024) { resolve(null); req.destroy(); return; } chunks.push(c); });
    req.on('end', () => { try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}')); } catch { resolve(null); } });
    req.on('error', () => resolve(null));
  });
}

function sendJson(res, obj, code = 200) {
  const body = JSON.stringify(obj);
  res.writeHead(code, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Length': Buffer.byteLength(body),
  });
  res.end(body);
}

// Helper só com API local (127.0.0.1): não serve o site nem lê/grava arquivos.
// O site é hospedado à parte e conversa com o Helper via CORS.

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
      // Permite que um site HTTPS público acesse este helper em localhost
      // (modelo antigo de Private Network Access do Chrome). Inofensivo nos demais.
      'Access-Control-Allow-Private-Network': 'true',
    });
    res.end(); return;
  }
  const rawPath = (req.url || '').split('?')[0].replace(/\/+$/, '');
  const urlPath = rawPath || '/status';

  if (req.method === 'GET') {
    // API: /status responde JSON. (Se o site estiver embutido, use / para o site.)
    if (urlPath === '/status') return sendJson(res, getStatus());
    if (urlPath === '/debug') {
      const det = detectRunningRoblox();
      const pid = det.pid;
      let base = 0;
      if (det.state === 'running' && injector && ensureAttached(pid)) base = injector.getBaseAddress();
      return sendJson(res, { ffiReady: HAS_FFI, loadError: LOAD_ERROR, peSize: PE_SIZE, meSize: ME_SIZE, robloxPid: pid, baseAddress: base ? '0x' + base.toString(16) : null, detection: publicDetection(det) });
    }
    // ── Macros ──
    if (urlPath === '/macros') return sendJson(res, { ok: true, ...macroSys.getConfig() });
    if (urlPath === '/macro/state') return sendJson(res, macroSys.state());
    if (urlPath === '/macro/record/status') return sendJson(res, { ok: true, ...macroSys.recordingStatus() });
    if (urlPath === '/' || urlPath === '') return sendJson(res, getStatus());
    return sendJson(res, { ok: false, message: 'rota desconhecida' }, 404);
  }

  if (req.method === 'POST') {
    const data = await readBody(req);
    if (data === null) return sendJson(res, { ok: false, message: 'JSON inválido' }, 400);
    switch (urlPath) {
      case '/apply': {
        if (!data.flags || typeof data.flags !== 'object') return sendJson(res, { ok: false, message: "campo 'flags' deve ser um objeto" }, 400);
        return sendJson(res, await applyFlags(data.flags, data.dumpVersion));
      }
      case '/set-offsets':
        return sendJson(res, setSiteOffsets(data.version, data.names, data.addresses));
      case '/restore':
        return sendJson(res, { ok: true, applied: 0, skipped: [], message: 'Reinicie o Roblox para restaurar os valores padrão.' });
      case '/toggle':
        if (!data.name) return sendJson(res, { ok: false, message: "campo 'name' é obrigatório" }, 400);
        return sendJson(res, await toggleFlag(data.name, data.flags || {}, data.dumpVersion));
      case '/cycle':
        if (!data.name) return sendJson(res, { ok: false, message: "campo 'name' é obrigatório" }, 400);
        return sendJson(res, await cycleFlag(data.name, data.cycleValues || [], data.flags || {}, data.dumpVersion));
      case '/pause':
        return sendJson(res, await pauseAllFlags(data.flags || null, data.dumpVersion));
      case '/resume':
        return sendJson(res, await resumeAllFlags(data.flags || {}, data.dumpVersion));
      case '/set-hotkeys':
        hotkeyConfig = data.hotkeys || {}; hotkeyFlags = data.flags || {}; startHotkeyListener();
        return sendJson(res, { ok: true, message: `${Object.keys(hotkeyConfig).length} hotkeys configuradas.` });
      // ── Macros ──
      case '/set-macros': {
        const r = macroSys.setConfig({ macros: data.macros, settings: data.settings });
        startHotkeyListener();
        return sendJson(res, { ok: true, ...r, message: `${r.count} ação(ões) sincronizada(s), ${r.active} com gatilho ativo.` });
      }
      case '/macro/run': {
        if (!data.macro || typeof data.macro !== 'object') return sendJson(res, { ok: false, message: "campo 'macro' é obrigatório" }, 400);
        startHotkeyListener();
        return sendJson(res, macroSys.run(data.macro, { countdown: Math.min(10000, Math.max(0, Number(data.countdown) || 0)) }));
      }
      case '/macro/stop': {
        const n = data.id ? (macroSys.stop(String(data.id)) ? 1 : 0) : macroSys.stopAll();
        return sendJson(res, { ok: true, stopped: n, message: n ? `${n} macro(s) parado(s).` : 'Nenhum macro rodando.' });
      }
      case '/macro/record/start':
        startHotkeyListener();
        return sendJson(res, macroSys.startRecording(data));
      case '/macro/record/stop':
        return sendJson(res, macroSys.stopRecording('parado pelo site'));
      case '/macro/cursor':
        return sendJson(res, await macroSys.pickCursor(data.delay));
      default:
        return sendJson(res, { ok: false, message: 'rota desconhecida' }, 404);
    }
  }
  sendJson(res, { ok: false, message: 'método não permitido' }, 405);
});

// ──────────────────────── Autoteste / Startup ────────────────────────

function selfTest() {
  console.log('── Autoteste de detecção ──');
  console.log(`FFI pronto: ${HAS_FFI}${LOAD_ERROR ? ' (erro: ' + LOAD_ERROR + ')' : ''}`);
  console.log(`sizeof PROCESSENTRY32W = ${PE_SIZE}, MODULEENTRY32W = ${ME_SIZE}`);
  if (!HAS_FFI) { console.log('FFI não disponível — abortando teste.'); return; }
  const det = detectRunningRoblox();
  for (const i of det.instances) console.log(`Instância PID ${i.pid}: ${i.version ?? 'versão desconhecida'}${i.path ? ' — ' + i.path : ''}${i.error ? ' (' + i.error + ')' : ''}`);
  console.log(det.reason);
  const pid = det.pid;
  console.log(`Roblox PID usado pelo Helper: ${pid ?? 'nenhum'}`);
  if (pid) {
    injector.attach(pid);
    const opened = injector.openProcess();
    console.log(`OpenProcess: ${opened ? 'ok' : 'falhou (tente como administrador)'}`);
    if (opened) {
      const base = injector.getBaseAddress();
      console.log(`Base address: ${base ? '0x' + base.toString(16) : 'falhou'}`);
    }
  } else if (det.state === 'not-running') {
    console.log('→ Abra o Roblox e entre em um jogo. Se já estiver aberto, rode como administrador.');
  }
  console.log('───────────────────────────');
}

if (process.argv.includes('--test')) {
  selfTest();
  process.exit(0);
}

const port = parseInt(process.argv[2]) || DEFAULT_PORT;

function tryListen(p, tries = 5) {
  server.listen(p, '127.0.0.1', () => {
    const st = getStatus();
    console.log('┌─ Painel do BOPE — Helper Local [Node.js · sem internet]');
    console.log(`│  versão ${HELPER_VERSION} · http://127.0.0.1:${p}`);
    console.log(`│  FFI pronto: ${HAS_FFI}${LOAD_ERROR ? ' — ' + LOAD_ERROR : ''}`);
    console.log(`│  Roblox: ${st.detection ? st.detection.reason : 'não detectado — abra o Roblox e entre em um jogo'}${st.robloxPid ? ` (PID ${st.robloxPid})` : ''}`);
    console.log('│  Abra o SITE (hospedado) no navegador — ele fala com este Helper em 127.0.0.1.');
    if (!IS_WIN) console.log('│  ⚠ Injeção em memória só funciona no Windows');
    console.log('│  Hotkeys (teclado + botões do mouse) funcionam GLOBALMENTE, mesmo com o Roblox em foco.');
    console.log('│  100% em memória: o Helper NÃO grava nada no seu PC (config fica no site).');
    const mc = macroSys.getConfig();
    console.log(`│  Ações: ${mc.macros.length} em memória · tecla de parada ${mc.settings.stopKey || 'F8'}${IS_WIN ? '' : ' · (fora do Windows: execução simulada)'}`);
    console.log('│  Dica: "node 626.js --test" testa só a detecção.');
    console.log('└─ Ctrl+C para encerrar.');
  });
  server.on('error', (e) => {
    if (e.code === 'EADDRINUSE' && tries > 1) {
      console.log(`[!] porta ${p} ocupada, tentando ${p + 1}…`);
      server.close();
      tryListen(p + 1, tries - 1);
    } else { console.error(`[x] não consegui abrir porta: ${e.message}`); process.exit(1); }
  });
}

tryListen(port);
startHotkeyListener(); // começa a ouvir hotkeys/ações assim que o site enviar a config

// Ctrl+C: para os macros (eles soltam teclas/botões segurados) antes de sair.
process.on('SIGINT', () => {
  try { macroSys.stopAll(); } catch {}
  setTimeout(() => { try { macroSys.shutdown(); } catch {} process.exit(0); }, 200);
});
