'use strict';
/**
 * Painel do BOPE — motor de escrita de FFlags na memória do Roblox.
 *
 * Objetivo: escrever e desfazer flags SEM crashar o Roblox.
 *
 *   1. Sessão por processo: PID + handle + horário de criação do processo.
 *      Roblox fechado/reaberto (mesmo com o PID reaproveitado) = sessão nova,
 *      nada do processo anterior é reaproveitado.
 *   2. Validação ANTES de qualquer escrita (preparar): tipo pelo prefixo do nome,
 *      valor estrito (nada de "abc" virar 0), endereço alinhado, dentro do
 *      executável do Roblox e numa página que JÁ é gravável. A proteção da memória
 *      nunca é alterada; endereço que não passa = offset errado = recusa.
 *   3. Lote atômico: se uma escrita falhar no meio, as escritas já feitas no lote
 *      são desfeitas — nada fica pela metade.
 *   4. Valor original guardado por ENDEREÇO no 1º contato da sessão (nomes
 *      diferentes que apontam para a mesma flag compartilham o original).
 *      Restaurar devolve os bytes exatos, na ordem inversa, e só onde o Helper
 *      mexeu. Nunca escreve um "padrão" inventado.
 *   5. Valor igual não é reescrito; toda escrita é conferida por leitura.
 *
 * Tudo fica em memória; nada é gravado no PC. Este módulo não fala com o Windows
 * diretamente: recebe uma camada `os` (626.js liga às APIs reais; os testes usam
 * um processo simulado).
 */

const PREFIX_TYPE = [
  ['DFFlag', 'bool'], ['SFFlag', 'bool'], ['FFlag', 'bool'], ['GFFlag', 'bool'],
  ['DFInt', 'int'], ['SFInt', 'int'], ['FInt', 'int'],
  ['DFLog', 'int'], ['FLog', 'int'],
  ['DFFloat', 'float'], ['SFFloat', 'float'], ['FFloat', 'float'],
  ['DFString', 'string'], ['SFString', 'string'], ['FString', 'string'],
];
const SORTED_PREFIXES = PREFIX_TYPE.map(p => p[0]).sort((a, b) => b.length - a.length);

function inferTypeFromName(name) {
  for (const pre of SORTED_PREFIXES) if (String(name).startsWith(pre)) return PREFIX_TYPE.find(p => p[0] === pre)[1];
  return null;
}
function cleanFlagName(name) {
  for (const pre of SORTED_PREFIXES) if (String(name).startsWith(pre)) return name.slice(pre.length);
  return name;
}
/** Sem prefixo no nome: deduz pelo valor (como o site faz). */
function inferTypeFromValue(val) {
  const s = String(val).toLowerCase().trim();
  if (s === 'true' || s === 'false') return 'bool';
  if (s !== '' && Number.isFinite(Number(s))) return /^[+-]?\d+$/.test(s) ? 'int' : 'float';
  return 'string';
}

// std::string do MSVC (x64): [0..15] buffer interno ou ponteiro, [16] tamanho, [24] capacidade.
// Só textos no buffer interno (capacidade 15) são trocados/restaurados: são 24 bytes
// sem ponteiros. Texto no heap nunca é tocado (o jogo poderia ler um ponteiro inválido).
const STR_OBJ = 32, STR_DATA = 24, SSO_CAP = 15n;
const SIZE = { bool: 1, int: 4, float: 4, string: STR_DATA };
const SPAN = { bool: 1, int: 4, float: 4, string: STR_OBJ }; // bytes que precisam ser legíveis/graváveis
const ALIGN = { bool: 1, int: 4, float: 4, string: 8 };

const MEM_COMMIT = 0x1000;
const PAGE_GUARD = 0x100;
const PAGE_READWRITE = 0x04, PAGE_WRITECOPY = 0x08;

const hex = (n) => '0x' + n.toString(16);

/** Valor do usuário → bytes. Recusa (não converte) o que não serve para o tipo. */
function encode(type, value) {
  const s = String(value ?? '').trim();
  if (type === 'bool') {
    const v = s.toLowerCase();
    if (['true', '1', 'yes', 'on'].includes(v)) return { ok: true, data: Buffer.from([1]), text: 'true' };
    if (['false', '0', 'no', 'off'].includes(v)) return { ok: true, data: Buffer.from([0]), text: 'false' };
    return { ok: false, reason: `valor "${s}" não é true/false` };
  }
  if (type === 'int') {
    const n = s === '' ? NaN : Number(s);
    if (!Number.isInteger(n)) return { ok: false, reason: `valor "${s}" não é um número inteiro` };
    if (n < -2147483648 || n > 2147483647) return { ok: false, reason: `valor ${s} fora do limite de um inteiro de 32 bits` };
    const b = Buffer.alloc(4); b.writeInt32LE(n); return { ok: true, data: b, text: String(n) };
  }
  if (type === 'float') {
    const n = s === '' ? NaN : Number(s);
    if (!Number.isFinite(n)) return { ok: false, reason: `valor "${s}" não é um número` };
    const b = Buffer.alloc(4); b.writeFloatLE(n);
    if (!Number.isFinite(b.readFloatLE(0))) return { ok: false, reason: `valor ${s} fora do limite de um float` };
    return { ok: true, data: b, text: String(n) };
  }
  if (type === 'string') {
    const raw = Buffer.from(String(value ?? ''), 'utf8');
    if (raw.length > 15) return { ok: false, reason: `texto com ${raw.length} bytes; o máximo seguro é 15` };
    const b = Buffer.alloc(STR_DATA, 0);
    raw.copy(b, 0);
    b.writeBigUInt64LE(BigInt(raw.length), 16);
    return { ok: true, data: b, text: String(value ?? '') };
  }
  return { ok: false, reason: `tipo não suportado (${type})` };
}

/** Bytes → texto para mensagens. */
function decode(type, buf) {
  if (!buf) return null;
  if (type === 'bool') return buf.readUInt8(0) !== 0 ? 'true' : 'false';
  if (type === 'int') return String(buf.readInt32LE(0));
  if (type === 'float') return String(Math.round(buf.readFloatLE(0) * 10000) / 10000);
  if (type === 'string') {
    const len = Number(buf.readBigUInt64LE(16));
    return len <= 15 ? buf.toString('utf8', 0, len) : null;
  }
  return null;
}

/**
 * os: {
 *   openProcess(pid) → handle | null      closeHandle(h)
 *   isAlive(h) → bool                     startTime(h) → string | null
 *   moduleInfo(pid) → { base, size } | null   (RobloxPlayerBeta.exe dentro do processo)
 *   read(h, addr, len) → Buffer | null    write(h, addr, buf) → bool
 *   query(h, addr) → { base, size, state, protect } | null   (VirtualQueryEx)
 * }
 */
function createFlagEngine(os, { log = () => {} } = {}) {
  let s = null; // sessão atual

  function close() {
    if (s && s.handle) { try { os.closeHandle(s.handle); } catch {} }
    s = null;
  }

  /** Conecta ao processo. Mesmo processo (PID + horário de criação) = mesma sessão. */
  function attach(pid) {
    if (s && s.pid === pid && os.isAlive(s.handle) && os.startTime(s.handle) === s.startTime) return { ok: true, fresh: false };
    close();
    const handle = os.openProcess(pid);
    if (!handle) return { ok: false, message: `Sem acesso ao processo do Roblox (PID ${pid}). Rode o Helper como administrador.` };
    if (!os.isAlive(handle)) { os.closeHandle(handle); return { ok: false, message: 'O processo do Roblox está fechando. Tente de novo quando ele abrir.' }; }
    const mod = os.moduleInfo(pid);
    if (!mod || !mod.base || !mod.size) {
      os.closeHandle(handle);
      return { ok: false, message: 'Não foi possível localizar o RobloxPlayerBeta.exe na memória do processo (ele ainda está abrindo?).' };
    }
    s = {
      pid, handle, startTime: os.startTime(handle), base: mod.base, size: mod.size,
      originals: new Map(), // addr → { raw, type, name }
      live: new Map(),      // addr → { name, type, value, seq } (flags alteradas pelo Helper)
      seq: 0,
    };
    log(`  [injeção] sessão nova: PID ${pid}, base ${hex(mod.base)}, ${mod.size} bytes`);
    return { ok: true, fresh: true };
  }

  function region(addr, span) {
    const r = os.query(s.handle, addr);
    if (!r) return `endereço ${hex(addr)} fora da memória do processo`;
    if (r.state !== MEM_COMMIT) return `memória não alocada em ${hex(addr)}`;
    if (r.protect & PAGE_GUARD) return `página protegida em ${hex(addr)}`;
    const p = r.protect & 0xff;
    if (p !== PAGE_READWRITE && p !== PAGE_WRITECOPY) return `página não gravável em ${hex(addr)} (proteção ${hex(p)}) — o offset não é de uma flag`;
    if (addr + span > r.base + r.size) return `a flag passaria do fim da região de memória em ${hex(addr)}`;
    return null;
  }

  function readBytes(addr, len) {
    try { return os.read(s.handle, addr, len); } catch { return null; }
  }

  function writeVerified(addr, data) {
    let ok = false;
    try { ok = os.write(s.handle, addr, data); } catch { ok = false; }
    if (!ok) return false;
    const back = readBytes(addr, data.length);
    return !!back && back.equals(data);
  }

  /** Lê o estado atual de uma flag e confere tudo. Não escreve nada. */
  function inspect(name, entry, valueForType) {
    if (!entry) return { ok: false, reason: 'não existe nos offsets desta versão' };
    const type = entry.type && entry.type !== 'unknown' ? entry.type
      : inferTypeFromName(entry.fullName) || inferTypeFromName(name) || inferTypeFromValue(valueForType);
    if (!SIZE[type]) return { ok: false, reason: `tipo não suportado (${type})` };
    const rva = entry.rva;
    if (!Number.isInteger(rva) || rva <= 0) return { ok: false, reason: 'offset inválido' };
    if (rva % ALIGN[type]) return { ok: false, reason: `offset ${hex(rva)} desalinhado para ${type} — não é o endereço desta flag` };
    if (rva + SPAN[type] > s.size) return { ok: false, reason: `offset ${hex(rva)} fora do executável do Roblox` };
    const addr = s.base + rva;
    const bad = region(addr, SPAN[type]);
    if (bad) return { ok: false, reason: bad };
    const cur = readBytes(addr, SPAN[type]);
    if (!cur) return { ok: false, reason: `não foi possível ler ${hex(addr)}` };
    if (type === 'string' && cur.readBigUInt64LE(24) !== SSO_CAP) {
      return { ok: false, reason: 'o texto atual desta flag é longo (fora do buffer interno); trocá-lo com o Roblox aberto pode crashar' };
    }
    return { ok: true, name, type, addr, current: cur.subarray(0, SIZE[type]) };
  }

  /**
   * Aplica um lote [{ name, entry, value }].
   *   preparar: valida tudo; itens inválidos são pulados com o motivo (nada é escrito neles);
   *   gravar:   escreve os válidos; se uma escrita falhar, desfaz as do lote.
   */
  function apply(changes) {
    if (!s) return { ok: false, applied: [], skipped: changes.map(c => ({ flag: c.name, reason: 'sem sessão com o Roblox' })) };
    const skipped = [];
    const byAddr = new Map(); // nomes que apontam para o mesmo endereço: o último vence
    for (const c of changes) {
      const it = inspect(c.name, c.entry, c.value);
      if (!it.ok) { skipped.push({ flag: c.name, reason: it.reason }); continue; }
      const enc = encode(it.type, c.value);
      if (!enc.ok) { skipped.push({ flag: c.name, reason: enc.reason }); continue; }
      const prev = byAddr.get(it.addr);
      if (prev) skipped.push({ flag: prev.name, reason: `mesma flag que '${c.name}' (vale o último valor)` });
      byAddr.set(it.addr, { ...it, data: enc.data, value: enc.text });
    }

    const touched = []; // { addr, before (se escreveu), wasLive } — para desfazer o lote
    const applied = [];
    for (const it of byAddr.values()) {
      if (!s.originals.has(it.addr)) s.originals.set(it.addr, { raw: Buffer.from(it.current), type: it.type, name: it.name });
      const same = it.current.equals(it.data);
      if (!same && !writeVerified(it.addr, it.data)) {
        // Desfaz o lote, do último para o primeiro (escritas e marcações).
        let undone = 0;
        const written = touched.filter(t => t.before).length;
        for (const t of touched.reverse()) {
          if (t.before && !writeVerified(t.addr, t.before)) continue; // fica marcada como alterada (a pausa tenta de novo)
          if (t.before) undone++;
          if (t.wasLive) s.live.set(t.addr, t.wasLive); else s.live.delete(t.addr);
        }
        log(`  [injeção] falha ao escrever ${it.name} em ${hex(it.addr)}; ${undone}/${written} escritas do lote desfeitas`);
        return {
          ok: false, applied: [], rolledBack: undone,
          skipped: [...skipped, { flag: it.name, reason: `falha ao escrever em ${hex(it.addr)}` },
            ...applied.map(n => ({ flag: n, reason: 'desfeita: outra flag do lote falhou' }))],
          message: `A escrita de '${it.name}' falhou; ${undone} alteração(ões) deste lote foram desfeitas para não deixar nada pela metade.`,
        };
      }
      touched.push({ addr: it.addr, before: same ? null : Buffer.from(it.current), wasLive: s.live.get(it.addr) });
      s.live.set(it.addr, { name: it.name, type: it.type, value: it.value, seq: ++s.seq });
      applied.push(it.name);
      log(`  [injeção] ${it.name} = ${it.value}${same ? ' (já estava)' : ''}`);
    }
    return { ok: applied.length > 0, applied, skipped, written: touched.filter(t => t.before).length };
  }

  /**
   * Restaura os valores originais (todos, ou só os nomes informados), na ordem
   * inversa das alterações. Só onde o Helper mexeu nesta sessão.
   */
  function restore(names) {
    if (!s) return { ok: true, restored: [], failed: [] };
    const want = names ? new Set(names.map(n => cleanFlagName(n))) : null;
    const items = [...s.live.entries()]
      .filter(([, v]) => !want || want.has(cleanFlagName(v.name)))
      .sort((a, b) => b[1].seq - a[1].seq);
    const restored = [], failed = [];
    for (const [addr, v] of items) {
      const orig = s.originals.get(addr);
      if (!orig) { failed.push({ flag: v.name, reason: 'valor original desconhecido' }); continue; }
      const bad = region(addr, SPAN[orig.type]);
      if (bad) { failed.push({ flag: v.name, reason: bad }); continue; }
      const cur = readBytes(addr, SPAN[orig.type]);
      if (!cur) { failed.push({ flag: v.name, reason: `não foi possível ler ${hex(addr)}` }); continue; }
      if (orig.type === 'string' && cur.readBigUInt64LE(24) !== SSO_CAP) {
        // O próprio jogo trocou o texto por um longo: não mexe.
        s.live.delete(addr);
        failed.push({ flag: v.name, reason: 'o jogo trocou este texto; reinicie o Roblox para restaurar' });
        continue;
      }
      const unchanged = cur.subarray(0, orig.raw.length).equals(orig.raw);
      if (!unchanged && !writeVerified(addr, orig.raw)) {
        failed.push({ flag: v.name, reason: `falha ao escrever em ${hex(addr)}` });
        continue;
      }
      s.live.delete(addr);
      // unchanged: a memória já estava no "original" guardado (o Helper foi aberto
      // com a flag já alterada e guardou o valor alterado como original).
      restored.push({ flag: v.name, value: decode(orig.type, orig.raw), unchanged });
      log(`  [injeção] ${v.name} restaurada → ${decode(orig.type, orig.raw)}`);
    }
    return { ok: failed.length === 0, restored, failed };
  }

  /** Identifica o processo: PID + horário de criação (muda se o Roblox reabrir). */
  function sessionId() { return s ? `${s.pid}:${s.startTime}` : null; }

  /**
   * Valores originais desta sessão, para o SITE guardar em memória (aba aberta).
   * Se o Helper for fechado e aberto de novo com o Roblox alterado, o site devolve
   * esses originais e pausar/desligar volta ao valor padrão de verdade.
   */
  function exportOriginals() {
    if (!s) return [];
    return [...s.originals.entries()].map(([addr, o]) => ({ rva: addr - s.base, type: o.type, name: o.name, raw: o.raw.toString('hex') }));
  }

  /**
   * Recebe originais guardados pelo site. Só vale para o MESMO processo (sessionId).
   * São mais antigos que os capturados por este Helper, então têm prioridade.
   * Onde a memória está diferente do original, a flag conta como alterada.
   */
  function seedOriginals(session, items) {
    if (!s || session !== sessionId() || !Array.isArray(items)) return { ok: false, seeded: 0 };
    let seeded = 0;
    for (const it of items.slice(0, 5000)) {
      if (!it || !SIZE[it.type] || typeof it.raw !== 'string' || !/^[0-9a-f]*$/i.test(it.raw)) continue;
      const raw = Buffer.from(it.raw, 'hex');
      const rva = it.rva;
      if (raw.length !== SIZE[it.type] || !Number.isInteger(rva) || rva <= 0 || rva % ALIGN[it.type] || rva + SPAN[it.type] > s.size) continue;
      const addr = s.base + rva;
      if (region(addr, SPAN[it.type])) continue;
      const cur = readBytes(addr, SPAN[it.type]);
      if (!cur) continue;
      if (it.type === 'string' && cur.readBigUInt64LE(24) !== SSO_CAP) continue;
      const name = typeof it.name === 'string' ? it.name.slice(0, 200) : `0x${rva.toString(16)}`;
      s.originals.set(addr, { raw, type: it.type, name });
      if (cur.subarray(0, SIZE[it.type]).equals(raw)) s.live.delete(addr);
      else if (!s.live.has(addr)) s.live.set(addr, { name, type: it.type, value: decode(it.type, cur.subarray(0, SIZE[it.type])), seq: ++s.seq });
      seeded++;
    }
    if (seeded) log(`  [injeção] ${seeded} valor(es) original(is) recuperado(s) do site`);
    return { ok: true, seeded };
  }

  function findLive(name) {
    const key = cleanFlagName(name);
    for (const v of (s ? s.live.values() : [])) if (cleanFlagName(v.name) === key) return v;
    return null;
  }

  return {
    attach, close, apply, restore, sessionId, exportOriginals, seedOriginals,
    pid: () => (s ? s.pid : null),
    base: () => (s ? s.base : 0),
    isLive: (name) => !!findLive(name),
    liveValue: (name) => { const v = findLive(name); return v ? v.value : null; },
    liveCount: () => (s ? s.live.size : 0),
    info: () => (s ? { pid: s.pid, base: hex(s.base), moduleSize: s.size, altered: s.live.size } : null),
  };
}

module.exports = { createFlagEngine, encode, decode, inferTypeFromName, inferTypeFromValue, cleanFlagName, PREFIX_TYPE };
