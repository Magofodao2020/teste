/*
 * Worker: executa macros (mouse + teclado) com SendInput.
 *
 * Cada macro ganha um worker próprio (criado sob demanda e reaproveitado), então
 * vários macros podem rodar ao mesmo tempo e a thread principal (HTTP + hotkeys)
 * nunca trava.
 *
 * Controle via memória compartilhada (workerData.ctl, Int32Array):
 *   [0] = 1 → parar agora (a thread principal faz Atomics.notify para acordar o sleep)
 *
 * Supressão de auto-disparo (workerData.injHeld / injLast, indexados por VK):
 *   antes de injetar uma tecla/botão, marcamos "fui eu" — assim, se o macro
 *   aperta a mesma tecla que o dispara, a thread principal não re-dispara.
 *
 * Mensagens:  in  { type:'run', runId, macro, countdown }
 *             out { type:'done', runId, ok, reason, iterations, error? }
 *
 * Fora do Windows (ou com workerData.mock) usa um backend "fake" que só registra
 * as ações com timestamp — serve para testar a temporização.
 */
const { parentPort, workerData } = require('worker_threads');
const { keyInfo, VK_STATIC } = require('./569');

const MARK = 0x424f5045;
const ctl = new Int32Array(workerData.ctl);
const injHeld = workerData.injHeld ? new Int32Array(workerData.injHeld) : null;
const injLast = workerData.injLast ? new Float64Array(workerData.injLast) : null;

// ───────────── backend de entrada ─────────────

function createWinBackend() {
  const koffi = require('koffi');
  const user32 = koffi.load('user32.dll');
  const SendInput = user32.func('uint32 SendInput(uint32 n, void* inputs, int cb)');
  const GetCursorPos = user32.func('int GetCursorPos(void* pt)');
  const SetCursorPos = user32.func('int SetCursorPos(int x, int y)');
  const GetSystemMetrics = user32.func('int GetSystemMetrics(int idx)');

  const X64 = process.arch !== 'ia32';
  const SIZE = X64 ? 40 : 28, U = X64 ? 8 : 4;
  const buf = Buffer.alloc(SIZE * 2);
  const pt = Buffer.alloc(8);
  let failures = 0, sent = 0;

  function writeMouse(off, dx, dy, data, flags) {
    buf.fill(0, off, off + SIZE);
    buf.writeUInt32LE(0, off); // INPUT_MOUSE
    buf.writeInt32LE(dx, off + U);
    buf.writeInt32LE(dy, off + U + 4);
    buf.writeUInt32LE(data >>> 0, off + U + 8);
    buf.writeUInt32LE(flags >>> 0, off + U + 12);
    if (X64) buf.writeBigUInt64LE(BigInt(MARK), off + U + 24); else buf.writeUInt32LE(MARK, off + U + 20);
  }
  function writeKey(off, vk, scan, flags) {
    buf.fill(0, off, off + SIZE);
    buf.writeUInt32LE(1, off); // INPUT_KEYBOARD
    buf.writeUInt16LE(vk & 0xffff, off + U);
    buf.writeUInt16LE(scan & 0xffff, off + U + 2);
    buf.writeUInt32LE(flags >>> 0, off + U + 4);
    if (X64) buf.writeBigUInt64LE(BigInt(MARK), off + U + 16); else buf.writeUInt32LE(MARK, off + U + 12);
  }
  function send(n) {
    const r = SendInput(n, buf, SIZE);
    sent++;
    if (r !== n) failures++;
    return r === n;
  }
  function virtualScreen() {
    return { x: GetSystemMetrics(76), y: GetSystemMetrics(77), w: GetSystemMetrics(78) || 1, h: GetSystemMetrics(79) || 1 };
  }
  let vs = virtualScreen();

  return {
    name: 'win',
    stats: () => ({ sent, failures }),
    refresh() { vs = virtualScreen(); },
    cursor() { return GetCursorPos(pt) ? { x: pt.readInt32LE(0), y: pt.readInt32LE(4) } : { x: 0, y: 0 }; },
    moveAbs(x, y, exact) {
      // MOUSEEVENTF_MOVE | ABSOLUTE | VIRTUALDESK  (coordenadas normalizadas 0..65535)
      const nx = Math.round(((x - vs.x) * 65535) / Math.max(1, vs.w - 1));
      const ny = Math.round(((y - vs.y) * 65535) / Math.max(1, vs.h - 1));
      writeMouse(0, nx, ny, 0, 0x0001 | 0x8000 | 0x4000);
      send(1);
      if (exact && GetCursorPos(pt) && (pt.readInt32LE(0) !== x || pt.readInt32LE(4) !== y)) SetCursorPos(x, y);
    },
    moveRel(dx, dy) {
      if (!dx && !dy) return;
      writeMouse(0, dx, dy, 0, 0x0001);
      send(1);
    },
    button(btn, down) {
      const F = {
        left: [0x0002, 0x0004], right: [0x0008, 0x0010], middle: [0x0020, 0x0040],
        back: [0x0080, 0x0100], forward: [0x0080, 0x0100],
      }[btn] || [0x0002, 0x0004];
      const data = btn === 'back' ? 1 : btn === 'forward' ? 2 : 0;
      writeMouse(0, 0, 0, data, down ? F[0] : F[1]);
      send(1);
    },
    wheel(delta) {
      writeMouse(0, 0, 0, delta | 0, 0x0800);
      send(1);
    },
    key(info, down) {
      // KEYEVENTF_SCANCODE quando temos scancode (melhor para jogos); senão por VK.
      let flags = down ? 0 : 0x0002;
      if (info.scan) {
        flags |= 0x0008;
        if (info.ext) flags |= 0x0001;
        writeKey(0, 0, info.scan, flags);
      } else {
        writeKey(0, info.vk, 0, flags);
      }
      send(1);
    },
    char(ch) {
      const code = ch.charCodeAt(0);
      writeKey(0, 0, code, 0x0004);
      writeKey(SIZE, 0, code, 0x0004 | 0x0002);
      send(2);
    },
  };
}

function createMockBackend() {
  const t0 = performance.now();
  const log = [];
  let cx = 0, cy = 0;
  const rec = (a) => log.push({ t: Math.round((performance.now() - t0) * 10) / 10, ...a });
  return {
    name: 'mock', log,
    stats: () => ({ sent: log.length, failures: 0 }),
    refresh() {},
    cursor: () => ({ x: cx, y: cy }),
    moveAbs(x, y) { cx = x; cy = y; rec({ a: 'abs', x, y }); },
    moveRel(dx, dy) { cx += dx; cy += dy; rec({ a: 'rel', dx, dy }); },
    button(btn, down) { rec({ a: down ? 'mdown' : 'mup', btn }); },
    wheel(delta) { rec({ a: 'wheel', delta }); },
    key(info, down) { rec({ a: down ? 'kdown' : 'kup', scan: info.scan, vk: info.vk }); },
    char(ch) { rec({ a: 'char', ch }); },
  };
}

let io;
try {
  io = (process.platform === 'win32' && !workerData.mock) ? createWinBackend() : createMockBackend();
} catch (e) {
  io = null;
  parentPort.postMessage({ type: 'fatal', error: 'backend de entrada indisponível: ' + e.message });
}

// ───────────── tempo ─────────────

const stopped = () => Atomics.load(ctl, 0) !== 0;

/** Dorme até `target` (performance.now). Retorna false se mandaram parar. */
function sleepUntil(target) {
  for (;;) {
    if (stopped()) return false;
    const rem = target - performance.now();
    if (rem <= 0) return true;
    if (rem > 2) Atomics.wait(ctl, 0, 0, Math.min(rem - 1.5, 250)); // acorda na hora se parar
    // últimos ~1.5ms: espera ativa para precisão de sub-milissegundo
  }
}

// ───────────── execução ─────────────

const BTN_VK = { left: 0x01, right: 0x02, middle: 0x04, back: 0x05, forward: 0x06 };
const num = (v, d = 0) => (Number.isFinite(Number(v)) ? Number(v) : d);
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

function markInject(vk, delta) {
  if (!vk) return;
  if (injLast) injLast[vk] = Date.now();
  if (injHeld && delta) Atomics.add(injHeld, vk, delta);
}

function runMacro(macro, countdown) {
  const steps = Array.isArray(macro.steps) ? macro.steps : [];
  const speed = clamp(num(macro.speed, 1), 0.05, 50);
  const mode = macro.mode === 'loop' || macro.mode === 'hold' ? macro.mode : 'once';
  const total = mode === 'once' ? clamp(Math.round(num(macro.repeat, 1)), 1, 1e6) : Infinity;
  const loopDelay = Math.max(0, num(macro.loopDelay, 0));
  const sc = (ms) => Math.max(0, num(ms, 0)) / speed;
  if (!steps.length) return { reason: 'sem passos', iterations: 0, blocked: false };
  // Em loop infinito, garante um respiro mínimo se o macro não tem tempo nenhum
  // (senão o worker ficaria girando a 100% de CPU).
  const effLoopDelay = (total === Infinity && plannedMs(steps) / speed < 5) ? Math.max(loopDelay, 5) : loopDelay;

  const heldKeys = new Map();   // code -> info  (teclas abaixadas pelo macro)
  const heldBtns = new Set();   // botões abaixados pelo macro

  const keyDown = (code) => {
    const info = keyInfo(code);
    if (!info) return;
    const vk = info.vk || VK_STATIC[code] || 0;
    markInject(vk, heldKeys.has(code) ? 0 : 1);
    io.key(info, true);
    heldKeys.set(code, { info, vk });
  };
  const keyUp = (code) => {
    const h = heldKeys.get(code);
    const info = h ? h.info : keyInfo(code);
    if (!info) return;
    const vk = h ? h.vk : (info.vk || 0);
    markInject(vk, 0);
    io.key(info, false);
    if (h) { heldKeys.delete(code); if (injHeld && vk) Atomics.sub(injHeld, vk, 1); }
  };
  const btnDown = (b) => {
    const vk = BTN_VK[b] || 1;
    markInject(vk, heldBtns.has(b) ? 0 : 1);
    io.button(b, true);
    heldBtns.add(b);
  };
  const btnUp = (b) => {
    const vk = BTN_VK[b] || 1;
    markInject(vk, 0);
    io.button(b, false);
    if (heldBtns.delete(b) && injHeld) Atomics.sub(injHeld, vk, 1);
  };
  const releaseAll = () => {
    for (const code of [...heldKeys.keys()].reverse()) { try { keyUp(code); } catch {} }
    for (const b of [...heldBtns].reverse()) { try { btnUp(b); } catch {} }
  };

  io.refresh();
  let t = performance.now() + Math.max(0, num(countdown, 0));
  let iterations = 0;
  let reason = 'concluído';

  const wait = (ms) => { t += ms; return sleepUntil(t); };
  const resync = () => { const now = performance.now(); if (now - t > 40) t = now; };

  try {
    outer: for (let iter = 0; iter < total; iter++) {
      if (iter > 0 && !wait(effLoopDelay)) { reason = 'parado'; break; }
      if (iter === 0 && !sleepUntil(t)) { reason = 'parado'; break; }
      for (const s of steps) {
        if (!s || typeof s !== 'object') continue;
        if (!wait(sc(s.delay))) { reason = 'parado'; break outer; }
        switch (s.t) {
          case 'wait':
            if (!wait(sc(s.ms))) { reason = 'parado'; break outer; }
            break;
          case 'move': {
            const dur = sc(s.dur);
            const x = Math.round(num(s.x)), y = Math.round(num(s.y));
            if (s.rel) {
              if (dur <= 0) { io.moveRel(x, y); break; }
              const n = Math.max(1, Math.round(dur / 6));
              let sx = 0, sy = 0;
              for (let i = 1; i <= n; i++) {
                if (!wait(dur / n)) { reason = 'parado'; break outer; }
                const p = s.ease ? easeInOut(i / n) : i / n;
                const tx = Math.round(x * p), ty = Math.round(y * p);
                io.moveRel(tx - sx, ty - sy); sx = tx; sy = ty;
              }
            } else {
              if (dur <= 0) { io.moveAbs(x, y, true); break; }
              const c = io.cursor();
              const n = Math.max(1, Math.round(dur / 6));
              for (let i = 1; i <= n; i++) {
                if (!wait(dur / n)) { reason = 'parado'; break outer; }
                const p = s.ease ? easeInOut(i / n) : i / n;
                io.moveAbs(Math.round(c.x + (x - c.x) * p), Math.round(c.y + (y - c.y) * p), i === n);
              }
            }
            break;
          }
          case 'path': {
            const pts = Array.isArray(s.pts) ? s.pts : [];
            for (let i = 0; i + 2 < pts.length; i += 3) {
              if (!wait(sc(pts[i]))) { reason = 'parado'; break outer; }
              if (s.rel) io.moveRel(Math.round(num(pts[i + 1])), Math.round(num(pts[i + 2])));
              else io.moveAbs(Math.round(num(pts[i + 1])), Math.round(num(pts[i + 2])), i + 3 >= pts.length);
            }
            break;
          }
          case 'click': {
            const btn = s.btn || 'left';
            const n = clamp(Math.round(num(s.n, 1)), 1, 1000);
            for (let i = 0; i < n; i++) {
              if (i > 0 && !wait(sc(s.gap ?? 60))) { reason = 'parado'; break outer; }
              btnDown(btn);
              if (!wait(sc(s.hold ?? 40))) { btnUp(btn); reason = 'parado'; break outer; }
              btnUp(btn);
            }
            break;
          }
          case 'flick': {
            // Reproduz o macro.ahk, com TODOS os delays configuráveis e movimento RELATIVO:
            //   (pre) → M1 Down → (hold) → M1 Up → (afterUp/pre-flick) → MoveRel(dx,dy) em moveDur
            //         → (afterMove) → (cooldown)
            // moveDur = 0 → um único movimento relativo (igual ao mouse_event do .ahk).
            if (!wait(sc(s.pre))) { reason = 'parado'; break outer; }
            const btn = s.btn === 'none' ? null : (s.btn || 'left');
            if (btn) {
              btnDown(btn);
              if (!wait(sc(s.hold ?? 500))) { btnUp(btn); reason = 'parado'; break outer; }
              btnUp(btn);
            }
            if (!wait(sc(s.afterUp))) { reason = 'parado'; break outer; }
            const tx = Math.round(num(s.dx)), ty = Math.round(num(s.dy));
            const dur = sc(s.moveDur);
            if (dur <= 0) {
              io.moveRel(tx, ty); // puxão único — a câmera do Roblox recebe como um movimento relativo
            } else {
              const n = Math.max(1, Math.round(dur / 4)); // ~250 Hz: visível, mas rápido
              let sx = 0, sy = 0;
              for (let i = 1; i <= n; i++) {
                if (!wait(dur / n)) { reason = 'parado'; break outer; }
                const nx = Math.round((tx * i) / n), ny = Math.round((ty * i) / n);
                io.moveRel(nx - sx, ny - sy); sx = nx; sy = ny;
              }
            }
            if (!wait(sc(s.afterMove))) { reason = 'parado'; break outer; }
            if (!wait(sc(s.cooldown))) { reason = 'parado'; break outer; }
            break;
          }
          case 'down': btnDown(s.btn || 'left'); break;
          case 'up': btnUp(s.btn || 'left'); break;
          case 'scroll': {
            const amt = Math.round(num(s.amount, 1));
            const n = Math.min(Math.abs(amt), 200);
            for (let i = 0; i < n; i++) {
              if (i > 0 && !wait(sc(s.gap ?? 20))) { reason = 'parado'; break outer; }
              io.wheel(amt > 0 ? 120 : -120);
            }
            break;
          }
          case 'key': {
            if (!s.code) break;
            const n = clamp(Math.round(num(s.n, 1)), 1, 1000);
            for (let i = 0; i < n; i++) {
              if (i > 0 && !wait(sc(s.gap ?? 60))) { reason = 'parado'; break outer; }
              keyDown(s.code);
              if (!wait(sc(s.hold ?? 40))) { keyUp(s.code); reason = 'parado'; break outer; }
              keyUp(s.code);
            }
            break;
          }
          case 'keydown': if (s.code) keyDown(s.code); break;
          case 'keyup': if (s.code) keyUp(s.code); break;
          case 'text': {
            const chars = Array.from(String(s.text ?? ''));
            for (let i = 0; i < chars.length; i++) {
              if (i > 0 && !wait(sc(s.gap ?? 15))) { reason = 'parado'; break outer; }
              const ch = chars[i];
              if (ch === '\n') { keyDown('Enter'); keyUp('Enter'); }
              else for (let k = 0; k < ch.length; k++) io.char(ch[k]); // UTF-16 (emoji = 2 unidades)
            }
            break;
          }
          default: break;
        }
        resync();
      }
      iterations++;
    }
  } finally {
    releaseAll();
  }
  const st = io.stats();
  const blocked = st.sent > 0 && st.failures === st.sent;
  return { reason, iterations, blocked };
}

/** Duração planejada (ms, sem velocidade) de uma passada pelos passos. */
function plannedMs(steps) {
  let ms = 0;
  for (const s of steps) {
    if (!s) continue;
    ms += Math.max(0, num(s.delay));
    if (s.t === 'wait') ms += Math.max(0, num(s.ms));
    else if (s.t === 'move') ms += Math.max(0, num(s.dur));
    else if (s.t === 'path') { const p = s.pts || []; for (let i = 0; i < p.length; i += 3) ms += Math.max(0, num(p[i])); }
    else if (s.t === 'flick') ms += num(s.pre) + (s.btn === 'none' ? 0 : num(s.hold ?? 500)) + num(s.afterUp) + num(s.moveDur) + num(s.afterMove) + num(s.cooldown);
    else if (s.t === 'click' || s.t === 'key') { const n = Math.max(1, num(s.n, 1)); ms += n * num(s.hold ?? 40) + (n - 1) * num(s.gap ?? 60); }
    else if (s.t === 'scroll') ms += Math.max(0, Math.abs(num(s.amount, 1)) - 1) * num(s.gap ?? 20);
    else if (s.t === 'text') ms += Math.max(0, String(s.text ?? '').length - 1) * num(s.gap ?? 15);
  }
  return ms;
}

function easeInOut(p) { return p < 0.5 ? 2 * p * p : 1 - Math.pow(-2 * p + 2, 2) / 2; }

parentPort.on('message', (m) => {
  if (!m || m.type !== 'run') return;
  if (!io) { parentPort.postMessage({ type: 'done', runId: m.runId, ok: false, reason: 'erro', error: 'backend indisponível' }); return; }
  let res;
  try {
    res = runMacro(m.macro || {}, m.countdown || 0);
  } catch (e) {
    parentPort.postMessage({ type: 'done', runId: m.runId, ok: false, reason: 'erro', error: e.message });
    return;
  }
  const out = { type: 'done', runId: m.runId, ok: !res.blocked, reason: res.reason, iterations: res.iterations };
  if (res.blocked) out.error = 'SendInput bloqueado pelo Windows (se o jogo roda como administrador, rode o helper como administrador também).';
  if (io.name === 'mock') out.log = io.log.splice(0);
  parentPort.postMessage(out);
});

parentPort.postMessage({ type: 'ready', backend: io ? io.name : null });
