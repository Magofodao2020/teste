/*
 * Worker: hooks globais de baixo nível (WH_MOUSE_LL / WH_KEYBOARD_LL).
 * Substitui o antigo mouse-hook.js.
 *
 *  1) SCROLL — sempre ativo. GetAsyncKeyState não detecta a roda do mouse, então
 *     o hook avisa a thread principal:  { type:'input', code:'ScrollUp'|'ScrollDown' }
 *
 *  2) GRAVAÇÃO DE MACRO — só enquanto a thread principal liga a flag na memória
 *     compartilhada. Aí o worker manda cada evento de mouse/teclado:
 *        { type:'rec', e:'move'|'mdown'|'mup'|'wheel'|'kdown'|'kup', ... }
 *     e { type:'rec-stop' } quando a tecla de parada é pressionada.
 *
 *  3) CAPTURA DE BOTÃO — enquanto [3] ≠ 0 (o site pediu para "definir botão"):
 *     cada botão pressionado (inclusive laterais), scroll ou tecla vira
 *        { type:'cap', code } / { type:'cap', vk, scan, ext }
 *     Funciona igual em qualquer navegador, porque vem do Windows. Os laterais
 *     capturados não chegam ao navegador (senão ele "volta" a página).
 *
 * Memória compartilhada (Int32Array em workerData.shared):
 *   [0] gravando (0/1)        [1] VK da tecla de parada (0 = nenhuma)
 *   [2] gravar movimento (0/1) [3] capturando: 0 não, 1 mouse+teclado, 2 só teclado
 *
 * Eventos injetados pelo próprio helper (macros) carregam dwExtraInfo = MARK e
 * são ignorados — assim um macro rodando não dispara hotkeys de scroll nem entra
 * numa gravação.
 *
 * Se o koffi/hook falhar, o worker só avisa e sai; o resto do helper segue.
 */
const { parentPort, workerData } = require('worker_threads');

const MARK = 0x424f5045; // 'BOPE'
const shared = workerData && workerData.shared ? new Int32Array(workerData.shared) : new Int32Array(4);

function fail(msg) {
  try { parentPort.postMessage({ type: 'error', error: msg }); } catch {}
  process.exit(0);
}

if (process.platform !== 'win32') fail('somente Windows');

let koffi;
try { koffi = require('./dp'); } catch (e) { fail('koffi não carregou: ' + e.message); }

try {
  const user32 = koffi.load('user32.dll');
  const kernel32 = koffi.load('kernel32.dll');

  const MSLLHOOKSTRUCT = koffi.struct('BOPE_MSLLHOOKSTRUCT', {
    x: 'int32', y: 'int32', mouseData: 'uint32', flags: 'uint32', time: 'uint32', dwExtraInfo: 'uintptr_t',
  });
  const KBDLLHOOKSTRUCT = koffi.struct('BOPE_KBDLLHOOKSTRUCT', {
    vkCode: 'uint32', scanCode: 'uint32', flags: 'uint32', time: 'uint32', dwExtraInfo: 'uintptr_t',
  });

  const GetModuleHandleW = kernel32.func('void* GetModuleHandleW(void* name)');
  const SetWindowsHookExW = user32.func('void* SetWindowsHookExW(int idHook, void* lpfn, void* hMod, uint32 threadId)');
  const CallNextHookEx = user32.func('intptr_t CallNextHookEx(void* hhk, int nCode, uintptr_t wParam, void* lParam)');
  const UnhookWindowsHookEx = user32.func('int UnhookWindowsHookEx(void* hhk)');
  const GetMessageW = user32.func('int GetMessageW(void* msg, void* hWnd, uint32 min, uint32 max)');
  const SetTimer = user32.func('uintptr_t SetTimer(void* hWnd, uintptr_t id, uint32 elapse, void* fn)');
  const GetCursorPos = user32.func('int GetCursorPos(void* pt)');

  const WH_KEYBOARD_LL = 13, WH_MOUSE_LL = 14;
  const WM_MOUSEMOVE = 0x200, WM_LBUTTONDOWN = 0x201, WM_LBUTTONUP = 0x202, WM_RBUTTONDOWN = 0x204,
    WM_RBUTTONUP = 0x205, WM_MBUTTONDOWN = 0x207, WM_MBUTTONUP = 0x208, WM_MOUSEWHEEL = 0x20a,
    WM_XBUTTONDOWN = 0x20b, WM_XBUTTONUP = 0x20c;
  const WM_KEYDOWN = 0x100, WM_KEYUP = 0x101, WM_SYSKEYDOWN = 0x104, WM_SYSKEYUP = 0x105;

  const BTN = {
    [WM_LBUTTONDOWN]: ['mdown', 'left'], [WM_LBUTTONUP]: ['mup', 'left'],
    [WM_RBUTTONDOWN]: ['mdown', 'right'], [WM_RBUTTONUP]: ['mup', 'right'],
    [WM_MBUTTONDOWN]: ['mdown', 'middle'], [WM_MBUTTONUP]: ['mup', 'middle'],
  };

  const HookProc = koffi.proto('intptr_t __stdcall BopeHookProc(int nCode, uintptr_t wParam, void* lParam)');
  const ptBuf = Buffer.alloc(8);
  const post = (m) => { try { parentPort.postMessage(m); } catch {} };

  const CAP_BTN = { [WM_LBUTTONDOWN]: 'MouseLeft', [WM_RBUTTONDOWN]: 'MouseRight', [WM_MBUTTONDOWN]: 'MouseMiddle' };
  let swallowXUp = 0; // lateral capturado: engole também o "soltar" (o navegador volta a página no soltar)

  const mouseCb = koffi.register((nCode, wParam, lParam) => {
    try {
      if (nCode >= 0 && lParam) {
        const msg = Number(wParam);
        const recording = Atomics.load(shared, 0) === 1;
        const capturing = Atomics.load(shared, 3) === 1; // 2 = só teclado: mouse segue normal
        if (swallowXUp && msg === WM_XBUTTONUP) {
          const d = koffi.decode(lParam, MSLLHOOKSTRUCT);
          if (((d.mouseData >>> 16) & 0xffff) === swallowXUp) { swallowXUp = 0; return 1; }
        }
        if (capturing && msg !== WM_MOUSEMOVE) {
          const d = koffi.decode(lParam, MSLLHOOKSTRUCT);
          if (Number(d.dwExtraInfo) !== MARK) {
            if (CAP_BTN[msg]) post({ type: 'cap', code: CAP_BTN[msg] });
            else if (msg === WM_XBUTTONDOWN) {
              const which = (d.mouseData >>> 16) & 0xffff;
              post({ type: 'cap', code: which === 2 ? 'MouseForward' : 'MouseBack' });
              swallowXUp = which;
              return 1;
            } else if (msg === WM_MOUSEWHEEL) {
              let delta = (d.mouseData >>> 16) & 0xffff;
              if (delta > 0x7fff) delta -= 0x10000;
              if (delta !== 0) post({ type: 'cap', code: delta > 0 ? 'ScrollUp' : 'ScrollDown' });
            }
          }
        }
        if (msg === WM_MOUSEWHEEL || recording) {
          const d = koffi.decode(lParam, MSLLHOOKSTRUCT);
          const ours = Number(d.dwExtraInfo) === MARK;
          if (msg === WM_MOUSEWHEEL) {
            let delta = (d.mouseData >>> 16) & 0xffff;
            if (delta > 0x7fff) delta -= 0x10000;
            if (delta !== 0 && !ours) post({ type: 'input', code: delta > 0 ? 'ScrollUp' : 'ScrollDown' });
            if (recording && !ours && delta !== 0) post({ type: 'rec', e: 'wheel', delta, x: d.x, y: d.y, t: d.time });
          } else if (recording && !ours) {
            if (msg === WM_MOUSEMOVE) {
              if (Atomics.load(shared, 2) === 1) {
                // No hook de baixo nível o cursor ainda NÃO andou: posição atual = antes do movimento.
                let dx = 0, dy = 0;
                if (GetCursorPos(ptBuf)) { dx = d.x - ptBuf.readInt32LE(0); dy = d.y - ptBuf.readInt32LE(4); }
                post({ type: 'rec', e: 'move', x: d.x, y: d.y, dx, dy, t: d.time });
              }
            } else if (BTN[msg]) {
              const [e, btn] = BTN[msg];
              post({ type: 'rec', e, btn, x: d.x, y: d.y, t: d.time });
            } else if (msg === WM_XBUTTONDOWN || msg === WM_XBUTTONUP) {
              const which = (d.mouseData >>> 16) & 0xffff;
              post({ type: 'rec', e: msg === WM_XBUTTONDOWN ? 'mdown' : 'mup', btn: which === 2 ? 'forward' : 'back', x: d.x, y: d.y, t: d.time });
            }
          }
        }
      }
    } catch { /* nunca deixar exceção escapar do hook */ }
    return CallNextHookEx(null, nCode, wParam, lParam);
  }, koffi.pointer(HookProc));

  const held = new Set();
  let stopHeld = false;
  const keyCb = koffi.register((nCode, wParam, lParam) => {
    try {
      const recording = Atomics.load(shared, 0) === 1;
      const capturing = Atomics.load(shared, 3) !== 0;
      if (nCode >= 0 && lParam && (recording || capturing)) {
        const msg = Number(wParam);
        const k = koffi.decode(lParam, KBDLLHOOKSTRUCT);
        if (capturing && Number(k.dwExtraInfo) !== MARK && (msg === WM_KEYDOWN || msg === WM_SYSKEYDOWN)) {
          post({ type: 'cap', vk: k.vkCode, scan: k.scanCode, ext: (k.flags & 1) ? 1 : 0 });
        }
        if (recording && Number(k.dwExtraInfo) !== MARK) {
          const down = msg === WM_KEYDOWN || msg === WM_SYSKEYDOWN;
          const up = msg === WM_KEYUP || msg === WM_SYSKEYUP;
          const stopVk = Atomics.load(shared, 1);
          if (stopVk && k.vkCode === stopVk) {
            // tecla de parada: não entra na gravação
            if (down && !stopHeld) { stopHeld = true; post({ type: 'rec-stop' }); }
            if (up) stopHeld = false;
          } else if (down) {
            if (!held.has(k.vkCode)) { // ignora auto-repeat do teclado
              held.add(k.vkCode);
              post({ type: 'rec', e: 'kdown', vk: k.vkCode, scan: k.scanCode, ext: (k.flags & 1) ? 1 : 0, t: k.time });
            }
          } else if (up) {
            held.delete(k.vkCode);
            post({ type: 'rec', e: 'kup', vk: k.vkCode, scan: k.scanCode, ext: (k.flags & 1) ? 1 : 0, t: k.time });
          }
        }
      }
    } catch {}
    return CallNextHookEx(null, nCode, wParam, lParam);
  }, koffi.pointer(HookProc));

  const hMod = GetModuleHandleW(null);
  const hMouse = SetWindowsHookExW(WH_MOUSE_LL, mouseCb, hMod, 0);
  if (!hMouse) fail('SetWindowsHookEx (mouse) falhou');
  let hKey = null;

  // Timer de 40ms: acorda o loop de mensagens para ligar/desligar o hook de
  // teclado conforme as flags (o teclado só é "escutado" gravando ou capturando).
  SetTimer(null, 0, 40, null);
  parentPort.postMessage({ type: 'ready' });

  const msgBuf = Buffer.alloc(64);
  for (;;) {
    const r = GetMessageW(msgBuf, null, 0, 0);
    if (r === 0 || r === -1) break;
    const recording = Atomics.load(shared, 0) === 1 || Atomics.load(shared, 3) !== 0;
    if (recording && !hKey) {
      held.clear(); stopHeld = false;
      hKey = SetWindowsHookExW(WH_KEYBOARD_LL, keyCb, hMod, 0);
      if (!hKey) post({ type: 'warn', error: 'hook de teclado falhou — gravando só o mouse' });
    } else if (!recording && hKey) {
      try { UnhookWindowsHookEx(hKey); } catch {}
      hKey = null; held.clear();
    }
  }
  try { if (hKey) UnhookWindowsHookEx(hKey); } catch {}
  try { UnhookWindowsHookEx(hMouse); } catch {}
  process.exit(0);
} catch (e) {
  fail(e.message);
}
