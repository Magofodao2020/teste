Datasets públicos (compartilhados por todos os usuários).

manifest.json  -> lista de versões disponíveis (campo "latest" = padrão).
<versao>.json  -> dump normalizado (robloxVersion, flags[], structOffsets...).

Para publicar uma nova versão do Roblox SEM alterar código:
  node scripts/build-dataset.mjs caminho/para/novo.hpp "Rótulo opcional"
Isso gera o <versao>.json e regenera o manifest. Depois: npm run build + deploy.
